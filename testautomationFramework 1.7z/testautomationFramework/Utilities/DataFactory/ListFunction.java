package DataFactory;

import java.util.List;
import java.util.Map;

public class ListFunction {
	
	public static Object GetKeyValueFromHashMap(List<Map<String, Object>> resultSet, String key) {
		   
		   String value = "";
		   for (int i = 0; i < resultSet.size(); i++) {
			   
			    for (Map.Entry<String, Object> entry: resultSet.get(i).entrySet()) {
			        if (key.equals(entry.getKey().toString())) {
			        	value = (String) entry.getValue();
			            break;
			        }
			    }
			}
		   
		   return value;
	   }
	 

}
