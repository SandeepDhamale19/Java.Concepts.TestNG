/**
 * 
 */
package DownloadsFolder;

import java.io.File;

import org.testng.Assert;


/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class getLatestFile {
		
	/*
     * Functionality: Fetch details of the latest file in the given folder path 
     * Date: 21/11/2022 Author: Ridhang
     */
	public void getLatestFilefromDownloads(String dirPath, String documentType){
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	    	Assert.fail("Downloading failed no files found!!!");
	    }

	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    if (lastModifiedFile.getName().contains(documentType)) {
	    	System.out.println(lastModifiedFile.getName() + " File is downloaded");
	    }
	    else {
	    	Assert.fail("Downloading failed no files found!");
	    }
	}
	
}
