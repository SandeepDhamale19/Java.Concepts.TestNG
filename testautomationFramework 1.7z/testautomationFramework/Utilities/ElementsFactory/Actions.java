/**
 * 
 */
package ElementsFactory;

import java.time.Duration;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;

import com.google.common.collect.ImmutableList;

import ActionsFactory.ActionOnElement;
import ActionsFactory.InputAction;
import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalIOSDriver;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Actions {

	private String _locator ;
	private String _locatorType ;
	
	public Actions() {
	}
	
	public Actions(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public void ActionMouseHover() {
		ActionOnElement actions= new ActionOnElement(_locator, _locatorType);
		actions.mouseHover();
	}
	
	public void ActionMouseclick() {
		ActionOnElement actions= new ActionOnElement(_locator, _locatorType);
		actions.mouseClick();
	}
	
	public void ActionDoubleclick() {
		ActionOnElement actions= new ActionOnElement(_locator, _locatorType);
		actions.mouseDoubleClick();
	}
	
	public void ScrollDown() {
		Dimension size = ThreadLocalAndroidDriver.getDriver().manage().window().getSize();
		System.out.println("Size"+size);
		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 
		int bottom=midPoint.y + (int)(midPoint.y*0.75);
		int top=midPoint.y - (int)(midPoint.y*0.75);
		Point start = new Point(midPoint.x,bottom);
		Point end = new Point(midPoint.x,top);
		
		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence scroll = new Sequence(indexFinger, 0);
		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), start.x, start.y));
		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), end.x, end.y));
		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		
		ThreadLocalAndroidDriver.getDriver().perform(ImmutableList.of(scroll));
	}

	
	//IOS Actions
	public void IOSScrollDown() {
		Dimension size = ThreadLocalIOSDriver.getDriver().manage().window().getSize();
		System.out.println("Size"+size);
		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 
		int bottom=midPoint.y + (int)(midPoint.y*0.75);
		int top=midPoint.y - (int)(midPoint.y*0.75);
		Point start = new Point(midPoint.x,bottom);
		Point end = new Point(midPoint.x,top);
		
		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence scroll = new Sequence(indexFinger, 0);
		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), start.x, start.y));
		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), end.x, end.y));
		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		
		ThreadLocalIOSDriver.getDriver().perform(ImmutableList.of(scroll));
	}
	
	public static void IOSScrollUp() {
		Dimension size = ThreadLocalIOSDriver.getDriver().manage().window().getSize();
		
		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 
		
		int bottom=midPoint.y - (int)(midPoint.y*0.75);
		
		int top=midPoint.y + (int)(midPoint.y*0.75);
		Point start = new Point(midPoint.y,top);
		Point end = new Point(midPoint.y,bottom);
		
		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence scroll = new Sequence(indexFinger, 0);
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), end.y, end.x));
		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), start.x, start.y));
		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		
		ThreadLocalIOSDriver.getDriver().perform(ImmutableList.of(scroll));
		System.out.println();
	}
	
	
	public void IOSScrollDown(double valbottom,double valup) {
		Dimension size = ThreadLocalIOSDriver.getDriver().manage().window().getSize();
		System.out.println("Size"+size);
		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 
		int bottom=midPoint.y + (int)(midPoint.y*valbottom);
		int top=midPoint.y - (int)(midPoint.y*valup);
		Point start = new Point(midPoint.x,bottom);
		Point end = new Point(midPoint.x,top);
		
		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence scroll = new Sequence(indexFinger, 0);
		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), start.x, start.y));
		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), end.x, end.y));
		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		
		ThreadLocalIOSDriver.getDriver().perform(ImmutableList.of(scroll));
	}
	
	public  void IOSScrollUp(double valbottom,double valup) {
		Dimension size = ThreadLocalIOSDriver.getDriver().manage().window().getSize();
		
		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 
		
		int bottom=midPoint.y - (int)(midPoint.y*valbottom);
		int top=midPoint.y + (int)(midPoint.y*valup);
		
		Point start = new Point(midPoint.y,top);
		Point end = new Point(midPoint.y,bottom);
		
		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence scroll = new Sequence(indexFinger, 0);
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), end.y, end.x));
		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), start.x, start.y));
		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		
		ThreadLocalIOSDriver.getDriver().perform(ImmutableList.of(scroll));
		System.out.println();
	}
	
}
