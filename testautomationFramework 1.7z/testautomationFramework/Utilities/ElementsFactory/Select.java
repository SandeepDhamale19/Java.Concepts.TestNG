/**
 * 
 */
package ElementsFactory;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import ActionsFactory.SelectDropdownAction;
import Selenium.ElementProperties;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Select {
	
	private String _locator = "";
	private String _locatorType = "";
	
	public Select(String locator,String locatorType) {
		_locator = locator;
		_locatorType = locatorType;
	}
	
	public void selectByVisibleText(String visibleText){
		SelectDropdownAction select=new SelectDropdownAction(_locator, _locatorType);
		select.selectByVisibleText(visibleText);
	}
	
	public void selectByValue(String value) {
		SelectDropdownAction select=new SelectDropdownAction(_locator, _locatorType);
		select.selectByValue(value);
	}
	
	public void selectByIndex(int Index) {
		SelectDropdownAction select=new SelectDropdownAction(_locator, _locatorType);
		select.selectByIndex(Index);
	}
	
	public String selectgetFirstSelectedOption() {
		SelectDropdownAction select=new SelectDropdownAction(_locator, _locatorType);
		String getFirstSelectedOption = select.selectgetFirstSelectedOption();
		return getFirstSelectedOption;
	}
	
	public Boolean CheckElementExistsInDropDown(String SelectwebElement) {
		Boolean flag=false;
		List list = new ArrayList();
		SelectDropdownAction select=new SelectDropdownAction(_locator, _locatorType);
		list  = select.DropDownOptions();
		for(int i=0;i<list.size();i++) {
			if (SelectwebElement.equalsIgnoreCase(list.get(i).toString())) {
				flag=true;
			}
		}
		return flag;
	}
}
