/**
 * 
 */
package ElementsFactory;

import ActionsFactory.FindElements;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Tables {
	
//	private String _locator1 = "";
//	private String _locatorType = "";
//	
//	public Tables(String locator, String locatorType) {
//		this._locator=locator;
//		this._locatorType=locatorType;
//	}
//	
//	public List<HashMap<String, String>> getTableDataUIContent(By StartDateXpath, By contentXpath)
//    {
//           List <HashMap<String, String>> ccpTableData = new ArrayList<HashMap<String, String>>();
//           List <WebElement> tableContributionID = FindElements.FindElement(_locator, _locatorType);
//           List <WebElement> tableStartDate = driver.findElements(StartDateXpath);
//           System.out.println("tableContent:"+tableContributionID.size());
//           System.out.println("tableStartDate:"+tableStartDate.size());
//           
//           for(int i=0; i<tableContributionID.size(); i++) {
//                  HashMap<String, String> tableRow = new HashMap<String, String>();
//                  System.out.println("Table Content:"+tableContributionID.get(i).getText());
//                  tableRow.put(tableStartDate.get(i).getText().replaceAll("\\s", ""), tableContributionID.get(i).getText());
//                  ccpTableData.add(tableRow);
//           }
//           System.out.println(ccpTableData);
//           return ccpTableData;
//    }

	
	
}
