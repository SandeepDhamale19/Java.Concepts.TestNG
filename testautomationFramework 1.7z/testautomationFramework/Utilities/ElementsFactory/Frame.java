/**
 * 
 */
package ElementsFactory;

import ActionsFactory.FrameActions;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Frame {
	
	private String _locator = "";
	private String _locatorType = "";
	
	public Frame(String locator, String locatorType) {
		this._locator=locator;
		this._locatorType=locatorType;
	}
	
	public void switchtoFrameWithWebElement() {
		FrameActions actions= new FrameActions(_locator, _locatorType);
		actions.switchtoFrameWithWebElement();
	}
	
	public void switchtoFrameWithIndex(int index) {
		FrameActions actions= new FrameActions(_locator, _locatorType);
		actions.switchtoFrameWithIndex(index);
	}
	
	public void switchtoFrameWithID(String  id_name) {
		FrameActions actions= new FrameActions();
		actions.switchtoFrameWithid(id_name);
	}
	
	public String getFrameNameSwitched() {
		FrameActions actions= new FrameActions();
		String framename = actions.getFramename(); 
		return framename;
	}
	
	public void switchedToParentFrame() {
		FrameActions actions= new FrameActions();
		actions.switchedToParentFrame();
	}
	
	public void switchedToDefaultFrame() {
		FrameActions actions= new FrameActions();
		actions.switchedToDefaultContent();
	}
	
}
