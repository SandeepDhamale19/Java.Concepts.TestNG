/**
 * 
 */
package ElementsFactory;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import ActionsFactory.FindAndroidElements;
import ActionsFactory.FindElements;
import ActionsFactory.FindIOSElements;
import ActionsFactory.LabelActions;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Label {
	
	private String _locator = "";
	private String _locatorType = "";
	
	public Label(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public Label() {
	}
	
	public String getTextlabel() {
		LabelActions lblactions=new LabelActions(_locator, _locatorType);
		String label = lblactions.getLabel();
		return label;
	}
	
	
	public String getTagname() {
		LabelActions lblactions=new LabelActions(_locator, _locatorType);
		String TagName = lblactions.getTagName();
		return TagName;
	}
	
	public String getAttributeName(String attributeName) {
		LabelActions lblactions=new LabelActions(_locator, _locatorType);
		String TagName = lblactions.getAttributeName(attributeName);
		return TagName;
	}
	
	public boolean getLabelIsDisplayed() {
		LabelActions lblactions=new LabelActions(_locator, _locatorType);
		boolean flag=false;
			flag =lblactions.getLabelIsDisplayed();
		return flag;
	}
	
//	private String _locator = "";
//	private String _locatorType = "";
//	
//	public ValidateLabelUI(String locator,String locatorType) {
//		this._locator = locator;
//		this._locatorType = locatorType;
//	}
//	
//	public ValidateLabelUI(String locatorType) {
//		this._locatorType = locatorType;
//	}
	
	
	public  void verifyText(String Expectedlabel) {
		WebElement ele = FindElements.FindElement(_locator, _locatorType);
				System.out.println("Label ON UI::"+ele.getText());
				if (ele.getText().equalsIgnoreCase(Expectedlabel)) {
					ExtentCucumberAdapter.addTestStepLog("Label "+ele.getText()+" Matches with "+Expectedlabel);
				}else {
					ExtentCucumberAdapter.addTestStepLog("Label "+ele.getText()+" does not matches with "+Expectedlabel);
					Assert.fail();
				}
	}
	
//	public  void verifyLabelDisplayedonUI(String xpathUI,String message) {
//		WebElement ele = FindElements.FindElement(xpathUI, _locatorType);
//		try {
//			Explicitwait.waitVisibility(ele);
//			if (ele.isDisplayed()) {
//					ExtentCucumberAdapter.addTestStepLog(message);
//			}else {
//				Assert.fail(message+" FAILED!!");
//			}
//		}catch (Exception e) {
//			e.printStackTrace();
//			Assert.fail(message+" FAILED!!"+e.getStackTrace());
//		}
//	}
	
	
	public void verifyLabelonUI(String Expectedlabel) {
				if (FindElements.FindElements(_locator, _locatorType).size()>0) {
					System.out.println("Label:"+FindElements.FindElements(_locator, _locatorType).get(0).getText());
					if (FindElements.FindElements(_locator, _locatorType).get(0).getText().equalsIgnoreCase(Expectedlabel)) {
						WebElement label = FindElements.FindElements(_locator, _locatorType).get(0);
						ExtentCucumberAdapter.addTestStepLog("Label "+label.getText()+" Matches with "+Expectedlabel);
					}else {
						Assert.fail("Label does not matches with "+Expectedlabel);
						ExtentCucumberAdapter.addTestStepLog("Label does not matches with "+Expectedlabel);
					}
				}else {
					Assert.fail("Element is Not Visible on UI!!");
					ExtentCucumberAdapter.addTestStepLog("Element is Not Visible on UI");
				}
	}

	
	// Android UI Elements //
	public void androiElementverifyLabelonUI(String Expectedlabel) {
		if (FindAndroidElements.FindElements(_locator, _locatorType).size()>0) {
			System.out.println("Label:"+ FindAndroidElements.FindElements(_locator, _locatorType).get(0).getText());
			if (FindAndroidElements.FindElements(_locator, _locatorType).get(0).getText().equalsIgnoreCase(Expectedlabel)) {
				WebElement label = FindAndroidElements.FindElements(_locator, _locatorType).get(0);
				ExtentCucumberAdapter.addTestStepLog("Label "+label.getText()+" Matches with "+Expectedlabel);
			}else {
				Assert.fail("Label does not matches with "+Expectedlabel);
				ExtentCucumberAdapter.addTestStepLog("Label does not matches with "+Expectedlabel);
			}
		}else {
			Assert.fail("Element is Not Visible on UI!!");
			ExtentCucumberAdapter.addTestStepLog("Element is Not Visible on UI");
		}
}
	
	
	public boolean androidElementgetLabelIsDisplayed() {
		LabelActions lblactions=new LabelActions(_locator, _locatorType);
		boolean flag=false;
			flag =lblactions.androidElementgetLabelIsDisplayed();
		return flag;
	}
	
	public int androidElementgetSize() {
		LabelActions lblactions=new LabelActions(_locator, _locatorType);
		int size=0;
		try {
			size =lblactions.androidElementSeize();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return size;
	}
	
	public List<WebElement> androidElementgetIndex()	{
		LabelActions lblactions=new LabelActions(_locator, _locatorType);
			List<WebElement> element =null;
			try {
				element = lblactions.androidElementgetIndex();
			}catch (Exception e) {
				e.printStackTrace();
			}
		return element;
	}
	
	
	// IOS UI Elements //
		public void iosElementverifyLabelonUI(String Expectedlabel) {
			if (FindIOSElements.FindElements(_locator, _locatorType).size()>0) {
				System.out.println("Label:"+ FindIOSElements.FindElements(_locator, _locatorType).get(0).getText());
				if (FindIOSElements.FindElements(_locator, _locatorType).get(0).getText().equalsIgnoreCase(Expectedlabel)) {
					WebElement label = FindIOSElements.FindElements(_locator, _locatorType).get(0);
					ExtentCucumberAdapter.addTestStepLog("Label "+label.getText()+" Matches with "+Expectedlabel);
				}else {
					Assert.fail("Label does not matches with "+Expectedlabel);
					ExtentCucumberAdapter.addTestStepLog("Label does not matches with "+Expectedlabel);
				}
			}else {
				Assert.fail("Element is Not Visible on UI!!");
				ExtentCucumberAdapter.addTestStepLog("Element is Not Visible on UI");
			}
	}
		
		
		public void iosElementgetLabelIsDisplayed() {
			LabelActions lblactions=new LabelActions(_locator, _locatorType);
			boolean	flag =lblactions.iosElementgetLabelIsDisplayed();
			Assert.assertTrue(flag);
		}
		
		public int iosElementgetSize() {
			LabelActions lblactions=new LabelActions(_locator, _locatorType);
			int size=0;
			try {
				size =lblactions.iosElementSeize();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return size;
		}
		
		public List<WebElement> iosElementgetIndex()	{
			LabelActions lblactions=new LabelActions(_locator, _locatorType);
				List<WebElement> element =null;
				try {
					element = lblactions.iosElementgetIndex();
				}catch (Exception e) {
					e.printStackTrace();
				}
			return element;
		}
	
		public void iosElementgetLabelIsDisplayed(String label) {
			LabelActions lblactions=new LabelActions("//XCUIElementTypeStaticText[@label='"+label+"']","XPATH");
			boolean	flag =lblactions.iosElementgetLabelIsDisplayed();
			Assert.assertTrue(flag);
		}
	
	
	
	
}

