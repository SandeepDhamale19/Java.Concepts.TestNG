/**
 * 
 */
package ScreenshotFactory;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.OutputType;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalDriver;
import DriverFactory.ThreadLocalIOSDriver;

/**
 * @author Varun Paranganath
 *31/05/2023
 *testautomation-framework
 */
public class TakeScreenshotIOS {

	public TakeScreenshotIOS() throws Exception {
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("HH_mm_ss");
        File srcFile = ThreadLocalIOSDriver.getDriver().getScreenshotAs(OutputType.FILE);
        String fileName = dateFormat.format(date).toString();
        File dstFile = new File("\\adcfs.capita.co.uk\\Public\\LMS\\GlobalBeckenham\\UK_LIC_Automation\\LIC_ScreenShots\\"+fileName+".png");
        FileUtils.copyFile(srcFile,dstFile);
        try{
            ExtentCucumberAdapter.addTestStepLog("<a href=\""+dstFile.toString()+"\" target=\"_blank\" ><i>Screenshot Evidences</i></a>");
        }catch (Exception e) {
            ExtentCucumberAdapter.addTestStepLog("Captured screenshot file not found - FAILED!");
            ExtentCucumberAdapter.addTestStepLog("<a href=\""+dstFile.toString()+"\" target=\"_blank\" ><i>Screenshot Evidences</i></a>");
        }
	}
	
}
