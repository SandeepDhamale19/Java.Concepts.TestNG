package WebTableFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DateFactory.DateFunction;
import Hardwait.Hardwait;

public class WebTableFactory {
	public static SoftAssert softAssert =new SoftAssert();
	public static void validateDatainWebTable(int seizeColumn,List<WebElement> Row_ivc,String ColumnName,String Columndata) {
		Hardwait.staticWait(5000);
		List<HashMap<String, String>> transactionHistory = new ArrayList<HashMap<String, String>>();
		for (int i = 0; i < seizeColumn; i++) {
			HashMap<String,String> tableRow=new HashMap<String,String>();
			tableRow.put(ColumnName, Row_ivc.get(i).getText());
			transactionHistory.add(tableRow);
		}
		
	if (!transactionHistory.isEmpty() && transactionHistory!=null) {
		for (int i = 0; i < transactionHistory.size(); i++) {
				HashMap<String, String> _mapTransaction = transactionHistory.get(i);
				System.out.println(_mapTransaction.get(ColumnName));
				if (_mapTransaction.get(ColumnName).equalsIgnoreCase(Columndata)) {
					ExtentCucumberAdapter.addTestStepLog("Data In WebTable is Matching "+_mapTransaction+" Matches with "+Columndata);
				}else {
					ExtentCucumberAdapter.addTestStepLog("Data In WebTable is Matching "+_mapTransaction+" NOT Matching with "+Columndata);
					softAssert.assertTrue(false, "Data In Table Is Not Matching!!");
				}
		}
	}else {
		ExtentCucumberAdapter.addTestStepLog("Data In Table Is NULL!!"+Columndata);
		softAssert.assertTrue(false, "Data In Table Is NULL!!"+Columndata);
	}
		
	}
	
	
	public static void validateDateRangeinWebTable(int seizeColumn,List<WebElement> Row_ivc,String ColumnName,String StartDate,String EndData) {
		try {
		List<HashMap<String, String>> transactionHistory = new ArrayList<HashMap<String, String>>();
		for (int i = 0; i < seizeColumn; i++) {
			HashMap<String,String> tableRow=new HashMap<String,String>();
			tableRow.put(ColumnName, Row_ivc.get(i).getText());
			DateFunction.ValidateBetweenSpecifiedRange(StartDate, EndData, Row_ivc.get(i).getText());
			transactionHistory.add(tableRow);
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
