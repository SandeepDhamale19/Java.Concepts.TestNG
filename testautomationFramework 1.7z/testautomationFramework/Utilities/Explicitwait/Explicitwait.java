/**
 * 
 */
package Explicitwait;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import DriverFactory.ThreadLocalDriver;

/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class Explicitwait {
	
	public void visibilityOfElementLocated(By by){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	
	public static void waitVisibility(WebElement ele) {
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.visibilityOf(ele));
	}
	
	public void waitElementClickable(By by){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.elementToBeClickable(by));
	}
	
	public void waitElementClickable(WebElement element){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public void waitElementStaleness(WebElement ele){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.stalenessOf(ele));
	}
	
	public void waitElementInvisibility(WebElement ele){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.invisibilityOf(ele));
	}
	
	
	public void waitElementTextNotPresent(By by, String text){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.invisibilityOfElementWithText(by, text));
	}
	
	public void waitElementTextPresent(By locator, String text,WebDriver driver){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.textToBePresentInElementValue(locator, text));
	}
	
	public void waitForPageLoad() {
		WebDriverWait wait = new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));   
	}
	public void waitNumberOfWindows(int expectedNumberOfWindows)
	{
		WebDriverWait wait = new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.numberOfWindowsToBe(expectedNumberOfWindows));
	}
	public void waitElementAttribute(WebElement element, String attribute){
		WebDriverWait wait = new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.attributeToBeNotEmpty(element, attribute));
	}
	
	public void waitElementInvisible(By by){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}
	public void waitElementInvisible(WebElement ele){
		WebDriverWait wait= new WebDriverWait(ThreadLocalDriver.getDriver(), Duration.ofSeconds(60));
		wait.until(ExpectedConditions.invisibilityOf(ele));
	}
	
}
