package DriverFactory;

import org.openqa.selenium.WebDriver;

import io.appium.java_client.android.AndroidDriver;

public class AndroidDriverInstance {
	
private static AndroidDriver _driver;
	
	public static void ResetDriver(String driver) {
		try
		{
			if(_driver!=null) {
//				Driver(driver).quit();
				_driver.quit();
				_driver = null;
			}
		}
		catch(Exception ex) {}
	}
	
//	public static AndroidDriver Driver(String driver)
//	{
//		if(_driver!=null)
//			{
//				return _driver;
//			}
//			_driver = new DriverProvider().createAndroidDriver(driver);
//			return _driver;
//	}
	
}
