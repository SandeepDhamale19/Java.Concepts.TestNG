/**
 * 
 */
package DriverFactory;

/**
 * @author Varun Paranganath
 *30/05/2023
 *testautomation-framework
 */
public class KillDriver {
	
	
	/**
	 * kill webdriver
	 */
	public KillDriver() {
		ThreadLocalDriver.getDriver().quit();
	}
	
}
