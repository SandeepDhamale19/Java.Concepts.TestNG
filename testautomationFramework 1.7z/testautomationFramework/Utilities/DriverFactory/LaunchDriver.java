/**
 * 
 */
package DriverFactory;

import java.time.Duration;

import Browserstack.Browserstackconfig;
import PropertiesfileReader.ReadValuePropertiesfile;

/**
 * @author Varun Paranganath
 *30/05/2023
 *testautomation-framework
 */
public class LaunchDriver {
	static String PropFilepath="\\config\\config.properties";
	
	public static void LaunchApplication() {
		String TestURL = ReadValuePropertiesfile.ConfigDataProvider(PropFilepath, "URL"); 
		DriverInstance.ResetDriver(); //Check if we this can be implemented in before or after scenario
		ThreadLocalDriver.setWebDriver(DriverInstance.Driver()); //Check if hooks can be implemented with in framework
		ThreadLocalDriver.getDriver().get(TestURL); // URL should be read by framework from project properties file
		ThreadLocalDriver.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		ThreadLocalDriver.getDriver().manage().window().maximize();
	}
	
	public static void LaunchApplication(String TestURL) {
		DriverInstance.ResetDriver(); //Check if we this can be implemented in before or after scenario
		ThreadLocalDriver.setWebDriver(DriverInstance.Driver()); //Check if hooks can be implemented with in framework
		ThreadLocalDriver.getDriver().get(TestURL); // URL should be read by framework from project properties file
		ThreadLocalDriver.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		ThreadLocalDriver.getDriver().manage().window().maximize();
	}
	
	public static void LaunchApplication(String TestURL,String driver) {
		DriverInstance.ResetDriver(driver); //Check if we this can be implemented in before or after scenario
		ThreadLocalDriver.setWebDriver(DriverInstance.Driver(driver)); //Check if hooks can be implemented with in framework
		ThreadLocalDriver.getDriver().get(TestURL); // URL should be read by framework from project properties file
		ThreadLocalDriver.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		ThreadLocalDriver.getDriver().manage().window().maximize();
	}
	
	
	public static void LaunchBrowserStack(String TestURL) {
		DriverInstance.ResetDriver(); //Check if we this can be implemented in before or after scenario
		ThreadLocalDriver.setWebDriver(Browserstackconfig.ChromeLaunchTest()); //Check if hooks can be implemented with in framework
		ThreadLocalDriver.getDriver().get(TestURL); // URL should be read by framework from project properties file
		ThreadLocalDriver.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		ThreadLocalDriver.getDriver().manage().window().maximize();
	}
	
	public static void LaunchAndroidApplication() {
		AndroidDriverInstance.ResetDriver("android");
		ThreadLocalAndroidDriver.setWebDriver(Browserstackconfig.launchAndroidTest());
	}
	
	public static void LaunchIOSApplication() {
		IOSDriverInstance.ResetDriver("ios");
		ThreadLocalIOSDriver.setWebDriver(Browserstackconfig.launchIOSTest());
	}
	
}
