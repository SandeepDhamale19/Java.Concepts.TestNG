package DriverFactory;

import java.util.Collections;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Platform;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;

public class DriverOptions {

	//Get Windows Chrome Options
    static ChromeOptions getWinChromeOptions() {
    	String currentPath = System.getProperty("user.dir");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("disable-infobars");
		options.addArguments("start-maximized");
		options.setExperimentalOption("excludeSwitches",
		Arrays.asList("disable-popup-blocking"));
		options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
		options.addArguments("allow-running-insecure-content");
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-gpu");
        //options.addArguments("enable-automation");
        options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
        options.setExperimentalOption("useAutomationExtension", false);
        
		/* Set Chrome Experimental Options */
		Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("download.default_directory", currentPath);
			options.setExperimentalOption("prefs", prefs);
        return options;
    }
    
  //Get Windows Chrome Options
    static ChromeOptions getHeadlessChromeOptions() {
    	
    	String currentPath = System.getProperty("user.dir");
		
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");
        options.addArguments("--disable-gpu");
        options.addArguments("enable-automation");
        options.addArguments("disable-infobars");
		options.addArguments("start-maximized");
		options.setExperimentalOption("excludeSwitches",
			    Arrays.asList("disable-popup-blocking"));
		options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
		options.addArguments("allow-running-insecure-content");
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-notifications");
        
		/* Set Chrome Experimental Options */
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("download.default_directory", currentPath);
		options.setExperimentalOption("prefs", prefs);
		
		return options;
    }

    static ChromeOptions getIncognitoChromeOptions() {
    	
    	String currentPath = System.getProperty("user.dir");
		
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        options.addArguments("--disable-gpu");
        options.addArguments("enable-automation");
        options.addArguments("disable-infobars");
		options.addArguments("start-maximized");
		options.setExperimentalOption("excludeSwitches",
			    Arrays.asList("disable-popup-blocking"));
		options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
		options.addArguments("allow-running-insecure-content");
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-notifications");
        
		/* Set Chrome Experimental Options */
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("download.default_directory", currentPath);
		options.setExperimentalOption("prefs", prefs);
		
		return options;
    }

    //Get Mac Chrome Options
    static ChromeOptions getMacChromeOptions() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("test-type");
        options.addArguments("allow-running-insecure-content");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--disable-extensions");
        options.addArguments("disable-infobars");
        options.addArguments("--disable-notifications");
        return options;
    }


    //Get IE Options
    static InternetExplorerOptions getIEOptions() {
        InternetExplorerOptions options = new InternetExplorerOptions();
//        options.setCapability(CapabilityType.PLATFORM, Platform.WINDOWS);
        options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
        options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        options.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
        options.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
        return options;
    }

    //Get Firefox Options
    static FirefoxOptions getFirefoxOptions() {
        FirefoxOptions options = new FirefoxOptions();
        
        return options;
    }
}
