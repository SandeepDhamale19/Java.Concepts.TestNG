package DriverFactory;

import org.openqa.selenium.WebDriver;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class IOSDriverInstance {
	
private static IOSDriver _driver;
	
	public static void ResetDriver(String driver) {
		try
		{
			if(_driver!=null) {
//				Driver(driver).quit();
				_driver.quit();
				_driver = null;
			}
		}
		catch(Exception ex) {}
	}
	
//	public static AndroidDriver Driver(String driver)
//	{
//		if(_driver!=null)
//			{
//				return _driver;
//			}
//			_driver = new DriverProvider().createAndroidDriver(driver);
//			return _driver;
//	}
	
}
