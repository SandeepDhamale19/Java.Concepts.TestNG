package DriverFactory;

import org.openqa.selenium.WebDriver;


public class DriverInstance {

	private static WebDriver _driver;
	
	public static void ResetDriver() {
		try
		{
			
			if(_driver!=null) {
				Driver().quit();
				_driver = null;
			}
		}
		catch(Exception ex) {}
	}
	
	public static WebDriver Driver()
	{
		if(_driver!=null)
			{
				return _driver;
			}
			_driver = new DriverProvider().Create();
			return _driver;
	}
	
	public static WebDriver Driver(String driver)
	{
		if(_driver!=null)
			{
				return _driver;
			}
			_driver = new DriverProvider().Create(driver);
			return _driver;
	}
	
	public static void ResetDriver(String driver) {
		try
		{
			if(_driver!=null) {
				Driver(driver).quit();
				_driver = null;
			}
		}
		catch(Exception ex) {}
	}
	
}
