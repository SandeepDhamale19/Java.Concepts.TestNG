package PDFFactory;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class PDFFunctions {

	public static String ReadPDFInURL(String url) throws IOException {
        //System.out.println("Enters into READ PDF");
        String output = "";
        URL urlString = new URL(url);
        //System.out.println("url :  " + url);
        InputStream is = urlString.openStream();
        BufferedInputStream fileToParse = new BufferedInputStream(is);
        PDDocument document = null;
        try {
            document = PDDocument.load(fileToParse);
            output = new PDFTextStripper().getText(document);
            /*if (output.contains(text)) {
                System.out.println("Element is matched in PDF is : " + text);
                //test.log(LogStatus.INFO, "Element is displayed in PDF " + text);
            } else {
                System.out.println("Element is not  matched in PDF");
                //test.log(LogStatus.ERROR, "Element is not displayed in PDF :: " + text);
                throw new AssertionError("Element is not displayed" + text);
            }*/
        } finally {
            if (document != null) {
                document.close();
            }
            fileToParse.close();
            is.close();
        }
        return output;
    }
	
	public static String ReadPDFLocal(String filePath) throws IOException {
	
		//Loading an existing document
	      File file = new File(filePath);
	      PDDocument document = PDDocument.load(file);

	      //Instantiate PDFTextStripper class
	      PDFTextStripper pdfStripper = new PDFTextStripper();

	      //Retrieving text from PDF document
	      String text = pdfStripper.getText(document);
	      //System.out.println(text);

	      //Closing the document
	      document.close();
	      
	      return text;
	}
	
	public static String PDFContainsText(String filePath, String subText) throws IOException {
		
		//Loading an existing document
	      File file = new File(filePath);
	      PDDocument document = PDDocument.load(file);

	      //Instantiate PDFTextStripper class
	      PDFTextStripper pdfStripper = new PDFTextStripper();

	      //Retrieving text from PDF document
	      String text = pdfStripper.getText(document);
	      //System.out.println(text);
	      
	      if (text.contains(subText)) {
	          //System.out.println("Element is matched in PDF is : " + text);
	          //test.log(LogStatus.INFO, "Element is displayed in PDF " + text);
	      } else {
	          //System.out.println("Element is not  matched in PDF");
	          //test.log(LogStatus.ERROR, "Element is not displayed in PDF :: " + text);
	          throw new AssertionError("Element is not displayed" + text);
	      }
	      
	      //Closing the document
	      document.close();
	      
	      return text;
	}
	
	public static String ReadPDFLocalAtPage(String filePath, int pageNumber) throws IOException {
		
		//Loading an existing document
	      File file = new File(filePath);
	      PDDocument document = PDDocument.load(file);

	      //Instantiate PDFTextStripper class
	      PDFTextStripper pdfStripper = new PDFTextStripper();
	      
	      pdfStripper.setStartPage(pageNumber);
	      pdfStripper.setEndPage(pageNumber);
	      //Retrieving text from PDF document
	      String text = pdfStripper.getText(document);
	      //System.out.println(text);

	      //Closing the document
	      document.close();
	      
	      return text;
	}
	
public static String ReadPDFLocalBetweenPages(String filePath, int startPageNumber, int endPageNumber) throws IOException {
		
		//Loading an existing document
	      File file = new File(filePath);
	      PDDocument document = PDDocument.load(file);

	      //Instantiate PDFTextStripper class
	      PDFTextStripper pdfStripper = new PDFTextStripper();
	      
	      pdfStripper.setStartPage(startPageNumber);
	      pdfStripper.setEndPage(endPageNumber);
	      //Retrieving text from PDF document
	      String text = pdfStripper.getText(document);
	      //System.out.println(text);

	      //Closing the document
	      document.close();
	      
	      return text;
	}
	
	public static int PDFPageCount(String filePath) throws IOException{
	
		//Loading an existing document
	      File file = new File(filePath);
	      PDDocument document = PDDocument.load(file);

	      //Instantiate PDFTextStripper class
	      PDFTextStripper pdfStripper = new PDFTextStripper();
	      
	      return pdfStripper.getEndPage();
	}
}

