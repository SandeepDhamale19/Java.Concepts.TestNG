/**
 * 
 */
package ActionsFactory;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.ThreadLocalDriver;
import Selenium.ElementProperties;

/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class WindowsFactory {
	
	String previousTab = "";
	
	private String _locator = "";
	private String _locatorType = "";
	
	
	public WindowsFactory() {
	}
	
	public WindowsFactory(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
    public void switchToTab(int position)
	{
		previousTab = ThreadLocalDriver.getDriver().getWindowHandle();
		ArrayList<String> tabs = new ArrayList<String> (ThreadLocalDriver.getDriver().getWindowHandles());
		ThreadLocalDriver.getDriver().switchTo().window(tabs.get(position));
	}
    	
	public void switchToPreviousTab()
	{
		ThreadLocalDriver.getDriver().switchTo().window(previousTab);
	}
	

	public void switchToFrameWithNameOrId(String nameOrId)
	{
		System.out.println("Switching to frame with name/id : " +nameOrId );
		ThreadLocalDriver.getDriver().switchTo().frame(nameOrId);
		JavascriptExecutorfunction.getCurrentFrameName();
	}
	
	public void switchToFrameWithIndex(int index)
	{
		System.out.println("Switching to frame with index : " +index );
		ThreadLocalDriver.getDriver().switchTo().frame(index);
		JavascriptExecutorfunction.getCurrentFrameName();
	}
	
	public void switchToFrameWithElement()
	{
		WebElement frameElement= FindElements.FindElement(_locator, _locatorType);
		System.out.println("Switching to frame with name : " + frameElement.getTagName());
		ThreadLocalDriver.getDriver().switchTo().frame(frameElement);
		JavascriptExecutorfunction.getCurrentFrameName();
	}
	
	public void switchToParentFrame(WebDriver driver)
	{
		System.out.println("Switching to previous frame");
		ThreadLocalDriver.getDriver().switchTo().parentFrame();
		JavascriptExecutorfunction.getCurrentFrameName();
	}
	
	public void switchToDefaultFrame(WebDriver driver)
	{
		System.out.println("Switching to default frame");
		ThreadLocalDriver.getDriver().switchTo().defaultContent();
		JavascriptExecutorfunction.getCurrentFrameName();
	}
	
	public String getWindowSession()
	{
		System.out.println("Switching to default frame");
		String windowsID = ThreadLocalDriver.getDriver().getWindowHandle();
		return windowsID;
	}
	
	public void SwitchToWindow()
	{
		Set<String> allWindowHandles = ThreadLocalDriver.getDriver().getWindowHandles();
        
        for(String handle : allWindowHandles)
        {
        	ThreadLocalDriver.getDriver().switchTo().window(handle);
        }
	}
	
	public void getWindowTitle(String ExpectedTitle) {
		String ActualTitle = ThreadLocalDriver.getDriver().getTitle();
		if (ActualTitle.equalsIgnoreCase(ExpectedTitle)) {
			ExtentCucumberAdapter.addTestStepLog("Title "+ActualTitle+" Matches with "+ExpectedTitle);
		}else {
			ExtentCucumberAdapter.addTestStepLog("Title "+ActualTitle+" does not matches with "+ExpectedTitle);
			Assert.fail();
		}
	}
	
	public void switchToWindow(String window) {
		ThreadLocalDriver.getDriver().switchTo().window(window);
	}
	
	public void CloseCurrentWindow(String window) {
		ThreadLocalDriver.getDriver().switchTo().window(window).close();
	}
	
}
