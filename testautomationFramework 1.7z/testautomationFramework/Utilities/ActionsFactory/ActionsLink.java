/**
 * 
 */
package ActionsFactory;

/**
 * @author Varun Paranganath
 *08/06/2023
 *testautomation-framework
 */
public class ActionsLink {

}
