/**
 * 
 */
package ActionsFactory;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import Explicitwait.Explicitwait;
import Hardwait.Hardwait;
import Selenium.ElementProperties;

/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class ValidateLabelUI {
	
	private String _locator = "";
	private String _locatorType = "";
	
	public ValidateLabelUI(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public ValidateLabelUI(String locatorType) {
		this._locatorType = locatorType;
	}
	
	
	public  void validatelabelonUI(String Expectedlabel) {
		WebElement ele = FindElements.FindElement(_locator, _locatorType);
//		try {
//			Explicitwait.waitVisibility(ele);
//			if (ele.isDisplayed()) {
				System.out.println("Label ON UI::"+ele.getText());
				if (ele.getText().equalsIgnoreCase(Expectedlabel)) {
					ExtentCucumberAdapter.addTestStepLog("Label "+ele.getText()+" Matches with "+Expectedlabel);
				}else {
					ExtentCucumberAdapter.addTestStepLog("Label "+ele.getText()+" does not matches with "+Expectedlabel);
					Assert.fail();
				}
//			}else {
//				Assert.fail(Expectedlabel +"");
//			}
//		}catch (Exception e) {
//			e.printStackTrace();
//			Assert.fail(message+" FAILED!!"+e.getStackTrace());
//		}
	}
	
//	public  void verifyLabelDisplayedonUI(String xpathUI,String message) {
//		WebElement ele = FindElements.FindElement(xpathUI, _locatorType);
//		try {
//			Explicitwait.waitVisibility(ele);
//			if (ele.isDisplayed()) {
//					ExtentCucumberAdapter.addTestStepLog(message);
//			}else {
//				Assert.fail(message+" FAILED!!");
//			}
//		}catch (Exception e) {
//			e.printStackTrace();
//			Assert.fail(message+" FAILED!!"+e.getStackTrace());
//		}
//	}
	
	
	
}
