package ActionsFactory;

import java.util.List;

import org.openqa.selenium.WebElement;

import Selenium.ElementProperties;
import io.appium.java_client.android.AndroidDriver;

/**
 * @author Varun Paranganath
 *08/06/2023
 *testautomation-framework
 */
public class LabelActions {
	
	private  String _locator = "";
	private  String _locatorType = "";
	
	public LabelActions(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public  String getLabel() {
		String label=null;
		try {
			label= FindElements.FindElement(_locator, _locatorType).getText();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return label;
	}
	
	public  String getTagName() {
		String tagName=null;
		try {
			tagName= FindElements.FindElement(_locator, _locatorType).getTagName();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return tagName;
	}
	
	public  String getAttributeName(String attributeName) {
		String tagName=null;
		try {
			tagName= FindElements.FindElement(_locator, _locatorType).getAttribute(attributeName);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return tagName;
	}
	
	
	public  boolean getLabelIsDisplayed() {
		boolean flag=false;
		try {
			flag =FindElements.FindElement(_locator, _locatorType).isDisplayed();
		}
		catch(Exception ex) {
			ex.printStackTrace();
			flag=false;
		}
		return flag;
	}
	
	
	//Android Element UI Actions //
	public  boolean androidElementgetLabelIsDisplayed() {
		boolean flag=false;
		try {
			flag =FindAndroidElements.FindElement(_locator, _locatorType).isDisplayed();
		}
		catch(Exception ex) {
			ex.printStackTrace();
			flag=false;
		}
		return flag;
	}
	
	public int androidElementSeize()	{
		int size=0;
		try {
			size = FindAndroidElements.FindElements(_locator, _locatorType).size();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return size;
	}
	
	public List<WebElement> androidElementgetIndex()	{
		List<WebElement> element =null;
		try {
			element = FindAndroidElements.FindElements(_locator, _locatorType);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return element;
	}
	
	
	//IOS Element UI Actions //
		public  boolean iosElementgetLabelIsDisplayed() {
			boolean flag=false;
			try {
				flag =FindIOSElements.FindElement(_locator, _locatorType).isDisplayed();
			}
			catch(Exception ex) {
				ex.printStackTrace();
				flag=false;
			}
			return flag;
		}
		
//		public  boolean iosElementgetLabelIsDisplayed(String _locator,String _locatorType) {
//			boolean flag=false;
//			try {
//				flag =FindIOSElements.FindElement(_locator, _locatorType).isDisplayed();
//			}
//			catch(Exception ex) {
//				ex.printStackTrace();
//				flag=false;
//			}
//			return flag;
//		}
		
		
		
		public int iosElementSeize()	{
			int size=0;
			try {
				size = FindIOSElements.FindElements(_locator, _locatorType).size();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return size;
		}
		
		public List<WebElement> iosElementgetIndex()	{
			List<WebElement> element =null;
			try {
				element = FindIOSElements.FindElements(_locator, _locatorType);
			}catch (Exception e) {
				e.printStackTrace();
			}
			return element;
		}
	
	
	
}
