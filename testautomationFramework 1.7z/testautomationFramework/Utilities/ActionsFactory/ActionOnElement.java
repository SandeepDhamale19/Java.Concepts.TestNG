/**
 * 
 */
package ActionsFactory;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import DriverFactory.ThreadLocalDriver;
import DriverFactory.WebdriverManager;
import Selenium.ElementProperties;

/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class ActionOnElement {

	private String _locator ;
	private String _locatorType ;
	
	public ActionOnElement(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public  void mouseHover(){
		Actions actions = new Actions(ThreadLocalDriver.getDriver());
		actions.moveToElement(FindElements.FindElement(_locator, _locatorType)).build().perform();
	}
	
	public  void mouseClick(){
		Actions actions = new Actions(ThreadLocalDriver.getDriver());
		actions.moveToElement(FindElements.FindElement(_locator, _locatorType)).click().build().perform();
	}
	
	public  void mouseDoubleClick(){
		Actions actions = new Actions(ThreadLocalDriver.getDriver());
		actions.moveToElement(FindElements.FindElement(_locator, _locatorType)).doubleClick().build().perform();
	}
}
