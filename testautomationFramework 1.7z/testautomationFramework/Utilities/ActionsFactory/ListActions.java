/**
 * 
 */
package ActionsFactory;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import DriverFactory.ThreadLocalDriver;

/**
 * @author Varun Paranganath
 *12/06/2023
 *testautomation-framework
 */
public class ListActions {
	
	private String _locator = "";
	
	public ListActions(String locator) {
		_locator = locator;
	}
		
	public List<WebElement> GetNoOfWebElements() {
		List<WebElement> elements = ThreadLocalDriver.getDriver().findElements(By.xpath(_locator));
	    System.out.println("Number of elements:" +elements.size());
	    return elements;
	}

	public ArrayList<String> GetListOfWebElements() {
		List<WebElement> myElements = ThreadLocalDriver.getDriver().findElements(By.xpath(_locator));
		ArrayList<String> array_List=new ArrayList<String>();
		for(WebElement e : myElements) {
			  array_List.add(e.getText());
			}
		return array_List;
	}
	
}
