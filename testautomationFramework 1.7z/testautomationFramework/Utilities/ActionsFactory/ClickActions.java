package ActionsFactory;

import java.time.Duration;
import java.util.Collections;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.testng.Assert;

import DriverFactory.ThreadLocalIOSDriver;
import Selenium.ElementProperties;

public class ClickActions {
	
	private static String _locator = "";
	private static String _locatorType = "";
	
	public ClickActions(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public static void Click() {
		try {
			FindElements.FindElement(_locator,_locatorType).click();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static Boolean IsDisplayed() {
		Boolean flag=null;
			if(FindElements.FindElements(_locator,_locatorType).size()>0) {
				flag=true;
			}else {
				flag=false;
			}
			
		return flag;
	}
	
	public static Boolean IsSelected() {
		Boolean flag=null;
		try {
			flag = FindElements.FindElement(_locator,_locatorType).isSelected();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	// Android Device UI Actions //
	public static void androidElementClick() {
		try {
			FindAndroidElements.FindElement(_locator,_locatorType).click();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static Boolean androidElementIsDisplayed() {
		Boolean flag=null;
			if(FindAndroidElements.FindElements(_locator,_locatorType).size()>0) {
				flag=true;
			}else {
				flag=false;
			}
		return flag;
	}
	
	public static Boolean androidElementIsSelected() {
		Boolean flag=null;
		try {
			flag = FindAndroidElements.FindElement(_locator,_locatorType).isSelected();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	
	// IOS Device UI Actions //
	public static void iosElementClick() {
		try {
			FindIOSElements.FindElement(_locator,_locatorType).click();
		}catch (StaleElementReferenceException e) {
			System.out.println("Caught StaleElementReferenceException!!");
		}catch (ElementNotInteractableException e) {
			System.out.println("Caught StaleElementReferenceException!!");
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static Boolean iOSElementIsEnabled() {
		Boolean flag=null;
		try {
			flag = FindIOSElements.FindElement(_locator,_locatorType).isEnabled();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	public static Boolean iOSElementIsDisplayed() {
		Boolean flag=null;
		try {
			flag = FindIOSElements.FindElement(_locator,_locatorType).isDisplayed();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	public static void tapPoint(Point point) {
	    PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
	    Sequence tap = new Sequence(finger, 1);
	    tap.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), point.getX(), point.getY()));
	    tap.addAction(finger.createPointerDown(0));
	    tap.addAction(finger.createPointerUp(0));
	    ThreadLocalIOSDriver.getDriver().perform(Collections.singletonList(tap));
	}

	public static void tapElement() {
	    Rectangle rec = FindIOSElements.FindElement(_locator,_locatorType).getRect();
	    int centerX = rec.getX() + (rec.getWidth() / 2);
	    int centerY = rec.getY() + (rec.getHeight() / 2);
	    Point elementLocation = new Point(centerX, centerY);
	    tapPoint(elementLocation);
	}
	
	
	public void iosElementClickbylabel(String label) {
		try {
			FindIOSElements.FindElement("//XCUIElementTypeStaticText[@label='"+label+"']",_locatorType).click();
		}catch (StaleElementReferenceException e) {
			System.out.println("Caught StaleElementReferenceException!!");
		}catch (ElementNotInteractableException e) {
			System.out.println("Caught StaleElementReferenceException!!");
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	
}
