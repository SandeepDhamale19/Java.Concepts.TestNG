/**
 * 
 */
package ActionsFactory;

/**
 * @author Varun Paranganath
 *12/06/2023
 *testautomation-framework
 */
public class LinkActions {

	
	
}
