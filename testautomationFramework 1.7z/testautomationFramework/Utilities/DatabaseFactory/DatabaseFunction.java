package DatabaseFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseFunction {

	// JDBC driver name and database URL 
	   static final String JDBC_DRIVER = "org.h2.Driver";   
	   //static final String DB_URL = "jdbc:h2:file:///C:/Users/sande/eclipse-workspace/TestAutomation.Database/Files/Database";  
	   //static final String DB_URL = "jdbc:h2:./Files/Database";
	   static final String DB_URL = "jdbc:h2:file:///C:/Users/sande/eclipse-workspace/TestAutomation.Selenium.Basics/Files/Database";
	   
	   //  Database credentials 
	   static final String USER = "sa"; 
	   static final String PASS = ""; 
	   	    
	   public static Connection DatabaseConnection(String jdbcDriver, String dbURL, String userName,
			   String password) throws Exception {
		   Connection dbConnection = null; 
		      
		      try { 
		         // STEP 1: Register JDBC driver 
		         Class.forName(jdbcDriver); //JDBC_DRIVER
		             
		         //STEP 2: Open a connection 
		         //System.out.println("Connecting to database..."); 
		         dbConnection = DriverManager.getConnection(dbURL, userName, password);  //DB_URL,USER,PASS
		         
		         return dbConnection;
		      }
		         catch(SQLException se) { 
			         //Handle errors for JDBC 
			         se.printStackTrace(); 
			         throw new Exception("Error while connecting to database: "+ se.getMessage());
			      } catch(Exception e) { 
			         //Handle errors for Class.forName 
			         e.printStackTrace(); 
			         throw new Exception("Error while connecting to database: "+ e.getMessage());
			      }
	   }
	   
	   
	   public static List<Map<String, Object>> ExecuteQuery(String jdbcDriver, String dbURL, String userName,
			   String password, String query) throws Exception {
		   
		         Connection dbConnection = DatabaseConnection(jdbcDriver, dbURL, userName, password);
		         Statement statement = null;
		         ResultSet result = null;
		         
		         List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		         Map<String, Object> row = null;
		         
		         try {
		         //STEP 3: Execute a query 
		         //System.out.println("Creating table in given database..."); 
		         statement = dbConnection.createStatement(); 
		         
		         String sql = query; //"SELECT First_Name FROM PUBLIC.Avengers_Characters_Info WHERE Character_Name = 'Captain America'";
		         result = statement.executeQuery(sql);
		         // System.out.println("Created table in given database..."); 
		         
		         ResultSetMetaData metaData = result.getMetaData();
		         Integer columnCount = metaData.getColumnCount();

		         while (result.next()) {
		             row = new HashMap<String, Object>();
		             for (int i = 1; i <= columnCount; i++) {
		                 row.put(metaData.getColumnName(i), result.getObject(i));
		             }
		             resultList.add(row);
		         }
		         
		         return resultList;
		         // STEP 4: Clean-up environment 
		    	  //statement.close(); 
		    	  //dbConnection.close();
		         
		      } catch(SQLException se) { 
		         //Handle errors for JDBC 
		         se.printStackTrace(); 
		         throw new Exception("Error while executing query: "+ se.getMessage());
		      } catch(Exception e) { 
		         //Handle errors for Class.forName 
		         e.printStackTrace(); 
		         throw new Exception("Error while executing query: "+ e.getMessage());
		      }finally {
		          if (result != null) try { result.close(); } catch (SQLException ignore) {}
		          if (statement != null) try { statement.close(); } catch (SQLException ignore) {}
		          if (dbConnection != null) try { dbConnection.close(); } catch (SQLException ignore) {}
		      }
		         
		   } 
	   
	   
	   public static int ExecuteUpdate(String jdbcDriver, String dbURL, String userName,
			   String password, String query) throws Exception {
		   
		         Connection dbConnection = DatabaseConnection(jdbcDriver, dbURL, userName, password);
		         Statement statement = null;
		         int result;
		         
		         try {
		         //STEP 3: Execute a query 
		         //System.out.println("Creating table in given database..."); 
		         statement = dbConnection.createStatement(); 
		         
		         String sql = query; 
		         
		         result = statement.executeUpdate(sql);
		         // System.out.println("Created table in given database..."); 
		         
		         // STEP 4: Clean-up environment 
		         statement.close(); 
		         dbConnection.close();
		         return result;
		      } catch(SQLException se) { 
		         //Handle errors for JDBC 
		         se.printStackTrace(); 
		         throw new Exception("Error while executing query: "+ se.getMessage());
		      } catch(Exception e) { 
		         //Handle errors for Class.forName 
		         e.printStackTrace(); 
		         throw new Exception("Error while executing query: "+ e.getMessage());
		      }
		         
		   } 

}
