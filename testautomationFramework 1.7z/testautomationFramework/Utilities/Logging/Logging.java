/**
 * 
 */
package Logging;
import org.apache.log4j.BasicConfigurator;
/**
 * @author Varun Paranganath
 *24/05/2023
 *testautomation-framework
 */
import org.apache.log4j.Logger;  
public class Logging {
	
	public static void setCustomLog(String LogType,String Log) {
		Logger logger = Logger.getLogger(Logging.class);
        BasicConfigurator.configure();
		switch (LogType) {
		case "info":
			 logger.info(Log);
			break;
		case "debug":
			logger.debug(Log);
			break;
		case "error":
			logger.error(Log);
			break;
		case "warn":
			logger.warn(Log);
			break;
		default:
			logger.info(Log);
			break;
		}
       
	}

	public static void main(String[] args) {
//		Logger logger = Logger.getLogger(Logging.class);
//        BasicConfigurator.configure();
		setCustomLog("info","Hello World!!");
		setCustomLog("debug","Hello World!!");
		setCustomLog("error","Hello World!!");
		setCustomLog("warn","Hello World!!");
	}
	
}
