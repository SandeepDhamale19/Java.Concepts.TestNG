package Selenium;

public class LocatorType {

	public static String ID = "ID";
    public static String NAME = "NAME";
    public static String XPATH = "XPATH";
    public static String LINKTEXT = "LINKTEXT";
    public static String CSS = "CSS";
    public static String CLASSNAME = "CLASSNAME";
    public static String TAGNAME = "TAGNAME";
}
