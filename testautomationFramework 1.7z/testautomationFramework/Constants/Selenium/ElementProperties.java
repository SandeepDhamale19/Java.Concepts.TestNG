package Selenium;

import DataFactory.StringFunction;

public class ElementProperties
{
	private static String elementName;
	
    public static String getElementName() {
    	return elementName;
    }
    
    public static void setElementName(String newElementName) {
    	newElementName = StringFunction.ToTitleCase(StringFunction.SplitTitleCase(newElementName));
    	elementName = newElementName;
    }
    
    private static String locator;
    public static String getlocator() {
    	return locator;
    }
    
    public static void setlocator(String newlocator) {
    	locator = newlocator;
    }
    
    
    private static String locatorType;
	
    public static String getlocatorType() {
    	
    	return locatorType;
    }
    
    public static void setlocatorType(String newlocatorType) {
    	
    	locatorType = newlocatorType;
    }
    
    
    private static String action;
	
    public static String getAction() {
    	
    	return action;
    }
    
    public static void setAction(String newAction) {
    	
    	action = newAction;
    }
    
    
    private static boolean displayed;
	
    public static boolean getDisplayed() {
    	
    	return displayed;
    }
    
    public static void setDisplayed(boolean newDisplayed) {
    	
    	displayed = newDisplayed;
    }
    
    
    private static boolean enabled;
	
    public static boolean getEnabled() {
    	
    	return enabled;
    }
    
    public static void setEnabled(boolean newEnabled) {
    	
    	enabled = newEnabled;
    }
    
    
    private static String tagName;
	
    public static String getTagname() {
    	
    	return tagName;
    }
    
    public static void setTagName(String newTagname) {
    	
    	tagName = newTagname;
    }
    
    
    private static String text;
	
    public static String getText() {
    	
    	return text;
    }
    
    public static void setText(String newText) {
    	
    	text = newText;
    }
    
    
    private static String browser;
	
    public static String getBrowser() {
    	
    	return browser;
    }
    
    public static void setBrowser(String newBrowser) {
    	
    	browser = newBrowser;
    }
    
    
    private static int xLocationOnPage;
	
    public static int getXLocationOnPage() {
    	
    	return xLocationOnPage;
    }
    
    public static void setXLocationOnPage(int newXLocationOnPage) {
    	
    	xLocationOnPage = newXLocationOnPage;
    }
    
    
    private static int yLocationOnPage;
	
    public static int getYLocationOnPage() {
    	
    	return yLocationOnPage;
    }
    
    public static void setYLocationOnPage(int newYLocationOnPage) {
    	
    	yLocationOnPage = newYLocationOnPage;
    }
    
    
    private static int width;
	
    public static int getWidth() {
    	
    	return width;
    }
    
    public static void setWidth(int newWidth) {
    	
    	width = newWidth;
    }
    
    
    private static int height;
	
    public static int getHeight() {
    	
    	return height;
    }
    
    public static void setHeight(int newHeight) {
    	
    	height = newHeight;
    }    

}
