package Constant;

import java.io.File;
import java.util.Properties;

public class LICConstants {
	public static final String currentPath = System.getProperty("user.dir");
	public static final String Configfilepath = currentPath+File.separator+"config"+File.separator+"applicationConfigDataENV.json";
}
