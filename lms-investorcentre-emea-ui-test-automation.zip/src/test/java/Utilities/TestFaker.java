package Utilities;

import java.io.BufferedReader;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.github.javafaker.Faker;

import DateFactory.DateFunction;

public class TestFaker {
public static void main(String[] args) {
//	Faker faker = new Faker();
//	System.out.println(faker.internet().emailAddress());
	
//	System.out.println(faker.address().streetName());
//	System.out.println(faker.address().streetAddress());
//	System.out.println(faker.address().cityName());
//	System.out.println(faker.address().city());
//	System.out.println(faker.address().country());
	
	
//	List<String> list = Arrays.asList("a", "b", "c","d","e","f");
//	Collections.shuffle(list);
//	String letter = list.stream().findAny().orElse(null);
//	System.out.println(letter);
System.gc();
//String str = "Hello World";
//StringBuilder sb1 = new StringBuilder();
//	for (int i = str.length() - 1; i >= 0; i--) {
//		char c = str.charAt(i);
//		sb1.append(c);
//	}
//	System.out.println(sb1);

//	LocalDate date=LocalDate.now();
//	String FormattedDate=date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
//	System.out.println("Foramtted: "+FormattedDate);
//	
//	LocalDate dateminusfiveYears=date.minus(5,ChronoUnit.YEARS);
//	String _FormattedDate=dateminusfiveYears.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
//	System.out.println(_FormattedDate);

//	ArrayList<Integer> _ArrYear = new ArrayList<Integer>();
//	ArrayList<Integer> _ArrMonth = new ArrayList<Integer>();
//	
//	for (int i = 2023; i <= 2023; i++) {
//		_ArrYear.add(i);
//	}
//	
//	for (int i = 1; i <= 12; i++) {
//		_ArrMonth.add(i);
//	}
//	
//for (int i = 0; i <_ArrYear.size(); i++) {
//	int year = _ArrYear.get(i);
//		for (int j = 0; j < _ArrMonth.size(); j++) {
//			int Month = _ArrMonth.get(j);
//			Calendar calender = Calendar.getInstance();
//			calender.set(year, Month,1);
//			SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
//			while (calender.get(Calendar.MONTH)==Month) {
//				Date date=calender.getTime();
//				String formattedDate =dateFormat.format(date);
//				System.out.println(formattedDate);
//				File dir = new File("C:\\Users\\VParanganath\\OneDrive - Link Group\\LIC\\LIC_Automation\\LIC_TestAutomation\\DWiseScreenshotsFolder\\"+formattedDate);
//				dir.mkdir();
//				calender.add(Calendar.DATE, 1);
//			}
//		}
//}

//	int year = 2023;
//	int Month = Calendar.OCTOBER;
//	Calendar calender = Calendar.getInstance();
//	calender.set(year, Month,1);
//	SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
//	
//	while (calender.get(Calendar.MONTH)==Month) {
//		Date date=calender.getTime();
//		String formattedDate =dateFormat.format(date);
//		System.out.println(formattedDate);
//		File dir = new File("C:\\Users\\VParanganath\\OneDrive - Link Group\\LIC\\LIC_Automation\\LIC_TestAutomation\\DWiseScreenshotsFolder\\"+formattedDate);
//		dir.mkdir();
//		calender.add(Calendar.DATE, 1);
//	}
	
//	String str = "applicationENV.json";
//	System.out.println(str.replace("ENV", "SIT"));
	
String InputPasswordValue = "varunp";
//for (int i = 0; i < 6; i++) {
//	char val = InputPasswordValue.charAt(i);
//	System.out.println(val);
//}

//System.out.println(InputPasswordValue.charAt(0));

String LastTwoYearsDate = DateFunction.getDateLastYears("dd MMM yyyy");
String TodaysDate = DateFunction.getTodaysDate("dd MMM yyyy");
System.out.println(TodaysDate);
System.out.println(LastTwoYearsDate);

  }
}
