package Utilities;

import java.util.Date;

public class TestNGParameterConfig {
	public static String browserType=null;
	public static String sitURL=null;
	public static String ExecuteOnBrowserStack=null;
	public static String Env=null;
	
	public static String getExecuteOnBrowserStack() {
		if (ExecuteOnBrowserStack!=null) {
			return ExecuteOnBrowserStack;
		}else {
			throw new RuntimeException("Browser Type is Not Specified in TestNG.xml");
		}
	}

	public static void setExecuteOnBrowserStack(String executeOnBrowserStack) {
		ExecuteOnBrowserStack = executeOnBrowserStack;
	}
	
	public static String getBrowserType() {
		if (browserType!=null) {
			return browserType;
		}else {
			throw new RuntimeException("Browser Type is Not Specified in TestNG.xml");
		}
	}

	public static void setBrowserType(String browser) {
		browserType = browser;
	}
	
	
	public static String getsitURL() {
		if (sitURL!=null) {
			return sitURL;
		}else {
			throw new RuntimeException("Browser URL is Not Specified in TestNG.xml");
		}
	}

	public static void setsitURL(String _sitURL) {
		sitURL = _sitURL;
	}
	
	public static String getEnv() {
		if (Env!=null) {
			return Env;
		}else {
			throw new RuntimeException("Env is Not Specified in TestNG.xml");
		}
	}

	public static void setEnv(String _Env) {
		Env = _Env;
	}
	
}
