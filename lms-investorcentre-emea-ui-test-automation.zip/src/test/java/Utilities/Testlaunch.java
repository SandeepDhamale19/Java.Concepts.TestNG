package Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Testlaunch {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VParanganath\\OneDrive - Link Group\\LIC\\ChromeDriver\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://ic-web-uat.emea.np.linkgroup.co.uk/Login/Login");
		try {
			Thread.sleep(10000);
		}catch (Exception e) {
			// TODO: handle exception
		}
		driver.quit();

		
		
	}
}
