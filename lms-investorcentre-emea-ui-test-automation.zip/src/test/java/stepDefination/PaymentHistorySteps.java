package stepDefination;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.internal.Debug;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import DateFactory.DateFunction;
import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalDriver;
import Hardwait.Hardwait;
import WebTableFactory.WebTableFactory;
import io.appium.java_client.AppiumBy;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.CommunicationPreferencesPage;
import pageObject.PaymentHistoryPage;

public class PaymentHistorySteps {
	
	PaymentHistoryPage paymentHistorypage=null;

	SoftAssert softAssert=new SoftAssert();

		public PaymentHistorySteps() {
			paymentHistorypage=new PaymentHistoryPage();
		}
	
	@And("I Validate Date is applied with filter From {string} to {string} for Payment History")
	public void I_Validate_Date_is_applied_with_filter(String datefrom,String dateto) throws Exception{
		String DateFrom = DateFunction.dateFormatChange(datefrom);
		String lblDateFrom = paymentHistorypage.lblFilterFrom.getTextlabel();
		Assert.assertEquals(DateFrom, lblDateFrom);
		
		String dateTo = DateFunction.dateFormatChange(dateto);
		String lblDateTo = paymentHistorypage.lblFilterTo.getTextlabel();
		Assert.assertEquals(dateTo, lblDateTo);
		
		List<WebElement> Row_date = paymentHistorypage.lblPaymentDate.GetNoOfWebElements();
		WebTableFactory.validateDateRangeinWebTable(Row_date.size(), Row_date, "Date", datefrom, dateto);
		
	}
	
	@And("I Validate table data from Payment History with {string} data {string}")
	public void I_Validate_table_data_from_Transaction_History(String ColumnName,String IVCData) {
		List<WebElement> Row_Issuer = paymentHistorypage.lblPaymentIssuer.GetNoOfWebElements();
		WebTableFactory.validateDatainWebTable(Row_Issuer.size(), Row_Issuer, "ISSUER", ColumnName);
		
		List<WebElement> ivc = paymentHistorypage.lblIVC.GetNoOfWebElements();
		WebTableFactory.validateDatainWebTable(ivc.size(), ivc, "IVC", IVCData);
		
	}
	
	@And("I Verify Pagination is available on screen")
	public void I_Verify_Pagination_is_available_on_screen() {
        List<WebElement> pagination = paymentHistorypage.listpagination.GetNoOfWebElements();
        Assert.assertTrue(pagination.size()>0);
    }

	@Then("I Select All Holding value {string} is selected By Default")
	public void I_Select_All_Holding(String lblHoldings)
	{
		Hardwait.staticWait(10000);
		String label = paymentHistorypage.selivcHolding.selectgetFirstSelectedOption();
		System.out.println("::"+label);
		Assert.assertEquals(lblHoldings, label);
	}
	
	
	@Then("I click on Payments menu in the navigational sub menu")
	public void i_click_on_payments_menu_in_the_navigational_sub_menu() {
		paymentHistorypage.androidEelementbtnPaymentcard.AndroidElementClick();
	}

	@When("I validate the labels on UI for the body of Payment History")
	public void i_validate_the_labels_on_ui_for_the_body_of_payment_history(List<Map<String,String>> portfolioDetails) {
		Hardwait.staticWait(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "paymentHistorylbl":
					paymentHistorypage.androidElementlblPaymentHistory.androiElementverifyLabelonUI(attributeValue);
					break;
				case "ViewBylbl":
					paymentHistorypage.androidElementlblviewBy.androiElementverifyLabelonUI(attributeValue);	
					break;
				case "FilterDateRangelbl":
					paymentHistorypage.androidElementlblFilterDateRange.androiElementverifyLabelonUI(attributeValue);
					break;
				case "PaymentEmptylbl":
					paymentHistorypage.androidElementlblPaymentEmptysubtitle.androiElementverifyLabelonUI(attributeValue);	
					break;
				case "VerifyTodaysDatelbl":
					String TodaysDate = DateFunction.getDateLastYears(attributeValue);
						paymentHistorypage.androidElementlblVerifytodaysdate.androiElementverifyLabelonUI(TodaysDate);
					break;
				case "Verifylast2YearsDatelbl":
					String LastTwoYearsDate = DateFunction.getTodaysDate(attributeValue);
						paymentHistorypage.androidElementlblVerifyLast2Years.androiElementverifyLabelonUI(LastTwoYearsDate);	
					break;
				case "NoRecentPaymentslbl":
						paymentHistorypage.androidElementlblNoRecentPayments.androiElementverifyLabelonUI(attributeValue);	
					break;
				case "PaymentsLast2Yearslbl":
						paymentHistorypage.androidElementlblPaymentsmakeLast2Years.androiElementverifyLabelonUI(attributeValue);	
					break;	
				case "paymentDescriptionlbl":
					paymentHistorypage.androidElementlblPaymentDescription.androiElementverifyLabelonUI(attributeValue);	
				break;	
				case "IVClbl":
					paymentHistorypage.androidElementlblIVC.androiElementverifyLabelonUI(attributeValue);	
				break;	
				case "SecurityCodelbl":
					paymentHistorypage.androidElementlblSecurityCode.androiElementverifyLabelonUI(attributeValue);	
				break;	
				case "Statuslbl":
					paymentHistorypage.androidElementlblStatus.androiElementverifyLabelonUI(attributeValue);
				break;	
				case "Typelbl":
					paymentHistorypage.androidElementlblType.androiElementverifyLabelonUI(attributeValue);
				break;	
				case "PaymentAmountlbl":
					paymentHistorypage.androidElementlblPaymentAmount.androiElementverifyLabelonUI(attributeValue);	
				break;	
				case "PaymentStmtlbl":
					paymentHistorypage.androidElementlblPaymentStatement.androiElementverifyLabelonUI(attributeValue);	
				break;	
				case "Downloadlbl":
					paymentHistorypage.androidElementlblDownload.androiElementverifyLabelonUI(attributeValue);	
				break;	
			}
		}
		
		
	}


	@Then("i select Issuer {string} on Payment History screen")
	public void i_select_issuer_on_payment_history_screen(String IssuerInput) throws Exception{
		paymentHistorypage.androidElementSelIssuerAllHoldings.AndroidElementClick();
		Thread.sleep(5000);
		paymentHistorypage.androidElementInputAllHoldings.AndroidDeviceInputvalues(IssuerInput);
		Thread.sleep(5000);
		paymentHistorypage.androidElementSelIssuer.AndroidElementClick();
	}

	@When("I Tap on Payments tab")
	public void i_tap_on_holdings_tab() {
		paymentHistorypage.iosElementPayment.IOSElementClick("Payments");
	}
	
	
	
	
	@When("I Tap on Validate Below sections in Payments Tab")
	public void I_Tap_on_Validate_Below_sections_in_Payments_Tab(List<Map<String,String>> portfolioDetails) {
		Hardwait.staticWait(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
			case "lblLastPayment":
				paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
				break;
				case "lblSecurityCode":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);	
					break;
				case "lblDate":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;
				case "lblAmount":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;
				case "lblViewpaymentHistory":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;	
				case "lblPaymentInstructions":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;	
				case "lblEdit":
					paymentHistorypage.iosElementlblEdit.iosElementgetLabelIsDisplayed();
					break;	
				case "btnViewpaymentHistory":
					paymentHistorypage.iosElementPayment.IOSElementClick(attributeValue);
					break;
				case "btnEdit":
					paymentHistorypage.iosElementbtnEdit.IOSElementClick();
					break;	
				default:
				break;
			}
		}
	}
	
	
	@When("I Tap on Validate Below sections in Payments History Tab")
	public void I_Tap_on_Validate_Below_sections_in_Payments_History_Tab(List<Map<String,String>> portfolioDetails) {
		Hardwait.staticWait(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
			case "lblpaymenthistory":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
				break;
				case "lblissuer":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);	
					break;
				case "lblregisteredholder":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;
				case "lblfilterdaterange":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;
				case "lblpaymentdescription":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;	
				case "lblsecuritycode":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;	
				case "lblstatus":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;	
				case "lbltype":
					paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;	
				case "lblpaymentamount":
					paymentHistorypage.iosElementPayment.IOSElementClick(attributeValue);
					break;	
				case "lblpaymentstatement":
					paymentHistorypage.iosElementPayment.IOSElementClick(attributeValue);
					break;	
				case "lbldownload":
						paymentHistorypage.iosElementValidatelabelPayment.iosElementgetLabelIsDisplayed(attributeValue);
					break;	
				case "lblIVC1":
					paymentHistorypage.iosElementlblIVC1.iosElementgetLabelIsDisplayed();
				break;
				case "lblIVC2":
					paymentHistorypage.iosElementlblIVC2.iosElementgetLabelIsDisplayed();
				break;
				default:
				break;
			}
		}
	}
	
	
	@When("i validate the Default Date range of past two years till system date")
	public void i_validate_the_default_date_range_of_past_years_till_system_date() {
		String LastTwoYearsDate = DateFunction.getDateLastYears("dd MMM yyyy");
		String TodaysDate = DateFunction.getTodaysDate("dd MMM yyyy");
		System.out.println(LastTwoYearsDate);
		System.out.println(TodaysDate);
		
		paymentHistorypage.iosElementLast2YearDate.iosElementverifyLabelonUI(LastTwoYearsDate);
		paymentHistorypage.iosElementTodaydate.iosElementverifyLabelonUI(TodaysDate);
	}
	
	@When("I click on download button for Payment History")
	public void i_click_on_download_button_for_payment_history() {
		paymentHistorypage.iosElementPayment.IOSElementClick("Download");
	}
	
	@Then("I Verify the PDF copy of the payment details is generated and displayed to the investor")
	public void i_verify_the_pdf_copy_of_the_payment_details_is_generated_and_displayed_to_the_investor() {
		paymentHistorypage.iosElementbtnSharePdf.IOSElementIsDisplayed();
	}
	
	
}
