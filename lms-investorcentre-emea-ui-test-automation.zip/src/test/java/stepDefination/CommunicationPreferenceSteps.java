package stepDefination;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.github.javafaker.Faker;
import com.google.common.collect.ImmutableList;

import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalDriver;
import DriverFactory.ThreadLocalIOSDriver;
import ElementsFactory.Actions;
import ElementsFactory.Select;
import Hardwait.Hardwait;
import io.appium.java_client.AppiumBy;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.AddHoldingPage;
import pageObject.CommunicationPreferencesPage;

public class CommunicationPreferenceSteps {
	
CommunicationPreferencesPage communicationPreferencesPage=null;
public static Map<String, String> sharedLabelData = new HashMap<String, String>();

SoftAssert softAssert=new SoftAssert();

	public CommunicationPreferenceSteps() {
		communicationPreferencesPage=new CommunicationPreferencesPage();
	}
	
	@Then("I click on Radio Button in Email Address Other")
	public void I_click_on_Radio_Button_in_Email_Address_Other() {
		communicationPreferencesPage.rbtnEmailAddress.Click();
	}
	
	@And("I Enter values in Email Address for Other Communication Preferences")
	public void I_Enter_values_in_Email_Address_for_Other_Communication_Preferences() {
		Faker faker = new Faker();
		String emailAddress = faker.address().firstName()+"@gmail.com";
		communicationPreferencesPage.txtEmailAddress.ClearInputvalues();
		communicationPreferencesPage.txtEmailAddress.Inputvalues(emailAddress);
		ExtentCucumberAdapter.addTestStepLog("Email Address added in Communication Preferences "+emailAddress);
	}
	
	@Then("I click on Next button")
	public void I_click_on_Next_button() {
		communicationPreferencesPage.btnNext.Click();
	}
	
	@Then("I click on Back button")
	public void I_click_on_Back_button() {
		communicationPreferencesPage.btnbackButton.Click();
	}
	
	@And("I Confirm the Communication Preferences")
	public void I_Confirm_the_Communication_Preferences() {
		communicationPreferencesPage.btnConfirm.Click();
	}
	
	@Then("I Validate Label {string} for Comm Pref")
	public void I_Validate_Label(String lblConCommPref) {
		communicationPreferencesPage.lblCommPref.verifyLabelonUI(lblConCommPref);
	}
	
	@Then("I Validate Label2 {string} for comm pref")
	public void I_Validate_Label2(String lblConCommPref) {
		communicationPreferencesPage.lblPleaseConfirm.verifyLabelonUI(lblConCommPref);
	}
	
	@Then("I selected radio button from show other options on communication page and when entered other email those will be displayed like {string} , {string} , {string} , {string} , {string} , {string}")                                
	public void I_selected_radio_button_from_show_other_options_on_communication_page(String lblMethod , String lblAllComm , String lblAllplyTo , String lblIssuer,String lblIVC, String lblHolderName) {
		communicationPreferencesPage.lblmethod.verifyLabelonUI(lblMethod);
		communicationPreferencesPage.lblAllCommElectroncally.getLabelIsDisplayed();
		communicationPreferencesPage.lblApplyTo.verifyLabelonUI(lblAllplyTo);
		communicationPreferencesPage.lblIssuer.verifyLabelonUI(lblIssuer);
		communicationPreferencesPage.lblIVC.verifyLabelonUI(lblIVC);
		communicationPreferencesPage.lblHolderName.verifyLabelonUI(lblHolderName);
		communicationPreferencesPage.btnbackButton.IsDisplayed();
		communicationPreferencesPage.btnConfirm.IsDisplayed();
	}
	
	@And("I Select Check Box Select other holdings to apply this update to")
	public void I_Select_Check_Box_Select_other_holdings_to_apply() throws Exception {
		Hardwait.staticWait(5000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		
		robot.keyPress(KeyEvent.VK_SPACE);
		robot.keyRelease(KeyEvent.VK_SPACE);

	}
	
	@And("I Check Both the radio Button Should Be hidden when i click on Select other holdings to apply this update to")
	public void I_Check_Both_the_radio_Button_Should_Be_hidden_when() {
		Boolean chkBox1Flag1 = communicationPreferencesPage.rdbtnotherHoldingsPadradioListradioListSlim1.IsDisplayed();
		softAssert.assertEquals(true, chkBox1Flag1);
		
		Boolean chkBox1Flag2 = communicationPreferencesPage.rdbtnotherHoldingsPadradioListradioListSlim2.IsDisplayed();
		softAssert.assertEquals(true, chkBox1Flag2);
		
	}
	
	@Then("I validate label Apply this update to all available holdings {string}")
	public void I_validate_label_Apply_this_update_to_all_available_holdings(String lblApplyHolding) {
		Hardwait.staticWait(5000);
		if(communicationPreferencesPage.lblApplyToAllHoldings_1.getLabelIsDisplayed()==true) {
			communicationPreferencesPage.lblApplyToAllHoldings_1.verifyLabelonUI(lblApplyHolding);
		}
	}
	
	
	@Then("I validate click on Apply this update to all available holdings")
	public void I_validate_CLick_Apply_this_update_to_all_available_holdings() {
		Hardwait.staticWait(5000);
		if(communicationPreferencesPage.lblApplyToAllHoldings_1.getLabelIsDisplayed()==true) {
			communicationPreferencesPage.btnApplyToAllHoldings_1.Click();
		}
	}
	
	
	@Then("I validate label Individually select the holdings to apply this update to {string}")
	public void I_validate_label_Individually(String lblApplyHoldingIndividually) {
		Hardwait.staticWait(2000);
		communicationPreferencesPage.lblApplyToAllHoldings_2.verifyLabelonUI(lblApplyHoldingIndividually);
	}
		 
	@And("I Validate whether radio button Individually select the holdings to apply this update to is selected by default")
	public void I_Validate_whether_radio_button_Individually_select_the_holdings_to_apply_this_update_to_is_selected_by_default() {
		String lblchecked = communicationPreferencesPage.lblApplyToAllHoldings_2chk.getAttributeName("checked");
		Assert.assertEquals("true", lblchecked);
		
	}
	
	
	
	@Then("I Select All Holding value {string}")
    public void I_Select_All_Holding_value(String txtHoldingName) throws Throwable {
		Hardwait.staticWait(8000);
		if (communicationPreferencesPage.lnkAllHoldingPath.GetListOfWebElements().size()>0) {
			communicationPreferencesPage.selAllHolding.selectByVisibleText(txtHoldingName);
		}
		Hardwait.staticWait(8000);
    }
	
	@Then("I Select All Holding value {string} and validate if Custom holding is deleted")
	public void validateifCustomholdingisdeleted(String checkDropDownElement) {
		Boolean checkflag=null;
		if (communicationPreferencesPage.lnkAllHoldingPath.GetListOfWebElements().size()>0) {
			checkflag = communicationPreferencesPage.selAllHolding.CheckElementExistsInDropDown(checkDropDownElement);
		}
		
		Assert.assertEquals(true, checkflag);
	}
	
	
	
	@And("I Check If Select other holdings to apply this update to is Selected By Default")
	public void I_Select_All_Holding_value() {
		Boolean chkFlag = communicationPreferencesPage.chkIsShowOtherHoldings.IsSelected();
		softAssert.assertEquals(true, chkFlag);
	}
	
	
	@Then("I Enter Invalid Email Address for Other field Communication Preferences {string}")
	public void I_Enter_Invalid_Email_Address_for_Other_field_Communication_Preferences(String txtEmailAddress) throws Throwable {
		communicationPreferencesPage.txtEmailAddress.Inputvalues(txtEmailAddress);
	}
	
	@And("I validate Error Message On screen for Invalid Email Address {string}")
	public void I_validate_Error_Message_On_screen_for_Invalid_Email_Address(String lblEmailAddressErrorMsg) throws Throwable {
		communicationPreferencesPage.lblEmailAddressError.verifyLabelonUI(lblEmailAddressErrorMsg);
	}
	
	@And("I Validate Note lable on screen {string}") 
	public void I_Validate_Note_lable_on_screen(String lblNote) throws Throwable {
		communicationPreferencesPage.lblNote.verifyLabelonUI(lblNote);
	}
	
	@Then("I validate Instructional Text 5 {string}")
	public void I_validate_Instructional_Text5(String lblInstructionalText) {
//		communicationPreferencesPage.lblInstructionalText5.verifyLabelonUI(lblInstructionalText);
		
		String InstructionalText5 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//div[@id='viewBarDetails']/p)[1]")).getText();
		System.out.println(InstructionalText5);
		softAssert.assertEquals(InstructionalText5, lblInstructionalText);
		
	}
	
	@Then("I validate Instructional Text 6 {string}")
	public void I_validate_Instructional_Text6(String lblInstructionalText) {
//		communicationPreferencesPage.lblInstructionalText6.verifyLabelonUI(lblInstructionalText);
		String InstructionalText5 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//div[@id='viewBarDetails']/p)[2]")).getText();
		System.out.println(InstructionalText5);
	}
	
	@Then("Validate Success message {string} On Communication Preferences page")
	public void validate_success_message_on_Communication_Preferences_page(String sucessMessage) {
		communicationPreferencesPage.lblCommunicationPreferences.verifyText(sucessMessage);
	}
	
//	@Then("Validate Success message {string} On Manage holdings page")
//	public void validate_success_message_on_Manage_Holdings_page(String sucessMessage) {
//		communicationPreferencesPage.lblCommunicationPreferences.verifyText(sucessMessage);
//	}
	
	
	@When("I get all the values of label to validate the List View")
	public void i_get_all_the_values_of_label_to_validate_the_list_view() {
		int size = communicationPreferencesPage.androidElementListlbl.androidElementgetSize();
		int sizeElement = communicationPreferencesPage.androidElementListIndividualHoldings.androidElementgetSize();
			for (int j = 1; j <=sizeElement-1; j++) {
					String label = communicationPreferencesPage.androidElementListIndividualHoldings.androidElementgetIndex().get(j).getText();
					System.out.println(label);
					sharedLabelData.put("1Element"+j, label);
			}
			
			for(Map.Entry<String, String> element : sharedLabelData.entrySet()) {
				System.out.println(element.getKey() + "=" + element.getValue());
			}
	}
	
	@When("I Validate Individual Holdings Labels on Communication Prefernce	Screen")
	public void I_Validate_Individual_Holdings_Labels_on_Communication_Prefernce_Screen(List<Map<String, String>> updateSettings)
			throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : updateSettings) {
			System.out.println(
					CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeValue = CommunicationPreference.get("AttributeValue");
			String attributeName = CommunicationPreference.get("AttributeName");
			switch (attributeName) {
			case "1Element1":
					Assert.assertEquals(attributeValue, communicationPreferencesPage.androidElementListIndividualHoldings.androidElementgetIndex().get(1).getText());	
				break;
			case "1Element3":
					Assert.assertEquals(attributeValue, communicationPreferencesPage.androidElementListIndividualHoldings.androidElementgetIndex().get(3).getText());
				break;
			case "1Element5":
					Assert.assertEquals(attributeValue, communicationPreferencesPage.androidElementListIndividualHoldings.androidElementgetIndex().get(5).getText());
				break;
			case "1Element6":
				    Assert.assertEquals(attributeValue, communicationPreferencesPage.androidElementListIndividualHoldings.androidElementgetIndex().get(6).getText());
				break;	
			}
		}
	}
	
//	@When("Then I click on toggle button on communication Preference screen")
//	public void then_i_click_on_toggle_button_on_communication_preference_screen() {
//		int size = communicationPreferencesPage.androidElementListToggleButton.androidElementgetSize();
//		for (int i = 1; i <=size-1; i++) {
//			System.out.println(communicationPreferencesPage.androidElementListToggleButton.androidElementgetIndex().get(i).getAttribute("checked")+"::"+i);
//			if (communicationPreferencesPage.androidElementListToggleButton.androidElementgetIndex().get(i).getAttribute("checked").equalsIgnoreCase("false")) {
//				communicationPreferencesPage.androidElementListToggleButton.androidElementgetIndex().get(i).click();
//			}
//		}
//	}
	
	@When("I Validate Labels on Communication Preference Screen IOS")
	public void I_Validate_Labels_on_Communication_Preference_Screen_IOS(List<Map<String, String>> holdingSettings)
			throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : holdingSettings) {
			System.out.println(
					CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeValue = CommunicationPreference.get("AttributeValue");
			String attributeName = CommunicationPreference.get("AttributeName");
			switch (attributeName) {
			case "lblHoldingSettings":
					communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed();
				break;
			case "lblHolding2Settings":
				communicationPreferencesPage.iosElementlblHoldings2.iosElementgetLabelIsDisplayed();
			break;	
			case "lblCommunicationPrefernces":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
				break;
			case "lblMethodOfCommunication":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
				break;
			case "lblYourcurrentCommunicationPreferncesisAllCommunicationElectronically":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
				break;
			case "lblEmailSentTo":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;	
			case "lblApplytoAllHoldings":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;	
			case "lblApplytoIndividualHoldings":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;	
			case "lblNoteSections":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;	
			case "lblUpdate":
				communicationPreferencesPage.action.IOSScrollDown();
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblDefaultEmail":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblOther":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			default:
				break;
			}
		}
	}
	
	
//	public static void IOSScrollUp() {
//		Dimension size = ThreadLocalIOSDriver.getDriver().manage().window().getSize();
//		
//		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 
//		
//		int bottom=midPoint.y - (int)(midPoint.y*0.75);
//		
//		int top=midPoint.y + (int)(midPoint.y*0.75);
//		Point start = new Point(midPoint.y,top);
//		Point end = new Point(midPoint.y,bottom);
//		
//		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
//		Sequence scroll = new Sequence(indexFinger, 0);
//		
//		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), end.y, end.x));
//		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
//		
//		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), start.x, start.y));
//		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
//		
//		ThreadLocalIOSDriver.getDriver().perform(ImmutableList.of(scroll));
//		System.out.println();
//	}
	
	
	@When("I Validate Labels on Address Details Screen IOS")
	public void I_Validate_Labels_on_Address_Details_Screen_IOS(List<Map<String, String>> holdingSettings)
			throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : holdingSettings) {
			System.out.println(
					CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeName = CommunicationPreference.get("AttributeName");
			String attributeValue = CommunicationPreference.get("AttributeValue");
			switch (attributeName) {
			case "lblHoldingSettings":
//					communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed();
					communicationPreferencesPage.action.IOSScrollDown();
					Hardwait.staticWait(5000);
//					IOSScrollUp();
				break;
			case "lblEnteryouraddressdetails":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblWithinUKIreland":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblOutsideUKIreland":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblStreetAddress":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblPostCode":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "ActoionScrollDown":
				communicationPreferencesPage.action.IOSScrollDown();
			break;
			case "lblUpdateSettings":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblApplytoallholdings":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblNoteSomeINfo":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblApplytoindividualholding":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblToSeeAllHoldings":
				communicationPreferencesPage.iosElementlblHoldings.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "ActoionScrollUp":
				communicationPreferencesPage.action.IOSScrollUp();
			break;

			
			default:
				break;
			}
		}
	}
	
	
	
	@When("I Enter values on Communication Preference Screen IOS")
	public void I_EnterValues_on_Communication_Preference_Screen_IOS(List<Map<String, String>> holdingSettings)
			throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : holdingSettings) {
			System.out.println(CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeName = CommunicationPreference.get("AttributeName");
			String attributeValue = CommunicationPreference.get("AttributeValue");
			switch (attributeName) {
			case "SelectIndividualHolding":
					communicationPreferencesPage.iosElementSelViewByDropDown.IOSElementClick();
					communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "CheckBoxOther":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "CheckBoxEmail":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "EnterEmailOther":
				communicationPreferencesPage.iosElementtxtEmailAddress.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtEmailAddress.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "BtnUpdate":
				communicationPreferencesPage.action.IOSScrollDown();
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "ToggleApplytoallholdings":
				communicationPreferencesPage.iosElementToggleApplytoAllHoldings.IOSElementClick();
			break;
			case "ToggleApplytoIndividualholdings":
				communicationPreferencesPage.iosElementToggleApplytoIndividualHoldings.IOSElementClick();
			break;
			case "lblOneHoldings":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			default:
				break;
			}
		}
	}

	
	
	
	
	@When("I Validate the Communication preferences Confirm Screen with below Labels")
	public void I_Validate_the_Communication_preferences_Confirm_Screen_with_below_Labels(List<Map<String, String>> holdingSettings) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : holdingSettings) {
			System.out.println(CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeName = CommunicationPreference.get("AttributeName");
			String attributeValue = CommunicationPreference.get("AttributeValue");
			switch (attributeName) {
			case "lblCommunicationPreferences":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "lblPleaseconfirmthatyouwishtoproceedwiththefollowingupdate":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "lblMethod":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "lblEmailID":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "lblAddress":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "lblAllcommunicationselectronically":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
				break;	
			case "lblApplyto":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
				break;	
			case "lblIVC":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
				break;	
			case "lblRegisteredHolder":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
				break;	
			case "lblIssuer":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
				break;	
			case "lblConfirm1":
				communicationPreferencesPage.iosElementlblConfirm1.iosElementgetLabelIsDisplayed();
				break;	
			case "btnConfirm":
				communicationPreferencesPage.iosElementlblConfirm.IOSElementClick();
				Hardwait.staticWait(50000);
				break;	
			
			default:
				break;
			}
		}
	}
	
	@When("I Validate Success screen for Communication Preference Screen for IOS")
	public void I_Validate_Success_screen_for_Communication_Preference_Screen_for_IOS(List<Map<String, String>> holdingSettings) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : holdingSettings) {
			System.out.println(CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeName = CommunicationPreference.get("AttributeName");
			String attributeValue = CommunicationPreference.get("AttributeValue");
			switch (attributeName) {
			case "lblSuccess":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "lblCommunicationPreferencesSuccessfullyUdpated":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "btnDone":
				communicationPreferencesPage.iosElementbtnDone.IOSElementClick();
			break;
			default:
				break;
			}
		}
	}
	
	@When("I Tap on Communication Preferences tab")
	public void i_tap_on_CommunicationPreferences_tab() {
		communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick("Communication");
	}
	
	@When("I Validate Values on Communication Preference Tab Screen IOS")
	public void I_Validate_Values_on_Communication_Preference_Tab_Screen_IOS(List<Map<String, String>> holdingSettings)
			throws Exception {
		Thread.sleep(15000);
		for (Map<String, String> CommunicationPreference : holdingSettings) {
			System.out.println(CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeName = CommunicationPreference.get("AttributeName");
			String attributeValue = CommunicationPreference.get("AttributeValue");
			switch (attributeName) {
			case "lblCommunicationOptions":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblEmailID":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblCommunicationElectronically":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblAddressDetails":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "lblEdit1":
				communicationPreferencesPage.iosElementlblEdit1.iosElementgetLabelIsDisplayed();
			break;
			case "lblEdit2":
				communicationPreferencesPage.iosElementlblEdit2.iosElementgetLabelIsDisplayed();
			break;
			}
		}
	}
	
	@When("I Tap on Edit button of communication options section")
	public void i_tap_on_edit_button_of_communication_options_section() {
	   communicationPreferencesPage.iosElementbtnEdit1.IOSElementClick();
	}
	
	@When("I Tap on Edit button of Address details options section")
	public void i_tap_on_edit_button_of_Address_details_section() {
	   communicationPreferencesPage.iosElementbtnEdit2.IOSElementClick();
	}
	
	@When("I {string} on Holding settings screen IOS")
	public void i_click_here_to_individually_select_the_holdings_to_apply_this_update(String lblClickHereIndividually) {
		communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(lblClickHereIndividually);
	}
	
	@Then("I click on the toggle button for Individual Holding")
	public void i_click_on_the_toggle_button_for_individual_holding() {
		communicationPreferencesPage.iosElementToggleApplytoAllHoldings.IOSElementClick();
	}
	
	@Then("I click on {string} on Communication Preferences for Individual Holding")
	public void i_click_on_on_communication_preferences_for_individual_holding(String lblApply) {
		communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(lblApply);
	}
	
	
	@When("I Enter values on Communication Preference Address Screen IOS")
	public void I_EnterValues_on_Communication_PreferenceAddress_Screen_IOS(List<Map<String, String>> holdingSettings)
			throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : holdingSettings) {
			System.out.println(CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeName = CommunicationPreference.get("AttributeName");
			String attributeValue = CommunicationPreference.get("AttributeValue");
			switch (attributeName) {
			case "SelectIndividualHolding":
					communicationPreferencesPage.iosElementSelViewByDropDown.IOSElementClick();
					communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "RadioBtnWithInUKOther":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "RadioBtnOutSideUKOther":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "EnterAddressLine1":
				communicationPreferencesPage.iosElementtxtAddressLine1.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtAddressLine1.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "EnterAddressLine2":
				communicationPreferencesPage.iosElementtxtAddressLine2.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtAddressLine2.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "EnterAddressLine3":
				communicationPreferencesPage.iosElementtxtAddressLine3.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtAddressLine3.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "EnterAddressLine4":
				communicationPreferencesPage.iosElementtxtAddressLine4.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtAddressLine4.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "EnterAddressLine5":
				communicationPreferencesPage.iosElementtxtAddressLine5.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtAddressLine5.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "EnterAddressLine6":
				communicationPreferencesPage.iosElementtxtAddressLine6.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtAddressLine6.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "CheckBoxOther":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "CheckBoxEmail":
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "EnterEmailOther":
				communicationPreferencesPage.iosElementtxtEmailAddress.IOSDeviceClearInputvalues();
				communicationPreferencesPage.iosElementtxtEmailAddress.IOSDeviceInputvalues(attributeValue);
				communicationPreferencesPage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "BtnUpdate":
				communicationPreferencesPage.action.IOSScrollDown();
				communicationPreferencesPage.iosElementSelectByTextValue.IOSElementClick(attributeValue);
			break;
			case "ToggleApplytoallholdings":
				communicationPreferencesPage.iosElementToggleApplytoAllHoldings.IOSElementClick();
			break;
			case "ToggleApplytoIndividualholdings":
				communicationPreferencesPage.iosElementToggleApplytoIndividualHoldings.IOSElementClick();
			break;
			case "lblOneHoldings":
				communicationPreferencesPage.iosElementlblValidateLabel.iosElementgetLabelIsDisplayed(attributeValue);
			break;
			case "ActoionScrollDown":
				communicationPreferencesPage.action.IOSScrollDown();
			break;
			default:
				break;
			}
		}
	}
	
}
