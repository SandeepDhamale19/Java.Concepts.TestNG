package stepDefination;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bouncycastle.jcajce.provider.digest.GOST3411.HashMac;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.github.dockerjava.core.WebTarget;

import DateFactory.DateFunction;
import DriverFactory.ThreadLocalDriver;
import Hardwait.Hardwait;
import ScreenshotFactory.TakeScreenshot;
import Utilities.TestNGParameterConfig;
import WebTableFactory.WebTableFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.ManagePortfolioPage;
import pageObject.TransactionHistoryPage;

public class TransactionHistorySteps {
	
	TransactionHistoryPage transactionHistoryPage=null;
	
	public TransactionHistorySteps() {
		transactionHistoryPage = new TransactionHistoryPage();
	}
	
	
	@Then("I click On Go")
	public void I_click_On_Go() {
		transactionHistoryPage.btnGo.Click();
	}
	
	@And("I Select Date Range From {string} to {string}")
	public void I_Select_Date_Range_From(String datefrom,String dateto) throws Exception {
		transactionHistoryPage.txtDateFrom.ClearInputvalues();
		transactionHistoryPage.txtDateFrom.Inputvalues(datefrom);
		
		transactionHistoryPage.txtDateTo.ClearInputvalues();
		transactionHistoryPage.txtDateTo.Inputvalues(dateto);
	}
	
	@And("I Validate Date is applied with filter From {string} to {string}")
	public void I_Validate_Date_is_applied_with_filter(String datefrom,String dateto) throws Exception{
		String DateFrom = DateFunction.dateFormatChange(datefrom);
		String lblDateFrom = transactionHistoryPage.lblFilterFrom.getTextlabel();
		Assert.assertEquals(DateFrom, lblDateFrom);
		
		String dateTo = DateFunction.dateFormatChange(dateto);
		String lblDateTo = transactionHistoryPage.lblFilterTo.getTextlabel();
		Assert.assertEquals(dateTo, lblDateTo);
		
		List<WebElement> Row_date = transactionHistoryPage.lblDateColumn.GetNoOfWebElements();
		WebTableFactory.validateDateRangeinWebTable(Row_date.size(), Row_date, "Date", datefrom, dateto);
		
		
		
	}
	
	@And("I Validate table data from Transaction History with date range from {string} to {string} with {string} data {string}")
	public void I_Validate_table_data_from_Transaction_History(String datefrom,String dateto,String ColumnName,String IVCData) {
		List<WebElement> Row_ivc = transactionHistoryPage.lblIVCColumn.GetNoOfWebElements();
		WebTableFactory.validateDatainWebTable(Row_ivc.size(), Row_ivc, ColumnName, IVCData);
	}
	
	
	@And("I Validate SecurityDropDown filter with Table Data")
	public void I_Validate_SecurityDropDown_filter_with_Table_Data() {
		Select select = new Select(ThreadLocalDriver.getDriver().findElement(By.xpath("//*[@id='SecurityCode']")));
    	List <WebElement> op = select.getOptions();
    	int size = op.size();
    	for(int i =0; i<size ; i++){
            String options = op.get(i).getText();
            select.selectByVisibleText(options);
            if (!options.equalsIgnoreCase("All Securities")) {
            	Hardwait.staticWait(10000);
            	List<WebElement> Row_securityCode = transactionHistoryPage.lblSecurityCode.GetNoOfWebElements();
        		WebTableFactory.validateDatainWebTable(Row_securityCode.size(), Row_securityCode, "SecurityCode", options);
			}
         }
	}
	
	@Then("I Validate Date range From {string} and To {string} is displayed")
	public void IValidateDateRangefromTransaction(String lblDateFrom,String lblDateTo) {
		transactionHistoryPage.lblTransactionDateFrom.verifyLabelonUI(lblDateFrom);
		transactionHistoryPage.lblTransactionDateTo.verifyLabelonUI(lblDateTo);
//		transactionHistoryPage.lblDisplayTransactionHistory.verifyLabelonUI("Displaying Transaction History from 21 Sep 2021 to 21 Sep 2023");
	}
	
	@Then("I Validate label as {string}")
	public void IValidateLabel(String lbl) {
        transactionHistoryPage.lblView.verifyLabelonUI(lbl);
    }
	
}
