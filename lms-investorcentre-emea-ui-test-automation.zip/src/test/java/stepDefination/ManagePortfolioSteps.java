package stepDefination;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import DriverFactory.ThreadLocalDriver;
import Hardwait.Hardwait;
import ScreenshotFactory.TakeScreenshot;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pageObject.AddHoldingPage;
import pageObject.LoginPage;
import pageObject.ManagePortfolioPage;

public class ManagePortfolioSteps {
	
	ManagePortfolioPage managePortfolio=null;
	AddHoldingPage addHoldingPage=null;
	public ManagePortfolioSteps() {
		managePortfolio=new ManagePortfolioPage();
		addHoldingPage=new AddHoldingPage();
	}

	@And("I Verify Landing on {string}")
    public void When_the_user_is_clicking_on_Manage_Holding_Button(String lblPortfolio) {
		Hardwait.staticWait(5000);
		managePortfolio.lblManagePortfolio.validatelabelonUI(lblPortfolio);
    }

	
	@Then("I Remove Holding for IVC {string}")
	public void i_remove_holding_for_ivc(String string) {
		Hardwait.staticWait(5000);
		managePortfolio.btnRemove.Click();
	}
	
	@And("Validate If you are sure you wish to remove this IVC and associated holdings from your web account")
	public void Validate_If_you_are_sure_you_wish_to_remove_this_IVC() {
		Hardwait.staticWait(5000);
		managePortfolio.btnConfirm.Click();
	}
	
	
	@Then("Validate Success message {string} On Manage holdings page")
	public void validate_success_message_on_manage_holdings_page(String sucessMessage) {
		managePortfolio.lblSuccessMessage.verifyText(sucessMessage);
	}
	
	@Then("I Validate the holdings from Manage portfolio")
	public void I_Remove_the_holdings_from_Manage_portfolio(List<Map<String,String>> tableIVC) {
		Hardwait.staticWait(3000);
		List<WebElement> portfolioElements = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr"));
		ArrayList<String> ob_lblIVC = new ArrayList<String>();
		
		for (int i = 0; i < portfolioElements.size(); i++) {
			String lblIVC = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr/td[2]")).get(i).getText();
			String lblRegisteredDetails = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr/td[3]")).get(i).getText();
			String lblAction = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr/td[5]")).get(i).getText();
			System.out.println(lblIVC+"\t"+lblRegisteredDetails+"\t"+lblAction);
			ob_lblIVC.add(lblIVC);
		}
		
		ArrayList<String> ob_testIVC = new ArrayList<String>();
		for(Map<String, String> dataIVC:tableIVC) {
			ob_testIVC.add(dataIVC.get("IVC"));
		}
		
		Boolean FlagTest = false;
		if (ob_lblIVC.equals(ob_testIVC)) {
			FlagTest=true;
		}
		
		if (!FlagTest) {
			Assert.fail("Holdings Added is not matching with the Manage Holding Data");
		}
		
	}

	@Then("I Validate to remove the holdings from Manage portfolio")
	public void I_Validate_to_remove_the_holdings_from_Manage_portfolio(List<Map<String,String>> tableIVC) {
		Hardwait.staticWait(3000);
		int i=0;
		for(Map<String, String> dataIVC:tableIVC) {
			
			Hardwait.staticWait(3000);
			 if(addHoldingPage.btnlstManageHolding.GetNoOfWebElements().size()>0) {
		        	addHoldingPage.btnManageHoldings.Click();
				}
			 
//			 if (ThreadLocalDriver.getDriver().findElement(By.xpath("//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr/td[2]")).getText().equalsIgnoreCase(dataIVC.get("IVC"))) {
				 if(ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr/td[text()='"+dataIVC.get("IVC")+"']")).size()>=0) {
						ThreadLocalDriver.getDriver().findElement(By.xpath("(//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr/td/a[text()='Remove'])['"+i+"']")).click();
						Hardwait.staticWait(1000);
						managePortfolio.btnConfirm.Click();
						Hardwait.staticWait(1000);
						managePortfolio.lblSuccessMessage.verifyText("Holdings successfully removed from your web account.");
						Hardwait.staticWait(1000);
						managePortfolio.btnBackToPortfolio.Click();
						Hardwait.staticWait(1000);
						i++;
					}else {
						System.out.println("Element Not Found!! "+"//table[@aria-labelledby='gbox_PortfolioGrid']/tbody/tr/td[text()='"+dataIVC.get("IVC")+"']");
					}
			 }
			
//		}
	}
	
	
	@Then("I Validate Dropdown list with label as {string}")
	public void I_Validate_DropDownListtest(String lblView) {
		managePortfolio.lblView.verifyLabelonUI(lblView);
		new TakeScreenshot();
	}
	
	@And("I Validate Label with Instrctional Text1 {string}")
	public void I_Validate_InstrctionalText1(String lblInstractionalText1) {
		managePortfolio.lblInstructionalText1.verifyLabelonUI(lblInstractionalText1);
	}
	
	
	@And("I Validate Label with Instrctional Text2 {string}")
	public void I_Validate_InstrctionalText2(String lblInstractionalText2) {
		managePortfolio.lblInstructionalText2.verifyLabelonUI(lblInstractionalText2);
	}

	@And("I Validate Label with Instrctional Text3 {string}")
	public void I_Validate_InstrctionalText3(String lblInstractionalText3) {
		managePortfolio.lblInstructionalText3.verifyLabelonUI(lblInstractionalText3);
	}
	
	@And("Validate Label {string}")
	public void ValidateLabelRemoveThisIVC(String lblAreyouSure) {
		managePortfolio.lblInstructionalText4.verifyLabelonUI(lblAreyouSure);
	}
	
	@Then("I Validate column name {string} and {string}")
	public void ValidateColumnsNamesIVCResgisteredHoldingName(String lblIVC , String lblRegisteredHolderName) {
		managePortfolio.lblIVC.verifyLabelonUI(lblIVC);
		managePortfolio.lblPegisteredHolding.verifyLabelonUI(lblRegisteredHolderName.trim());
	}
	
	
	@Then("I Validate column Values {string} and {string}")
	public void ValidateColumnsValuesIVCResgisteredHoldingName(String lblIVCvalue , String lblRegisteredHolderNamevalue) {
		managePortfolio.lblIVCvalue.verifyLabelonUI(lblIVCvalue);
		managePortfolio.lblPegisteredHoldingvalue.verifyLabelonUI(lblRegisteredHolderNamevalue);
	}
	
	
	@And("I Validate Instruction {string}")
	public void I_Validate_Instruction(String lblInstruction) {
        managePortfolio.lblInstraction.verifyLabelonUI(lblInstruction);
    }
	
	@And("I click On Cancel")
	public void I_Click_on_cancel() {
        managePortfolio.btnCancel.Click();
    }
	
	
	
}
