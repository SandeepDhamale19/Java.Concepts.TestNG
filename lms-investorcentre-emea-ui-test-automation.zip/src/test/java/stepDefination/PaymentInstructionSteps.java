package stepDefination;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.github.javafaker.Faker;
import com.google.common.collect.ImmutableList;

import DriverFactory.ThreadLocalIOSDriver;
import Hardwait.Hardwait;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.PaymentInstructionsPage;

public class PaymentInstructionSteps {

	PaymentInstructionsPage paymentInstructionspage=null;

	SoftAssert softAssert=new SoftAssert();

		public PaymentInstructionSteps() {
			paymentInstructionspage=new PaymentInstructionsPage();
		}
		
		@Then("I Verify Landing on {string} Page")
		public void I_Verify_Landing_on_Payment_Instructions_Page(String lblPaymentInstPage) {
			Hardwait.staticWait(10000);
			paymentInstructionspage.lblPaymentInstructions.verifyLabelonUI(lblPaymentInstPage);
		}
		
		@And("I Click on Country dropdown and select {string} as the country")
		public void I_Click_on_Country_dropdown_and_select_as_the_country(String Country) {
			String selCountry = paymentInstructionspage.selCountry.selectgetFirstSelectedOption();
			if (selCountry.equalsIgnoreCase(Country)) {
				
			}else {
				paymentInstructionspage.selCountry.selectByVisibleText(Country);
			}
		}
		
		@And("I Click on Payment Type dropdown and select {string} as the country")
		public void I_Click_on_PaymentType_dropdown_and_select_as_the_country(String PaymentType) {
			Hardwait.staticWait(10000);
			paymentInstructionspage.selPaymentType.selectByValue(PaymentType);
		}
		
		@And("I Validate if Sort Code, Account Number and Buidling Society RollNumber are Displayed")
		public void I_Validate_if_Sort_Code_Account_Number_and_Buidling_Society() {
			Boolean flagChk1 = paymentInstructionspage.txtAccountNumber.IsDisplayed();
			Boolean flagChk2 = paymentInstructionspage.txtSortCode.IsDisplayed();
			Boolean flagChk3 = paymentInstructionspage.txtBuildingSocietyRollNumber.IsDisplayed();
			if ((!flagChk1) || (!flagChk2) || (!flagChk3)) {
				Assert.fail("Sort Code, Account Number and Buidling Society RollNumber are NOT Displayed");
			}
		}
		
		@And("I Validate data for Payment Instruction Fields")
		public void I_Validate_Navigation_to_Tabs_on_LIC (List<Map<String,String>> paymentInstDetails) throws Exception{
			for(Map<String, String> portfolio:paymentInstDetails) {
				System.out.println(portfolio.get("key")+":"+portfolio.get("value"));
				Hardwait.staticWait(4000);
				String txtValue = portfolio.get("value");
				
				Faker faker = new Faker();
				
				switch (portfolio.get("key")) {
					case "Country Sel":
						paymentInstructionspage.selCountry.selectByValue(txtValue);
						break;
					case "PaymentType Sel":
						paymentInstructionspage.selPaymentType.selectByValue(txtValue);
						break;
					case "SortCode Input":
						paymentInstructionspage.txtSortCode.ClearInputText();
						paymentInstructionspage.txtSortCode.Inputvalues(txtValue);
						break;
					case "AccountNumber Input":
						paymentInstructionspage.txtAccountNumber.ClearInputText();
						paymentInstructionspage.txtAccountNumber.Inputvalues(txtValue);
						break;	
					case "Building Society Roll Number Input":
						paymentInstructionspage.txtBuildingSocietyRollNumber.ClearInputText();
						paymentInstructionspage.txtBuildingSocietyRollNumber.Inputvalues(txtValue);
						break;	
					case "SWIFT_BIC Input":
						paymentInstructionspage.txtSwiftBIC.ClearInputText();
						paymentInstructionspage.txtSwiftBIC.Inputvalues(txtValue);
						break;
					case "Bank Name Input":
						paymentInstructionspage.txtBankName.ClearInputText();
						paymentInstructionspage.txtBankName.Inputvalues(txtValue);
						break;	
					case "Address line 1 Input":
						String AddressLine1 = faker.address().streetName();
						paymentInstructionspage.txtBankAddressLine1.ClearInputText();
						paymentInstructionspage.txtBankAddressLine1.Inputvalues(AddressLine1);
						break;	
					case "Address line 2 Input":
						String AddressLine2 = faker.address().streetName();
						paymentInstructionspage.txtBankAddressLine2.ClearInputText();
						paymentInstructionspage.txtBankAddressLine2.Inputvalues(AddressLine2);
						break;	
					case "City Input":
						String city = faker.address().city();
						paymentInstructionspage.txtCity.ClearInputText();
						paymentInstructionspage.txtCity.Inputvalues(city);
						break;
					case "ZIP_Postcode_Eircode Input":
						String zipcode = faker.address().zipCode();
						paymentInstructionspage.txtPostCode.ClearInputText();
						paymentInstructionspage.txtPostCode.Inputvalues(zipcode.replaceAll("[^a-zA-Z0-9]", ""));
						break;	
					case "IBAN Input":
						paymentInstructionspage.txtIBAN.ClearInputText();
						paymentInstructionspage.txtIBAN.Inputvalues(txtValue);
						break;
					case "BankNumber Input":
						paymentInstructionspage.txtBankNumber.ClearInputText();
						paymentInstructionspage.txtBankNumber.Inputvalues(txtValue);
						break;
					case "BrnachNumber Input":
						paymentInstructionspage.txtBranchNumber.ClearInputText();
						paymentInstructionspage.txtBranchNumber.Inputvalues(txtValue);
						break;	
					case "BankCode Input":
						paymentInstructionspage.txtBankCode.ClearInputText();
						paymentInstructionspage.txtBankCode.Inputvalues(txtValue);
						break;
					case "IFSCCode Input":
						paymentInstructionspage.txtIFSCCode.ClearInputText();
						paymentInstructionspage.txtIFSCCode.Inputvalues(txtValue);
						break;	
					default:
						break;		
				}
			}
		}
		
	@Then("I Validate Individually select the holdings to apply this update to is selected and Apply this update to all available holdings is not selected")
	public void I_Validate_Individually_select_the_holdings_to_apply_this_update_to_is_selected_and_Apply_this_update_to_all_available_holdings_is_not_selected() {
		Boolean flagChk1 = paymentInstructionspage.chkIndividuallySelecttheHoldings.IsDisplayed();
//		Boolean flagChk2 = paymentInstructionspage.chkApplyThisUpdate.IsDisplayed();
		
		if (!flagChk1) {
			Assert.fail("I Validate Individually select the holdings to apply this update to is selected and Apply this update to all available holdings is not selected");
		}
//		if (flagChk1==false) {
//			Assert.fail("I Validate Individually select the holdings to apply this update to is selected and Apply this update to all available holdings is not selected");
//		}
	}
	
	@And("I Validate Label to {string}")
	public void validateLabel(String lblConfirmationLabel){
		paymentInstructionspage.lblConfirmPaymentInstructions.verifyLabelonUI(lblConfirmationLabel);
	}
	
	@Then("I click on Next button on Paymt Inst Screen")
	public void I_click_on_Next_button_on_Paymt_Inst_Screen(){
		paymentInstructionspage.btnNext.Click();
	}
	
	@Then("I click on Back to Payment Instructions")
	public void I_click_on_Back_to_Payment_Instructions(){
		paymentInstructionspage.btnback.Click();
	}
	
	@When("I Click to Confirm Payment Instructions")
	public void I_Click_to_Confirm_Payment_Instructions(){
		paymentInstructionspage.btnConfirm.Click();
	}
	
	@When("I Click on Edit button for Payment Instructions")
	public void i_click_on_edit_button_for_payment_instructions() {
		paymentInstructionspage.iosElementbtnEdit.IOSElementClick();
	}
	
	
	public static void IOSScrollDown(double valbottom,double valup) {
		Dimension size = ThreadLocalIOSDriver.getDriver().manage().window().getSize();
		System.out.println("Size"+size);
		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 
		int bottom=midPoint.y + (int)(midPoint.y*valbottom);
		int top=midPoint.y - (int)(midPoint.y*valup);
		Point start = new Point(midPoint.x,bottom);
		Point end = new Point(midPoint.x,top);
		
		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence scroll = new Sequence(indexFinger, 0);
		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), start.x, start.y));
		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		
		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(300), PointerInput.Origin.viewport(), end.x, end.y));
		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		
		ThreadLocalIOSDriver.getDriver().perform(ImmutableList.of(scroll));
	}
	
	@When("I Enter the Input Values for Below fields")
	public void I_Enter_the_Input_Values_for_Below_fields(List<Map<String,String>> portfolioDetails) {
		Hardwait.staticWait(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
			case "SelectCountry":
					paymentInstructionspage.iosElementbtnSelectCountry.IOSElementClick();
					paymentInstructionspage.iosElementtxtSelectCountry.IOSDeviceInputvalues(attributeValue.substring(0, attributeValue.length() - 2));
					paymentInstructionspage.iosElementPaymentInst.IOSElementClick(attributeValue);
				break;
			case "InputIBAN":
				   paymentInstructionspage.iosElementtxtSelectIBAN.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtSelectIBAN.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputSWIFTBIC":
				   paymentInstructionspage.iosElementtxtSWIFTBIC.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtSWIFTBIC.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputBankBranchCode":
				   paymentInstructionspage.iosElementtxtBankBranchCode.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtBankBranchCode.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputABARoutingNumberCode":
				   paymentInstructionspage.iosElementtxtABARoutingNumberCode.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtABARoutingNumberCode.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputAccountNumberSuffixCode":
				   paymentInstructionspage.iosElementtxtAccountNumberSuffix.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtAccountNumberSuffix.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputAccountNumber":
				   paymentInstructionspage.iosElementtxtAccountnumber.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtAccountnumber.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			
			case "InputIFSCNumber":
				   paymentInstructionspage.iosElementtxtIFSCNumber.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtIFSCNumber.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputBankName":
				   paymentInstructionspage.iosElementtxtSelectBankName.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtSelectBankName.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputBankCode":
				   paymentInstructionspage.iosElementtxtBankCode.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtBankCode.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputBankNumber":
				   paymentInstructionspage.iosElementtxtBankNumber.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtBankNumber.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputBranchNumber":
				   paymentInstructionspage.iosElementtxtBranchNumber.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtBranchNumber.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputAddressLine1":
				   paymentInstructionspage.iosElementtxtAddressLine1.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtAddressLine1.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputAddressLine2":
				   paymentInstructionspage.iosElementtxtAddressLine2.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtAddressLine2.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputCity":
				   paymentInstructionspage.iosElementtxtCity.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtCity.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputZipPostalCode":
				   paymentInstructionspage.iosElementtxtZipPostalCode.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtZipPostalCode.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputSortCode":
				   paymentInstructionspage.iosElementtxtSortCode.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtSortCode.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "InputBuildingsocietyrollNumber":
				   paymentInstructionspage.iosElementtxtBuildingsocietyrollnumber.IOSDeviceClearInputvalues();
				   paymentInstructionspage.iosElementtxtBuildingsocietyrollnumber.IOSDeviceInputvalues(attributeValue);
				   paymentInstructionspage.iosElementHideKeyboard.iosHideKeyboard();
			break;
			case "ActoionScrollDown":
					paymentInstructionspage.action.IOSScrollDown(0.25,0.25);
				Hardwait.staticWait(5000);
			break;
			case "ActoionScrollUp":
					paymentInstructionspage.action.IOSScrollUp(0.25, 0.25);
			break;
			case "BtnUpdate":
				paymentInstructionspage.iosElementbtnUpdate.IOSElementClick();
			break;
			case "ToggleApplytoallholdings":
				paymentInstructionspage.iosElementToggleApplytoAllHoldings.IOSElementClick();
			break;
			case "ToggleApplytoIndividualholdings":
				paymentInstructionspage.iosElementToggleApplytoIndividualHoldings.IOSElementClick();
			break;
				default:
				break;
			}
		}
	}
	
	
}
