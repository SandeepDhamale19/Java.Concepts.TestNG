package stepDefination;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import Constant.LICConstants;
import DriverFactory.DriverInstance;
import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalDriver;
import DriverFactory.ThreadLocalIOSDriver;
import ElementsFactory.Actions;
import Hardwait.Hardwait;
import JSONReaderFactory.JsonValueReader;
import ScreenshotFactory.TakeScreenshot;
import ScreenshotFactory.TakeScreenshotAndroid;
import ScreenshotFactory.TakeScreenshotIOS;
import Utilities.TestNGParameterConfig;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AppiumElementLocatorFactory;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.LoginPage;

public class LoginSteps {

	LoginPage loginPage=null;

	public LoginSteps() {
		loginPage=new LoginPage();
	}
	
	@Then("i validate pop {string}")
	public void i_validate_pop(String lblOurUseOfcookies) {
		loginPage.lblCookiespopUp.verifyLabelonUI(lblOurUseOfcookies);
	}
	
	@Then("i validate pop {string} should not be displayed")
	public void i_validate_popshouldnotbedisplayed(String lblOurUseOfcookies) {
		Boolean flag  = loginPage.lblCookiespopUp.getLabelIsDisplayed();
		Assert.assertFalse(flag);
	 }
	
	@And("I Click on Agree Button to accept cookies")
	public void I_Click_on_Agree_Button_to_accept_cookies() {
        loginPage.btnAgreeCookies.Click();
    }
	
	@And("I Click on Reject Button to accept cookies")
	public void I_Click_on_reject_Button_to_accept_cookies() {
        loginPage.btnRejectCookies.Click();
    }
	
	
	@And("I login using valid credentials")
    public void i_login_using_valid_credentials() throws Throwable {
		try {
			ExtentCucumberAdapter.addTestStepLog("Launched IC Application Web For UK Region");
			loginPage.btnRejectCookies.Click();
			loginPage.btnLogon.Click();
			String TestDataPath = LICConstants.Configfilepath.replace("ENV", TestNGParameterConfig.getEnv());
				new TakeScreenshot();
				loginPage.txtUsername.ClearInputvalues();
				loginPage.txtUsername.Inputvalues(JsonValueReader.readJSONValue(TestDataPath, "icUsername"));
				ExtentCucumberAdapter.addTestStepLog("Entered Username in IC Application");
				
				loginPage.txtPassword.ClearInputvalues();
				loginPage.txtPassword.Inputvalues(JsonValueReader.readJSONValue(TestDataPath, "icPassword"));
				ExtentCucumberAdapter.addTestStepLog("Entered Password in IC Application");
			loginPage.btnLogin.Click();
			new TakeScreenshot();
		}catch (Exception e) {
			e.printStackTrace();
			new TakeScreenshot();
		}
	}
	
	@And("I login using valid credentials for device Android")
    public void i_login_using_valid_credentialsAndroid() throws Throwable {
		try {
			ExtentCucumberAdapter.addTestStepLog("Launched IC Application Web For UK Region");
			loginPage.btnandroidElementbtnLoginPath.AndroidElementClick();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
	@Then("I Validate the Country Selection drop down Screen")
	public void I_Validate_the_Country_Selection_drop_down() {
		loginPage.iosElementlblWelcometoLink.iosElementgetLabelIsDisplayed();
		loginPage.iosElementSelPleaseSelect.IOSElementClick();
		loginPage.iosElementSelUK.IOSElementClick();
		loginPage.iosElementbtnContinue.IOSElementClick();
	}
	
	
	@And("I login using valid credentials for device IOS")
    public void i_login_using_valid_credentialsIOS() throws Exception {
		try {
			ExtentCucumberAdapter.addTestStepLog("Launched IC Application For UK Region");
			loginPage.iosElementlblWelcometoLink.iosElementgetLabelIsDisplayed();
			loginPage.iosElementSelPleaseSelect.IOSElementClick();
			loginPage.iosElementSelUK.IOSElementClick();
			loginPage.iosElementbtnContinue.IOSElementClick();
			loginPage.iosElementbtnLogin.IOSElementClick();
			Hardwait.staticWait(2000);
			try {
				loginPage.iosElementpopupbtnContinue.IOSElementClick();
				Hardwait.staticWait(10000);
			}catch (StaleElementReferenceException e) {
				System.out.println("Caught StaleElementReferenceException!!");
			}catch (ElementNotInteractableException e) {
				System.out.println("Caught ElementNotInteractableException!!");
			}catch (TimeoutException e) {
				System.out.println("Caught TimeoutException!!");
			}catch (NullPointerException e) {
				System.out.println("Caught NullPointerException!!");
			}
			loginPage.iosElementlblManageHolding.iosElementgetLabelIsDisplayed();
			loginPage.iosElementlblEnterEmail.iosElementgetLabelIsDisplayed();
			loginPage.iosElementlblEnterPassword.iosElementgetLabelIsDisplayed();
			loginPage.iosElementlblKeepMeSignedIn.iosElementgetLabelIsDisplayed();
			Hardwait.staticWait(10000);
			String TestDataPath = LICConstants.Configfilepath.replace("ENV", TestNGParameterConfig.getEnv());
//				new TakeScreenshotIOS();
				ThreadLocalIOSDriver.getDriver().findElement(AppiumBy.xpath("//XCUIElementTypeTextField")).click();
//				loginPage.iosElementtxtUsername.IOSDeviceClearInputvalues();
				loginPage.iosElementtxtUsername.IOSDeviceInputvalues(JsonValueReader.readJSONValue(TestDataPath, "icUsername"));
				ExtentCucumberAdapter.addTestStepLog("Entered Username in IC Application");
				
//				loginPage.iosElementtxtPassword.IOSDeviceClearInputvalues();
				loginPage.iosElementtxtPassword.IOSDeviceInputvalues(JsonValueReader.readJSONValue(TestDataPath, "icPassword"));
				ExtentCucumberAdapter.addTestStepLog("Entered Password in IC Application");
			loginPage.iosElementbtnLoginManageHoldings.IOSElementClick();
			new TakeScreenshotIOS();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@When("I validate {string} Launching of IOS Application")
	public void i_validate_launching_of_ios_application(String lblWelcometoLinkMarket) {
		loginPage.iosElementlblWelcometoLink.iosElementverifyLabelonUI(lblWelcometoLinkMarket);
	}
	
	@When("I Validate Select Country United Kingdom in Drop Down")
	public void i_validate_country_drop_down_is_displayed() {
		loginPage.iosElementSelPleaseSelect.IOSElementClick();
		loginPage.iosElementSelUK.IOSElementClick();
	}
	
	@Then("I Select Continue Button on iOS")
	public void i_select_continue_button_on_i_os() {
		loginPage.iosElementbtnContinue.IOSElementClick();
		loginPage.iosElementbtnLogin.IOSElementClick();
	}
	
	@Then("I Click on Login Button IOS")
	public void i_click_on_login_button_ios() {
		loginPage.iosElementbtnLoginPin.IOSElementClick();
	}
	
	@Then("I Select Country drop down {string}")
	public void ISelectCountryDropDown(String selCountry) {
		loginPage.androidElementSelPleaseSelect.AndroidElementClick();
		loginPage.androidElementSelUK.AndroidElementClick();
	}
	
	@And("I Click On Continue")
	public void Click_On_Continue() throws Exception{
		loginPage.androidElementbtnContinue.AndroidElementClick();
	}
	

	@Then("I validate Landing on Home screen {string}")
	public void VdlateLandingScreen(String lblLanding) {
		loginPage.androidElementlblWelcomeToHomeScreen.androiElementverifyLabelonUI(lblLanding);
	}

	@Then("i Land on Welcome to Link market Services to click on Login Button")
	public void click_on_Login_Button() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/login_btn")).click();
	}
	
	@When("I Enter Username and Password on Manage Holdings")
	public void Enter_Username_and_Password_on_Manage_Holdings() {
		Hardwait.staticWait(10000);
		String name = ThreadLocalAndroidDriver.getDriver().getContext();
		System.out.println(name);
		
		String TestDataPath = LICConstants.Configfilepath.replace("ENV", TestNGParameterConfig.getEnv());
		System.out.println(JsonValueReader.readJSONValue(TestDataPath, "icUsername"));
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("(//android.widget.EditText)[1]")).sendKeys(JsonValueReader.readJSONValue(TestDataPath, "icUsername")); 
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("(//android.widget.EditText)[2]")).sendKeys(JsonValueReader.readJSONValue(TestDataPath, "icPassword"));
	}
	
	@And("I Enter User Name and Password on Manage Holding screen")
	public void I_Enter_User_Name_and_Password_on_Manage_Holding_screen(List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeName = portfolio.get("AttributeName");
			String attributeValue=portfolio.get("AttributeValue");
			switch (attributeName) {
				case "Username":
						ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("(//android.widget.EditText)[1]")).sendKeys(attributeValue);					
					break;
				case "Password":
						ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("(//android.widget.EditText)[2]")).sendKeys(attributeValue);					
					break;
			}
		}
	}
	
	@When("I click on Login")
	public void ClickOnLoginButton() {
		Hardwait.staticWait(5000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.Button[@text='Login']")).click();
		Hardwait.staticWait(40000);
	}
	
	@When("I click on Enter")
	public void ClickOnEnterButton() {
		Hardwait.staticWait(5000);
		((AndroidDriver)ThreadLocalAndroidDriver.getDriver()).pressKey(new KeyEvent(AndroidKey.ESCAPE));
		Hardwait.staticWait(10000);
	}
	
	@Then("i validate SetUp PIN Screen with Title {string}")
	public void i_validate_Setup_PIN_Screen_with_Title(String lblSetUpPin) {
		Hardwait.staticWait(10000);
		String lblSetUpUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/toolbar_title")).getText();
		Assert.assertEquals(lblSetUpUI, lblSetUpPin);
	}
	
	@Then("i click on Yes SetUp PIN Screen")
	public void clickonYes_Setup_PIN_Screen_with_Title() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/yes")).click();
		Hardwait.staticWait(60000);
	}
	
	@And("I Enter Values on PIN screen")
	public void I_Enter_Values_on_PIN_screen() {
		
		
//		((AndroidDriver)ThreadLocalAndroidDriver.getDriver()).pressKey(new KeyEvent(AndroidKey.ENTER));
		
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/pin1")).sendKeys("1");
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/pin2")).sendKeys("2");
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/pin3")).sendKeys("3");
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/pin4")).sendKeys("4");
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/pin5")).sendKeys("5");
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/pin6")).sendKeys("6");
		
		loginPage.action.ScrollDown();
		Hardwait.staticWait(30000);
	}

	@Then("I Validate Landing on {string} screen UI")
	public void Validate_Landing_on_Portfolio(String lblPortfolio) {
		Hardwait.staticWait(30000);
		String lblPortfolioUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/toolbar_title")).getText();
		Assert.assertEquals(lblPortfolioUI, lblPortfolio);
	}
	
	
	
	@And("I Click on Submit Button UI")
	public void I_Click_on_Submit_Button_UI() {
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/btnSubmit")).click();
	}
	
	@Then("I Validate Success Pop up on screen {string} and {string} post PIN authentication")
	public void I_Validate_Success_Pop_up_on_screen(String lblSuccess,String lblPinAuthentication) {
		String lblSuccessUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/delete_account_error_text")).getText();
		Assert.assertEquals(lblSuccessUI, lblSuccess);
		
		String lblPinAuthenticationUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/delete_account_error_subtext")).getText();
		Assert.assertEquals(lblPinAuthenticationUI, lblPinAuthentication);
		
	}
	
	@And("I validate Setup Fingerface ID print ID {string} click on Mabe Later")
	public void I_validet_Setup_Fingerface_ID_print_ID__click_on_Mabe_Later(String lblSetupFingerPrint) {
		Hardwait.staticWait(10000);
		String lblSetupFingerPrintUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/toolbar_title")).getText();
		Assert.assertEquals(lblSetupFingerPrintUI, lblSetupFingerPrint);
		
		String lblAPPSetupFingerPrintUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/message")).getText();
		Assert.assertEquals(lblAPPSetupFingerPrintUI, "The app will use the stored Fingerprint/Face ID data on your device for authentication during login.");
		
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/later")).click();
		
	}
	
	
	
	@And("I Click on Done UI")
	public void clickOnDone() {
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/done_btn")).click();
	}
	
	
	@Then("I Validate {string} to confirm PIN")
	public void toConfirmPIN(String lblConfirmPIN) {
		String lblConfirmPINUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/toolbar_title")).getText();
		Assert.assertEquals(lblConfirmPINUI, lblConfirmPIN);
	}
	
	
	@Then("i validate SetUp six Digit Pin Screen with Title {string}")
	public void i_validate_SetUp_six_Digit_Pin(String lblSixDigitPin) {
		String lbllblSixDigitPinUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/message")).getText();
		Assert.assertEquals(lbllblSixDigitPinUI, lblSixDigitPin);
	}
	
	@Then("i validate Yes SetUp Pin Screen with label {string}")
	public void i_validate_Yes_SetUp_Pin_Screen(String lblYesSetuppin) {
		String lblYesSetuppinUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/yes")).getText();
		Assert.assertEquals(lblYesSetuppinUI, lblYesSetuppin);
		
		String lblMayBeLaterUI = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/later")).getText();
		Assert.assertEquals(lblMayBeLaterUI, "Maybe later");
		
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/later")).click();
		
	}
	
	
	@When("I Click on Next button OnBoarding Screen")
	public void	 OnBoarding_Screen() throws Exception {
		Thread.sleep(5000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/next")).click();
	}
	
	
	
	
	
	
	@Then("I Click on Get Started Button OnBoarding Screen")
	public void OnBoardingScreen() throws Exception{
		Thread.sleep(5000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/get_started")).click();
	}
	
	
	
	@And("I Click on Skip Button on UI Screen")
	public void I_Click_on_Skip_Button_on_UI_Screen() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/skip_all")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@When("I Click on Logout Button UI")
	public void click_on_Logout_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.TextView[@text='Log Out']")).click();
		Hardwait.staticWait(5000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.Button[@text='LOGOUT']")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@Given("I click on Login Button")
	public void I_click_on_Login_Button() {
		loginPage.btnLogon.Click();
	}

	@Given("Enter Valid Email ID {string}")
	public void Enter_Valid_Email_ID(String txtEamilIDInput) {
		loginPage.txtUsername.Inputvalues(txtEamilIDInput);
	}
	
	@Given("Enter In Valid Email ID {string}")
	public void Enter_In_Valid_Email_ID(String txtEamilIDInput) {
		loginPage.txtUsername.Inputvalues(txtEamilIDInput);
	}
	
	@And("I Validate EmailID is Entered on Screen")
	public void IValidateEmailIDisEnteredonScreen() {
		System.out.println("Get Input Text:"+loginPage.txtUsername.getInputText());
	}
	
	@Given("Enter In Valid Password {string}")
	public void Enter_In_valid_Password(String txtPasswordInput) {
		loginPage.txtPassword.Inputvalues(txtPasswordInput);
	}
	 
	@Given("Enter Valid Password {string}")
	public void Enter_valid_Password(String txtPasswordInput) {
		loginPage.txtPassword.Inputvalues(txtPasswordInput);
	}
	
	@And("I check if I can Show the Password {string}")
	public void Enter_valid_PasswordShowThePassword(String txtPasswordInput) throws Exception {
		loginPage.btnshowPassword.Click();
		Assert.assertEquals(txtPasswordInput, loginPage.txtPassword.getInputText());
		Thread.sleep(1000);
		loginPage.btnshowPassword.Click();
	}
	
	@And("I check if I can View the Username {string}")
	public void Enter_valid_PasswordShowTheUsername(String txtUsernameInput) throws Exception {
		Assert.assertEquals(txtUsernameInput, loginPage.txtUsername.getInputText());
	}
	
	
	@When("Click on Check box with label {string}")
	public void Click_on_Check_box_with_label_Keep_me_signed_in(String lblkeepMeSignedIN) {
		loginPage.lblRememberMe.verifyText(lblkeepMeSignedIN);
		loginPage.chkRememberMe.Click();
	}
	
	@And("I Validate {string} is visible on Screen")
	public void IValdiateLoginScreen(String lblkeepMeSignedIN) throws Exception {
		Thread.sleep(5000);
		loginPage.lblFAQs.verifyText(lblkeepMeSignedIN);
	}	
	
	
	@And("I Validate {string} screen should be displayed")
	public void I_validate_ResetPass(String lblResetForgetPassword) throws Exception{
		Thread.sleep(5000);
		loginPage.lblResetPassword.verifyText(lblResetForgetPassword);
	}
	
	@Then("I Validate Forget Password Link is visible on Screen")
	public void I_Validate_Forget_Password_Link() {
		loginPage.btnForgetPassword.ValidateIsButtonDisplayed();
	}
	
	@Then("I Click on Forget Password Link") 
	public void I_ClickOn_Forget_Password_Link() {
		loginPage.btnForgetPassword.Click();
	}
	
	@Then("I Validate Help Link is visible on Screen")
	public void I_Validate_Help_Link() {
		loginPage.btnHelp.ValidateIsButtonDisplayed();
	}
	
	@Then("I Click on Help Link is visible on Screen")
	public void I_ClickOnValidate_Help_Link() {
		loginPage.btnHelp.Click();
	}
	
	
	
	@And("Click on login button")
	public void Click_on_login_button() {
		loginPage.btnLogonsubmit.Click();
	}
	
	@And("Validate Login Is Displayed")
	public void ValidateLogin_ButtonIsDisplayed() {
		loginPage.btnLogonsubmit.ValidateIsButtonDisplayed();
	}
	
	@Then("Validate Error Message {string}  should be displayed")
	public void Validate_Error_Message(String lblErrorMessage) throws Exception{
		Thread.sleep(3000);
		loginPage.lblErrorMessage.verifyText(lblErrorMessage);
	}
	
	@Given("Validate Register is displayed on Top and Center of screen")
	public void validate_register_is_displayed_on_top_and_center_of_screen() {
		loginPage.btnRegisterNow.ValidateIsButtonDisplayed();
		loginPage.btnRegisterNowTop.ValidateIsButtonDisplayed();
	}
	
	@Then("Verify Instructional Text {string}")
	public void verify_instructional_text(String lblInstructionalText) {
		Assert.assertEquals(lblInstructionalText, loginPage.getLablelInstructionsText());
	}
	
	
	@And("Verify if Login Button is Visible on Screen")
	public void verifyifLoginButtonisVisible() {
		loginPage.btnLogintop.ValidateIsButtonDisplayed();
	}
	
	
	@Then("I Click on Register Button")
	public void IClickOnregister() {
		loginPage.btnRegisterNowTop.Click();
	}
	
	@And("Verify your Email page should get displayed for registration process {string}")
	public void VerifyEmailAddressPage(String lblVerifyEMail) {
		loginPage.lblVerifyEmail.verifyText(lblVerifyEMail);
	}
	
	@Then("I verify LinkMarket Services Logo")
	public void I_verifyLinkMarket_Services_Logo() {
		Assert.assertEquals(true, loginPage.lblLinkMarketServicesLogo.getLabelIsDisplayed()); 
	}
	
	@And("I {string} label and Email address field")
	public void I_Enter_email_labelandEmailaddress(String lblEmailAddress) {
		loginPage.lblEnterEmail.verifyText(lblEmailAddress);
	}
	
	@And("I verify Checkbox to confirm as {string}")
	public void IverifyCheckBoxToConfirm(String lblCheckBoxRobot) {
//		loginPage.chkCapcha.ValidateIsButtonDisplayed();
//		loginPage.lblamNotARobot.verifyLabelonUI(lblCheckBoxRobot);
		
		if(ThreadLocalDriver.getDriver().findElements(By.xpath("//label[@id='recaptcha-anchor-label']")).size()>0){
			String label = ThreadLocalDriver.getDriver().findElements(By.xpath("//label[@id='recaptcha-anchor-label']")).get(0).getText();
			Assert.assertEquals(label, lblCheckBoxRobot);
			ExtentCucumberAdapter.addTestStepLog("Webelement is Present!!");
		}else {
			ExtentCucumberAdapter.addTestStepLog("Webelement is Not Present!!");
		}
		
	}
	
	@And("I verify Generate Pin Button is displayed")
	public void IverifyGeneratePinButton() {
		loginPage.btnGeneratePin.IsDisplayed();
	}
	
	@Then("I Verify Cancel Button is displayed")
	public void Ive6rifyGeneratePinButton() {
		loginPage.btnCancel.ValidateIsButtonDisplayed();
	}
	
	@Then("I Click on Cancel Button")
	public void IClickonCancelButton() {
		loginPage.btnCancel.Click();
	}
	
	@And("I validate UI Labels for SetUp PIN for IOS")
	public void I_validate_UI_Labels_for_SetUp_PIN_for_IOS (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(10000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "lblSetuppin":
						loginPage.iosElementlblSetupPin.iosElementgetLabelIsDisplayed();
					break;
				case "lblSetup6digitpin":
					loginPage.iosElementlblSetup6DigitPin.iosElementgetLabelIsDisplayed();
				break;
				case "lblYesSetuppin":
					loginPage.iosElementlblYesSetupPin.iosElementgetLabelIsDisplayed();
				break;
				case "lblMaybeLater":
					loginPage.iosElementlblMayBeLater.iosElementgetLabelIsDisplayed();
				break;
			}
		}
	}
	
	
	@When("I click on Maybe later on IOS")
	public void i_click_on_maybe_later_on_ios() {
		loginPage.iosElementbtnMayBeLater.IOSElementClick();
	}	
	
	@Then("I click on Skip button on IOS")
	public void i_click_on_skip_button_on_ios() {
	    loginPage.iosElementbtnSkip.IOSElementClick();
	}
	
	
	@Then("I click on Next button on IOS")
	public void i_click_on_Next_button_on_ios() {
	    loginPage.iosElementbtnNext.IOSElementClick();
	}
	
	
	@Then("I Validate Label Everything you need to manage your portfolio")
	public void i_validate_label_everything_you_need_to_manage_your_portfolio() {
	   loginPage.iosElementlblEverythingYouNeedToManage.iosElementverifyLabelonUI("Everything you need to manage your portfolio");
	}

	@Then("I Validate Label Quickly check payments and balances")
	public void i_validate_label_quickly_check_payments_and_balances() {
		loginPage.iosElementlblQuicklyCheckPayments.iosElementverifyLabelonUI("Quickly check payments and balances");
	}

	@Then("I Validate Label Add holdings as your portfolio grows")
	public void i_validate_label_add_holdings_as_your_portfolio_grows() {
		loginPage.iosElementlblAddHoldingsAsYourPortfolio.iosElementverifyLabelonUI("Add holdings as your portfolio grows");
	}

	@Then("I Validate Label Easily manage your settings and preferences")
	public void i_validate_label_easily_manage_your_settings_and_preferences() {
		loginPage.iosElementlblEasilyManageYourSettingsAndPreferences.iosElementverifyLabelonUI("Easily manage your settings and preferences");
	}

	@Then("I click on Get Started button on IOS")
	public void i_click_on_get_started_button_on_ios() {
		loginPage.iosElementbtnGetStarted.IOSElementClick();
	}
	
	
	@Then("I click on Yes setup Pin")
	public void i_click_on_yes_setup_pin() {
		loginPage.iosElementbtnYesSetupPin.IOSElementClick();
	}
	
	@And("I validate UI Labels for Create PIN Screen")
	public void I_validate_UI_Labels_for_Create_PIN_Screen (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(10000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "lblCreatepin":
						loginPage.iosElementlblCreatePin.iosElementverifyLabelonUI(attributeValue);
					break;
				case "lblEnter6digitpin":
					loginPage.iosElementlblEnter6DigitPin.iosElementverifyLabelonUI(attributeValue);
				break;
			}
		}
	}
	
	@And("I validate UI Labels for Confirm PIN Screen")
	public void I_validate_UI_Labels_for_Confirm_PIN_Screen (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(10000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "lblConfirmpin":
						loginPage.iosElementlblConfirmPin.iosElementverifyLabelonUI(attributeValue);
					break;
				case "lblReEnterEnter6digitpin":
					loginPage.iosElementlblReEnter6DigitPin.iosElementverifyLabelonUI(attributeValue);
				break;
			}
		}
	}
	
	@Then("I Enter the values on Pin fields {string}")
	public void i_enter_the_values_on_create_pin(String InputPassword)throws Exception {
		loginPage.iosElementlblEnterPin1.IOSDeviceInputvalues(String.valueOf(InputPassword.charAt(0)));
		loginPage.iosElementlblEnterPin2.IOSDeviceInputvalues(String.valueOf(InputPassword.charAt(1)));
		loginPage.iosElementlblEnterPin3.IOSDeviceInputvalues(String.valueOf(InputPassword.charAt(2)));
		loginPage.iosElementlblEnterPin4.IOSDeviceInputvalues(String.valueOf(InputPassword.charAt(3)));
		loginPage.iosElementlblEnterPin5.IOSDeviceInputvalues(String.valueOf(InputPassword.charAt(4)));
		loginPage.iosElementlblEnterPin6.IOSDeviceInputvalues(String.valueOf(InputPassword.charAt(5)));
		
	}
	
	@Then("I Click on Submit pin IOS")
	public void i_click_on_submit_pin_ios() {
		loginPage.iosElementbtnSubmit.IOSElementClick();
	}
	
	@When("I click on Confirm PIN IOS")
	public void i_click_on_confirm_pin_ios() {
		loginPage.iosElementbtnConfirm.IOSElementClick();
	}
	
	@When("I Verify Success Message {string}  and {string} for PIN Change on IOS")
	public void i_verify_success_message_and_for_pin_change_on_ios(String lblSuccess, String lblSuccessMsg) {
		loginPage.iosElementlblSuccess.iosElementverifyLabelonUI(lblSuccess);
		loginPage.iosElementlblPinAuth.iosElementverifyLabelonUI(lblSuccessMsg);
		
	}
	
	@Then("I click on done in IOS")
	public void i_click_on_done_in_ios() {
	    loginPage.iosElementbtnDone.IOSElementClick();
	}
	
}
