package stepDefination;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import DriverFactory.ThreadLocalAndroidDriver;
import Hardwait.Hardwait;
import io.appium.java_client.AppiumBy;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.AddHoldingPage;
import pageObject.HoldingSettingsPage;

public class HoldingSettingSteps {

	HoldingSettingsPage holdingSettings_pageobject = null;
	public WebDriver driver;
	public static Map<String, String> sharedData = new HashMap<String, String>();

	public HoldingSettingSteps() {

		holdingSettings_pageobject = new HoldingSettingsPage();
	}

	@When("I click on Communication preferences Button UI")
	public void i_click_on_communication_preferences_button_ui() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementcommprefbutton.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Communication preference button");
		Hardwait.staticWait(10000);

	}

	@When("I Validate Communication preferences Screen Labels")
	public void i_validate_communication_preferences_screen_labels(List<Map<String, String>> CommPrefDetails)
			throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : CommPrefDetails) {
			System.out.println(
					CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeValue = CommunicationPreference.get("AttributeValue");
			String attributeName = CommunicationPreference.get("AttributeName");
			switch (attributeName) {

			case "HoldingSettings":
				String lblHoldingSettings = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView"))
						.getText();
				Assert.assertEquals(lblHoldingSettings, attributeValue);
				Hardwait.staticWait(20000);
				break;

			case "CommunicationPreferences":
				String lblCommunicationPreferences = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView[1]"))
						.getText();
				Assert.assertEquals(lblCommunicationPreferences, attributeValue);
				break;

			case "ViewBy":
				String lblViewBy = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.TextView[2]"))
						.getText();
				Assert.assertEquals(lblViewBy, attributeValue);
				break;

			case "MethodOfCommunication":
				String lblMethodOfCommunication = ThreadLocalAndroidDriver.getDriver()
						.findElement(
								AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/communication_method_label"))
						.getText();
				Assert.assertEquals(lblMethodOfCommunication, attributeValue);
				break;
			case "InstructionalText1":
				holdingSettings_pageobject.AndroidElementlblYourCurrentCommPref.androidElementgetLabelIsDisplayed();
				break;
			case "InstructionalText2":
				holdingSettings_pageobject.AndroidElementlblAllInvestorCommunicationSentElectronically.androidElementgetLabelIsDisplayed();
				break;

			case "Note":
				holdingSettings_pageobject.scroll.ScrollDown();
				String lblNote = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/note")).getText();
				Assert.assertEquals(lblNote, attributeValue);
				break;

			case "Next":
				String lblNext = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/button")).getText();
				Assert.assertEquals(lblNext, attributeValue);
				break;

			}
		}
	}

	@When("I Validate Email Sent to SubSection Labels")
	public void i_validate_email_sent_to_sub_section_labels(List<Map<String, String>> EmailDetails) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : EmailDetails) {
			System.out.println(CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeValue = CommunicationPreference.get("AttributeValue");
			String attributeName = CommunicationPreference.get("AttributeName");
			switch (attributeName) {

			case "Default":
				String lblDefault = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/email")).getText();
				Assert.assertEquals(lblDefault, attributeValue);
				break;

			case "other":
				String lblOther = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/other")).getText();
				Assert.assertEquals(lblOther, attributeValue);
				break;
			}
		}
	}

	@When("I Validate Update settings SubSection Labels")
	public void i_validate_update_settings_sub_section_labels(List<Map<String, String>> updateSettings)
			throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : updateSettings) {
			System.out.println(
					CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeValue = CommunicationPreference.get("AttributeValue");
			String attributeName = CommunicationPreference.get("AttributeName");
			switch (attributeName) {

			case "ApplyToAllHoldings":
				String lblApplyToAllHoldings = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/apply_to_all")).getText();
				Assert.assertEquals(lblApplyToAllHoldings, attributeValue);
				holdingSettings_pageobject.actions.ScrollDown();
				break;

			case "ApplyToIndividualHolding":
				String lblApplyToIndividualHolding = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy
								.id("com.linkgroup.android_investorcentre.sit:id/apply_to_individual_holding_toggle"))
						.getText();
				Assert.assertEquals(lblApplyToIndividualHolding, attributeValue);
				break;
			case "ApplyToAllHoldingsbtn":
					ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/apply_to_all")).click();
				break;

			case "ApplyToIndividualHoldingbtn":
					ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/apply_to_individual_holding_toggle")).click();
					holdingSettings_pageobject.scroll.ScrollDown();
				break;	
			case "HoldingSelectedlbl":
				holdingSettings_pageobject.AndroidElementHoldingSelected.androidElementgetLabelIsDisplayed();
				holdingSettings_pageobject.scroll.ScrollDown();
			break;			
			}
		}
	}
	
	@Then("I Select the holding in value drop down as {string}")
	public void i_select_the_holding_in_value_drop_down_as(String setholder) {
		holdingSettings_pageobject.androidElementdropdown.AndroidElementClick();
		holdingSettings_pageobject.androidElementdropdownValue.AndroidElementClick();
	}
	
	@Then("I Select a holding in value drop down as {string}")
	public void i_select_a_holding_in_value_drop_down_as(String setholder) {
		holdingSettings_pageobject.androidElementdropdown.AndroidElementClick();
		holdingSettings_pageobject.androidElementviewbydropdownValue.AndroidElementClick();
	}

	@Then("I Select the new holding in value drop down as {string}")
	public void i_select_the_new_holding_in_value_drop_down_as(String setholder) {
		holdingSettings_pageobject.androidElementdropdown.AndroidElementClick();
		holdingSettings_pageobject.androidElementDropdownvalue.AndroidElementClick();
	}

	@Then("I click on Other radio button on UI and enter Random email address")
	public void i_click_on_other_radio_button_on_ui_and_enter_Random_email_address() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementOtherButton.AndroidElementClick();
		Hardwait.staticWait(10000);
		// Faker faker = new Faker();
		String emailAddress = holdingSettings_pageobject.generateRandomAlphaString(5).toLowerCase() + "@gmail.com";
		holdingSettings_pageobject.androidElementtxtEmailAddress.AndroidDeviceClearInputvalues();
		holdingSettings_pageobject.androidElementtxtEmailAddress.AndroidDeviceInputvalues(emailAddress);
		ExtentCucumberAdapter.addTestStepLog("Email Address added in Communication Preferences " + emailAddress);
		sharedData.put("Updated Email", emailAddress);
		holdingSettings_pageobject.scroll.ScrollDown();
	}

	@When("I click on Next Button UI")
	public void i_click_on_next_button_ui() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementNextButton.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Next button");
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.scroll.ScrollDown();
	}

	@When("I Validate Communication preferences confirmation page Screen Labels")
	public void i_validate_communication_preferences_confirmation_page_screen_labels(
			List<Map<String, String>> confirmCommPref) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : confirmCommPref) {
			System.out.println(
					CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeValue = CommunicationPreference.get("AttributeValue");
			String attributeName = CommunicationPreference.get("AttributeName");
			switch (attributeName) {

			case "CommunicationPreferences":
				String lblCommunicationPreferences = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.TextView[1]"))
						.getText();
				Assert.assertEquals(lblCommunicationPreferences, attributeValue);
				break;

			case "Confirm":
				String lblConfirm = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.TextView[3]"))
						.getText();
				Assert.assertEquals(lblConfirm, attributeValue);
				break;

			case "Method":

				String lblMethod = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/email")).getText();
				/*
				 * String emailAddress = sharedData.get("Updated Email");
				 * Assert.assertEquals(lblMethod, emailAddress);
				 */
				ExtentCucumberAdapter
						.addTestStepLog("Updated email address is same as updated in previous page" + lblMethod);
				break;

			case "Update":
				String lblUpdate = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/button")).getText();
				// Assert.assertEquals(lblUpdate, attributeValue);
				break;

			}
		}
	}

	@When("I click on Confirm Button UI")
	public void i_click_on_Confirm_button_ui() {
		holdingSettings_pageobject.scroll.ScrollDown();
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementConfirmButton.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Confirm button");
		Hardwait.staticWait(10000);
	}

	@When("I Validate Success page Screen Labels")
	public void i_validate_success_page_screen_labels(List<Map<String, String>> successpage) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> CommunicationPreference : successpage) {
			System.out.println(
					CommunicationPreference.get("AttributeName") + ":" + CommunicationPreference.get("AttributeValue"));
			String attributeValue = CommunicationPreference.get("AttributeValue");
			String attributeName = CommunicationPreference.get("AttributeName");
			switch (attributeName) {

			case "success":
				String lblsuccess = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/success_title"))
						.getText();
				Assert.assertEquals(lblsuccess, attributeValue);
				break;

			case "InstructionalText":
				String lblInstructionalText = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/message")).getText();
				Assert.assertEquals(lblInstructionalText, attributeValue);
				break;

			case "done":
				String lbldone = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/back_btn")).getText();
				Assert.assertEquals(lbldone, attributeValue);
				break;
			}
		}
	}

	@Then("I click on Done button")
	public void i_click_on_done_button() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementDoneButton.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Done button");
		Hardwait.staticWait(10000);
	}

	@Then("validate communication preference is successfully updated for specific holding")
	public void validate_communication_preference_is_successfully_updated_for_specific_holding() {
		Hardwait.staticWait(60000);
		holdingSettings_pageobject.scroll.ScrollDown();
		Hardwait.staticWait(60000);
		String lblemail = ThreadLocalAndroidDriver.getDriver()
				.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/other_email")).getText();
		String emailAddressnew = sharedData.get("Updated Email");
		Assert.assertEquals(lblemail, emailAddressnew);
		ExtentCucumberAdapter.addTestStepLog("Updated email address is " + emailAddressnew);
	}

	@Then("I click on Apply to all holding radio button")
	public void i_click_on_apply_to_all_holding_radio_button() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementApplyToallHolding.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Apply to all holding radio button");
		Hardwait.staticWait(10000);
	}

	@Then("validate communication preference is successfully updated for all holding")
	public void validate_communication_preference_is_successfully_updated_for_all_holding() {
		Hardwait.staticWait(60000);
		holdingSettings_pageobject.scroll.ScrollDown();
		Hardwait.staticWait(60000);
		String lblemail = ThreadLocalAndroidDriver.getDriver()
				.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/other_email")).getText();
		String emailAddressnew = sharedData.get("Updated Email");
		Assert.assertEquals(lblemail, emailAddressnew);
		ExtentCucumberAdapter.addTestStepLog("Updated email address is " + emailAddressnew);
	}

	@Then("I click on Apply to Individual holding radio button on UI")
	public void i_click_on_apply_to_individual_holding_radio_button_on_ui() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementApplyToindividualHolding.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Apply to individual holding radio button");
		Hardwait.staticWait(10000);
	}

	@Then("I click on Click here to individually select the holdings to apply this update button on UI")
	public void i_click_on_click_here_to_individually_select_the_holdings_to_apply_this_update_button_on_ui() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementClickhereToApply.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Click here to individually select the holdings to apply this update button on UI");
		Hardwait.staticWait(10000);
	}

	@Then("validate I have landed on Individual holdings page")
	public void validate_i_have_landed_on_individual_holdings_page() {
		String attributeValue = "Individual holdings";
		String lblIndividualHoldings = ThreadLocalAndroidDriver.getDriver()
				.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/individual_holdings_label"))
				.getText();
		Assert.assertEquals(lblIndividualHoldings, attributeValue);
	}
	
	
	
	
	@Then("I click on Apply button")
	public void i_click_on_apply_button() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.androidElementApplybutton.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on apply button on UI");
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.scroll.ScrollDown();

	}

	@When("I click on Address Details Button UI")
	public void i_click_on_address_details_button_ui() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.AndroidElementbtnAddressdetails.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Adress Details on UI");
		Hardwait.staticWait(10000);
	}

	@When("I Validate Address Details Screen Labels")
	public void I_validate_Address_Details_screen_labels(List<Map<String, String>> AddressDetails) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> AddressDetailsPage : AddressDetails) {
			System.out
					.println(AddressDetailsPage.get("AttributeName") + ":" + AddressDetailsPage.get("AttributeValue"));
			String attributeValue = AddressDetailsPage.get("AttributeValue");
			String attributeName = AddressDetailsPage.get("AttributeName");
			switch (attributeName) {

			case "HoldingSettings":
				String lblHoldingSettings = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView"))
						.getText();
				Assert.assertEquals(lblHoldingSettings, attributeValue);
				Hardwait.staticWait(20000);
				break;

			case "AddressDetails":
				String lblAddressDetails = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/address_details_title"))
						.getText();
				Assert.assertEquals(lblAddressDetails, attributeValue);
				// Hardwait.staticWait(20000);
				break;

			case "ViewBy":
				String lblViewBy = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/view_by_label"))
						.getText();
				Assert.assertEquals(lblViewBy, attributeValue);
				break;

			case "EnterYourAddressDetails":
				String lblEnterYourAddressDetails = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.widget.LinearLayout/android.widget.TextView[1]"))
						.getText();
				Assert.assertEquals(lblEnterYourAddressDetails, attributeValue);
				break;

			case "Location Header":
				String lblLocation_Header = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/location_title"))
						.getText();
				Assert.assertEquals(lblLocation_Header, attributeValue);
				break;

			case "Location RadioButton1":
				String lblLocation_RadioButton1 = ThreadLocalAndroidDriver.getDriver()
						.findElement(
								AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/location_within_uk_ireland"))
						.getText();
				Assert.assertEquals(lblLocation_RadioButton1, attributeValue);
				break;

			case "Location RadioButton2":
				String lblLocation_RadioButton2 = ThreadLocalAndroidDriver.getDriver()
						.findElement(
								AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/location_outside_uk_ireland"))
						.getText();
				Assert.assertEquals(lblLocation_RadioButton2, attributeValue);
				break;

			case "Street Adress Header":
				String lblStreet_Adress_Header = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath(
						"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.RelativeLayout/android.widget.RelativeLayout[2]/android.widget.LinearLayout/android.widget.TextView[3]"))
						.getText();
				Assert.assertEquals(lblStreet_Adress_Header, attributeValue);
				break;

			case "Street Adress Textbox1":
				String lblStreet_Adress_Textbox1 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/street_address"))
						.getText();
				if (attributeValue.equalsIgnoreCase("Random Address1")) {
					attributeValue = lblStreet_Adress_Textbox1.toUpperCase();
				}
				Assert.assertEquals(lblStreet_Adress_Textbox1, attributeValue);
				break;

			case "Street Adress Textbox2":
				String lblStreet_Adress_Textbox2 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/street_address_2"))
						.getText();
				if (attributeValue.equalsIgnoreCase("Random Address2")) {
					attributeValue = lblStreet_Adress_Textbox2.toUpperCase();
				}
				Assert.assertEquals(lblStreet_Adress_Textbox2, attributeValue);
				break;

			case "Street Adress Textbox3":
				String lblStreet_Adress_Textbox3 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/street_address_3"))
						.getText();
				if (attributeValue.equalsIgnoreCase("Random Address3")) {
					attributeValue = lblStreet_Adress_Textbox3.toUpperCase();
				}
				Assert.assertEquals(lblStreet_Adress_Textbox3, attributeValue);
				break;

			case "Street Adress Textbox4":
				holdingSettings_pageobject.scroll.ScrollDown();
				Hardwait.staticWait(10000);
				String lblStreet_Adress_Textbox4 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/street_address_4"))
						.getText();
				if (attributeValue.equalsIgnoreCase("Random Address4")) {
					attributeValue = lblStreet_Adress_Textbox4.toUpperCase();
				}
				Assert.assertEquals(lblStreet_Adress_Textbox4, attributeValue);
				break;

			case "Street Adress Textbox5":
				String lblStreet_Adress_Textbox5 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/street_address_5"))
						.getText();
				if (attributeValue.equalsIgnoreCase("Random Address5")) {
					attributeValue = lblStreet_Adress_Textbox5.toUpperCase();
				}
				Assert.assertEquals(lblStreet_Adress_Textbox5, attributeValue);
				break;

			case "Post Code Textbox":
				String lblPost_Code_Textbox = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/postcode_label"))
						.getText();
				Assert.assertEquals(lblPost_Code_Textbox, attributeValue);
				break;

			case "ApplyToAllHoldings":
				String lblApplyToAllHoldings = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/apply_to_all")).getText();
				Assert.assertEquals(lblApplyToAllHoldings, attributeValue);
				break;

			case "ApplyToIndividualHolding":
				String lblApplyToIndividualHolding = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy
								.id("com.linkgroup.android_investorcentre.sit:id/apply_to_individual_holding_toggle"))
						.getText();
				Assert.assertEquals(lblApplyToIndividualHolding, attributeValue);
				break;

			case "Disclaimer Text1":
				String lblDisclaimer_Text1 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/edit_address_note"))
						.getText();
				Assert.assertEquals(lblDisclaimer_Text1, attributeValue);
				break;

			case "Disclaimer Text and link":
				String lblDisclaimer_Text_and_link = ThreadLocalAndroidDriver.getDriver()
						.findElement(
								AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/not_editable_list_click_here"))
						.getText();
				Assert.assertEquals(lblDisclaimer_Text_and_link, attributeValue);
				break;

			case "Next":
				String lblNext = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/button")).getText();
				Assert.assertEquals(lblNext, attributeValue);
				break;

			}
		}
	}

	@Then("I click on Within UK radio button")
	public void i_click_on_within_uk_radio_button() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.AndroidElementRadioBtnwithinUK.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Within UK radio button UI");
		Hardwait.staticWait(10000);
	}
	
	@Then("I click on outside UK radio button")
	public void i_click_on_outside_uk_radio_button() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.AndroidElementRadioBtnOutsideUK.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Within UK radio button UI");
		Hardwait.staticWait(10000);
	}

	@Then("I enter street address details as below")
	public void i_enter_street_address_details_as_below(List<Map<String, String>> Address) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> AddressDetailsPage : Address) {
			System.out
					.println(AddressDetailsPage.get("AttributeName") + ":" + AddressDetailsPage.get("AttributeValue"));
			String attributeValue = AddressDetailsPage.get("AttributeValue");
			String attributeName = AddressDetailsPage.get("AttributeName");
			switch (attributeName) {

			case "Street Adress 1":
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox1.AndroidDeviceClearInputvalues();
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox1.AndroidDeviceInputvalues(attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Address line 1 entered as " + attributeValue);
				sharedData.put("Adress Line 1", attributeValue);
				break;

			case "Street Adress 2":
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox2.AndroidDeviceClearInputvalues();
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox2.AndroidDeviceInputvalues(attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Address line 2 entered as " + attributeValue);
				sharedData.put("Adress Line 2", attributeValue);
				break;

			case "Street Adress 3":
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox3.AndroidDeviceClearInputvalues();
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox3.AndroidDeviceInputvalues(attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Address line 3 entered as " + attributeValue);
				sharedData.put("Adress Line 3", attributeValue);
				break;

			case "Street Adress 4":
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox4.AndroidDeviceClearInputvalues();
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox4.AndroidDeviceInputvalues(attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Address line 4 entered as " + attributeValue);
				sharedData.put("Adress Line 4", attributeValue);
				break;

			case "Street Adress 5":
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox5.AndroidDeviceClearInputvalues();
				holdingSettings_pageobject.AndroidlblStreetAdressTextbox5.AndroidDeviceInputvalues(attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Address line 5 entered as " + attributeValue);
				sharedData.put("Adress Line 5", attributeValue);
				break;

			}
		}
	}

	@When("I Validate Confirm page screen Labels")
	public void i_validate_confirm_page_screen_labels(List<Map<String, String>> ConfirmPage) throws Exception {

		Thread.sleep(5000);
		for (Map<String, String> AddressDetailsPage : ConfirmPage) {
			System.out
					.println(AddressDetailsPage.get("AttributeName") + ":" + AddressDetailsPage.get("AttributeValue"));
			String attributeValue = AddressDetailsPage.get("AttributeValue");
			String attributeName = AddressDetailsPage.get("AttributeName");
			switch (attributeName) {

			case "Confirm Page Header":
				/*
				 * String lblConfirm_Page_Header = ThreadLocalAndroidDriver.getDriver()
				 * .findElement(AppiumBy.id(
				 * "com.linkgroup.android_investorcentre.sit:id/street_address")) .getText(); if
				 * (attributeValue.equalsIgnoreCase("Confirm")) { attributeValue =
				 * "STREET ADDRESS1"; } Assert.assertEquals(lblConfirm_Page_Header,
				 * attributeValue);
				 */
				
				break;
				
			case "Disclaimer Text":
				/*
				 * String lblDisclaimer_Text = ThreadLocalAndroidDriver.getDriver()
				 * .findElement(AppiumBy.id(
				 * "com.linkgroup.android_investorcentre.sit:id/street_address_2")) .getText();
				 * if (attributeValue.
				 * equalsIgnoreCase("Please confirm that you wish to proceed with following updates"
				 * )) { attributeValue = "STREET ADDRESS2"; }
				 * Assert.assertEquals(lblDisclaimer_Text, attributeValue);
				 */
				
				break;
				
			case "Address Section":
				/*
				 * String lblAddress_Section = ThreadLocalAndroidDriver.getDriver()
				 * .findElement(AppiumBy.id(
				 * "com.linkgroup.android_investorcentre.sit:id/address")) .getText(); if
				 * (attributeValue.equalsIgnoreCase("Address")) { attributeValue =
				 * "STREET ADDRESS1 STREET ADDRESS2 STREET ADDRESS3 STREET ADDRESS4 STREET ADDRESS5 GG7 5BT"
				 * ; } Assert.assertEquals(lblAddress_Section, attributeValue);
				 */
				
				break;
				
			case "Apply To Section":
				/*
				 * String lblApply_To_Section = ThreadLocalAndroidDriver.getDriver()
				 * .findElement(AppiumBy.id(
				 * "com.linkgroup.android_investorcentre.sit:id/postcode_label")) .getText(); if
				 * (attributeValue.equalsIgnoreCase("Apply To")) { attributeValue = "Postcode";
				 * } Assert.assertEquals(lblApply_To_Section, attributeValue);
				 */
				break;
				
			case "Update":
				String lblUpdate = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/button")).getText();
				if (attributeValue.equalsIgnoreCase("Confirm")) {
					attributeValue = "Update";
				}
				Assert.assertEquals(lblUpdate, attributeValue);
				break;
				
			}
		}
	}
	
	@When("I Validate Address update Success page Screen Labels")
	public void i_validate_address_update_success_page_screen_labels(List<Map<String, String>> SuccessPage) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> AddressDetailsPage : SuccessPage) {
			System.out
					.println(AddressDetailsPage.get("AttributeName") + ":" + AddressDetailsPage.get("AttributeValue"));
			String attributeValue = AddressDetailsPage.get("AttributeValue");
			String attributeName = AddressDetailsPage.get("AttributeName");
			switch (attributeName) {

			case "success":
				String lblsuccess = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/success_title"))
						.getText();
				Assert.assertEquals(lblsuccess, attributeValue);
				break;

			case "InstructionalText1":
				String lblInstructionalText1 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/message")).getText();
				Assert.assertEquals(lblInstructionalText1, attributeValue);
				break;
				
			case "InstructionalText2":
				String lblInstructionalText2 = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/sub_message")).getText();
				Assert.assertEquals(lblInstructionalText2, attributeValue);
				break;

			case "done":
				String lbldone = ThreadLocalAndroidDriver.getDriver()
						.findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/back_btn")).getText();
				Assert.assertEquals(lbldone, attributeValue);
				break;
				
			}
		}
	}
	
	@Then("I click on Toggle button for Individual holding")
	public void i_click_on_toggle_button_for_individual_holding() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.AndroidElementRadioBtnToggle.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Toggle button for Individual holding");
		Hardwait.staticWait(10000);
	}
	
	@When("I click on Payment Instructions Button UI")
	public void i_click_on_Payment_Instructions_button_ui() {
		Hardwait.staticWait(10000);
		holdingSettings_pageobject.AndroidElementbtnpaymentInstruction.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Adress Details on UI");
		Hardwait.staticWait(10000);
	}
	
	@Then("I select {string} from the Country dropdown")
	public void i_select_from_the_country_dropdown(String CountryName) {
		holdingSettings_pageobject.AndroidElementCountrydropdown.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Country dropdown on UI");
		holdingSettings_pageobject.AndroidElementtextboxCountry.AndroidDeviceInputvalues(CountryName);
		ExtentCucumberAdapter.addTestStepLog("Entered country name as " + CountryName);
		holdingSettings_pageobject.AndroidElementSelectCountry.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Selected country from dropdown " + CountryName);
	}
	
	@Then("I select Payment type as {string}")
	public void i_select_payment_type_as(String paymentType) {
		holdingSettings_pageobject.AndroidElementdropdownpaymentType.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Payment type dropdown on UI");
		holdingSettings_pageobject.AndroidElementSelectPaymentType.AndroidElementClick();
		ExtentCucumberAdapter.addTestStepLog("Selected Payment type");
	}

}
