package stepDefination;

import java.util.List;
import java.util.Map;

import ElementsFactory.Browser;
import Hardwait.Hardwait;
import io.cucumber.java.en.And;
import pageObject.AddressDetailsPage;
import pageObject.CommunicationPreferencesPage;
import pageObject.HoldingDetailsPage;
import pageObject.PaymentHistoryPage;
import pageObject.PaymentInstructionsPage;
import pageObject.TaxDetailsPage;

public class HoldingDetailsSteps {
		
	HoldingDetailsPage holdingDetailsobj=null;
	
	CommunicationPreferencesPage communicationPreferences_PageObject=null;
	AddressDetailsPage addressUpdate_PageObject=null;
	PaymentHistoryPage paymentHistory_PageObject=null;
	TaxDetailsPage taxDetails_PageObject=null; 
	PaymentInstructionsPage paymentInstructions_PageObject=null;
	
	Browser browser= new Browser();
	public HoldingDetailsSteps() {
		holdingDetailsobj=new HoldingDetailsPage();
		communicationPreferences_PageObject = new CommunicationPreferencesPage();
		addressUpdate_PageObject = new AddressDetailsPage();
		paymentHistory_PageObject= new PaymentHistoryPage();
		taxDetails_PageObject= new TaxDetailsPage();
		paymentInstructions_PageObject= new PaymentInstructionsPage();
	}

	@And("I navigate to {string} Page")
	public void I_Navigate_To_Page(String pages) {
		Hardwait.staticWait(5000);
		switch (pages) {
		case "CommunicationsOptionsUpdate":
			holdingDetailsobj.lnkCommunicationPreference.Click();
			communicationPreferences_PageObject.lblCommunicationPreferences.verifyText("Communication Preferences");
			browser.Navigatebackward();
			break;
		case "AddressUpdate":
			holdingDetailsobj.lnkAddressUpdate.Click();
			addressUpdate_PageObject.lblAddressUpdate.verifyText("Address Details");
			browser.Navigatebackward();
			break;
		case "PaymentHistory":
			holdingDetailsobj.lnkPaymentHistory.Click();
			paymentHistory_PageObject.lblPaymentHistory.verifyText("Payment History");
			browser.Navigatebackward();
			break;
		case "PaymentInstructionsUpdate":
			holdingDetailsobj.lnkPaymentInstructionsUpdate.Click();
			paymentInstructions_PageObject.lblPaymentInstructions.verifyText("Payment Instructions");
			browser.Navigatebackward();
			break;
		default:
			break;
		}
	}
	
	@And("I Validate Navigation to potfolio Screen")
	public void I_Navigate_To_Portfolio_Page(List<Map<String,String>> holdingDetails) {
		for(Map<String, String> holding:holdingDetails) {
			System.out.println(holding.get("NavigateTo")+":"+holding.get("VerifyTitle"));
			switch (holding.get("NavigateTo")) {
				case "CommunicationsOptionsUpdate":
					holdingDetailsobj.lnkCommunicationPreference.Click();
					Hardwait.staticWait(5000);
					communicationPreferences_PageObject.lblCommunicationPreferences.verifyText(holding.get("VerifyTitle"));
					browser.Navigatebackward();
					break;
				case "AddressUpdate":
					holdingDetailsobj.lnkAddressUpdate.Click();
					Hardwait.staticWait(5000);
					addressUpdate_PageObject.lblAddressUpdate.verifyText(holding.get("VerifyTitle"));
					browser.Navigatebackward();
					break;
				case "PaymentHistory":
					holdingDetailsobj.lnkPaymentHistory.Click();
					Hardwait.staticWait(5000);
					paymentHistory_PageObject.lblPaymentHistory.verifyText(holding.get("VerifyTitle"));
					browser.Navigatebackward();
					break;
				case "PaymentInstructionsUpdate":
					holdingDetailsobj.lnkPaymentInstructionsUpdate.Click();
					Hardwait.staticWait(5000);
					paymentInstructions_PageObject.lblPaymentInstructions.verifyText(holding.get("VerifyTitle"));
					browser.Navigatebackward();
					break;
				default:
					break;
			}
		}
	}
	
	
	
	@And("I navigate to Menu {string} with {string}")
	public void I_navigate_to_Menu(String menuKey,String menuValue) {
		switch (menuKey) {
		case "Communications":
			
			break;
		}
	}
}
