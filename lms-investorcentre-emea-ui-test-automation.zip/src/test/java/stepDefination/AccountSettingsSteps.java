package stepDefination;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.ThreadLocalAndroidDriver;
import Hardwait.Hardwait;
import io.appium.java_client.AppiumBy;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.AccountSettingsPage;
import pageObject.CommunicationPreferencesPage;
import pageObject.LoginPage;
import pageObject.PortfolioPage;
import pageObject.SettingsPage;

public class AccountSettingsSteps {
	AccountSettingsPage accountSettingsObj=null;
	LoginPage loginPageObj=null;
	
	public AccountSettingsSteps() {
		accountSettingsObj = new AccountSettingsPage();
		loginPageObj = new LoginPage();
	}
	
	@Then("I Validate Title of {string} Screen")
	public void IValidateTitleAccount(String lblaccount) {
		String lblAccounts = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/title")).getText();
		if (lblAccounts.equalsIgnoreCase(lblaccount)) {
			ExtentCucumberAdapter.addTestStepLog("Label "+lblAccounts+" Matches with "+lblaccount);
		}else{
			Assert.fail("Label "+lblAccounts+" NOT Matches with "+lblaccount);
		}
	}
	
	
	@Then("I Validate label {string} Remove your Accounts")
	public void RemoveYourAccounts(String lblaccount) throws Exception{
		Thread.sleep(2000);
		String lblAccounts = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/alertTitle")).getText();
		if (lblAccounts.equalsIgnoreCase(lblaccount)) {
			ExtentCucumberAdapter.addTestStepLog("Label "+lblAccounts+" Matches with "+lblaccount);
		}else{
			Assert.fail("Label "+lblAccounts+" NOT Matches with "+lblaccount);
		}
	}
	
	
	@Then("I Validate label {string} Remove your Accounts undo sections")
	public void RemoveYourAccountsundo(String lblaccount) throws Exception{
		Thread.sleep(2000);
		String lblAccounts = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/message")).getText();
		if (lblAccounts.equalsIgnoreCase(lblaccount)) {
			ExtentCucumberAdapter.addTestStepLog("Label "+lblAccounts+" Matches with "+lblaccount);
		}else{
			Assert.fail("Label "+lblAccounts+" NOT Matches with "+lblaccount);
		}
	}
	
	
	@Then("I Validate {string} on Create PIN screen")
	public void CreatePINscreen(String lblaccount) throws Exception{
		Thread.sleep(2000);
		String lblAccounts = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/toolbar_title")).getText();
		if (lblAccounts.equalsIgnoreCase(lblaccount)) {
			ExtentCucumberAdapter.addTestStepLog("Label "+lblAccounts+" Matches with "+lblaccount);
		}else{
			Assert.fail("Label "+lblAccounts+" NOT Matches with "+lblaccount);
		}
	}
	
	
	@When("User click on Remove Account From Device")
	public void RemoveAccountfromDevice() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/remove_account_label")).click();
		Hardwait.staticWait(10000);
	}
	
	@When("User click on Cancel Remove Account From Device")
	public void CancelRemoveAccountfromDevice() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/button2")).click();
		Hardwait.staticWait(10000);
	}
	
	@When("I click on Account Button UI")
	public void click_on_Account_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/account_btn")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@And("I click on Manage Pin on device UI")
	public void click_on_ManagePin_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/manage_pin")).click();
		Hardwait.staticWait(10000);
	}
	
	@And("I click on Enable PIN")
	public void click_on_EnablePin_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/enable_pin")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@When("I click on Logout Button UI")
	public void click_on_Logout_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/logout")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@When("I click on User Settings Button UI")
	public void click_on_User_Settings_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/user_settings_label")).click();
		Hardwait.staticWait(10000);
	}

	@When("I click on Change Portfolio Password Button UI")
	public void click_on_User_Change_Portfolio_Password_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/portfolio_password")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@When("I click on Delete Account Button UI")
	public void click_on_DeleteAccount_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/delete_account")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@And("I click on Delete Account Button on Delete Account Screen")
	public void click_on_DeleteAccountScreen_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/delete_label")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@Then("I click on cancel Button on Delete Account screen")
	public void click_on_cancelDeleteAccountScreen_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/button2")).click();
		Hardwait.staticWait(10000);
	}
	
	@And("I Click on Confirm Button on User Settings screen")
	public void I_Click_on_Confirm_Button_on_User_Settings_screen() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/button")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@And("I click on Terms & Conditions")
	public void Terms_Conditions() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/terms_and_conditions")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@Then("I Validate Title of {string} T&C Screen")
	public void IValidateTitleT_C(String lblaccount) {
		String lblAccounts = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/title")).getText();
		if (lblAccounts.equalsIgnoreCase(lblaccount)) {
			ExtentCucumberAdapter.addTestStepLog("Label "+lblAccounts+" Matches with "+lblaccount);
		}else{
			Assert.fail("Label "+lblAccounts+" NOT Matches with "+lblaccount);
		}
	}
	
	@When("I click on App Settings Button UI")
	public void click_on_App_Settings_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/app_settings")).click();
		Hardwait.staticWait(10000);
	}
	
	@When("I click on Holding Settings Button UI")
	public void click_on_Holding_Settings_Button_UI() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/holding_settings")).click();
		Hardwait.staticWait(10000);
	}

	@And("I Validate Accounts Screen Labels")
	public void I_Validate_Navigation_to_Tabs_on_LIC (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(10000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "UserSettings":
					String lblUserSettings = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/user_settings_label")).getText();
					Assert.assertEquals(lblUserSettings, attributeValue);
					break;
				case "HoldingSettings":
					String lblHoldingSettings = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/holding_settings_label")).getText();
					Assert.assertEquals(lblHoldingSettings, attributeValue);
					break;
				case "AppSettings":
					String lblAppSettings = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/app_settings_label")).getText();
					Assert.assertEquals(lblAppSettings, attributeValue);
					break;
				case "RevisitOnboarding":
					String lblRevisitOnboarding = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.TextView[@text='Re-visit Onboarding']")).getText();
					Assert.assertEquals(lblRevisitOnboarding, attributeValue);
					break;
				case "TermsAndConditions":
					String lblTermsAndConditions = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.TextView[@text='Terms & Conditions']")).getText();
					Assert.assertEquals(lblTermsAndConditions, attributeValue);
					break;
				case "ContactUs":
					String lblContactUs = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.TextView[@text='Contact Us']")).getText();
					Assert.assertEquals(lblContactUs, attributeValue);
					break;	
				case "RemoveAccountFromDevice":
					String lblRemoveAccountFromDevice = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/remove_account_label")).getText();
					Assert.assertEquals(lblRemoveAccountFromDevice, attributeValue);
					break;	
				case "LogOut":
					String lblLogOut = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/logout")).getText();
					Assert.assertEquals(lblLogOut, attributeValue);
					break;	
			}
		}
	}
	
	
	
	@And("I Validate User Settings SubSection Labels")
	public void I_Validate_User_Settings_SubSection_Labels (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "ChangePortfolioPassword":
					String lblChangePortfolioPassword = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/portfolio_password")).getText();
					Assert.assertEquals(lblChangePortfolioPassword, attributeValue);
					break;
				case "ChangeLoginEmail":
					String lblChangeLoginEmail = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/login_email")).getText();
					Assert.assertEquals(lblChangeLoginEmail, attributeValue);
					break;
				case "ResetMultiFactorAuthentication":
					String lblResetMultiFactorAuthentication = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/change_mfa")).getText();
					Assert.assertEquals(lblResetMultiFactorAuthentication, attributeValue);
					break;
				case "DeleteAccount":
					String lblDeleteAccount = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/delete_account")).getText();
					Assert.assertEquals(lblDeleteAccount, attributeValue);
					break;
			}
		}
	}
	
	@And("I Validate Delete Account Screen Labels")
	public void I_Validate_Delete_Account_Screen_Labels(List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "deleteAccount":
					String lbldeleteAccount = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.TextView[@text='DELETE ACCOUNT']")).getText();
					Assert.assertEquals(lbldeleteAccount, attributeValue);
					break;
			}
		}
	}
	
	@And("I Validate Delete Account Pop up Labels")
	public void I_Validate_Delete_Account_PopupLabels(List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "DeleteAccount":
					String lbldeleteAccount = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/alertTitle")).getText();
					Assert.assertEquals(lbldeleteAccount, attributeValue);
					break;
				case "DeleteyourPortfolioAccount":
					String lblDeleteyourPortfolioAccount = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/message")).getText();
					Assert.assertEquals(lblDeleteyourPortfolioAccount, attributeValue);
					break;	
			}
		}
	}
	
	
	@And("I Validate Labels on USER SETTINGS page")
	public void I_Validate_Labels_on_USER_SETTINGS_page(List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "ChangePortfolioPassword":
					String lblChangePortfolioPassword = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/header")).getText();
					Assert.assertEquals(lblChangePortfolioPassword, attributeValue);
					break;
				case "UserSettings":
					String lblUserSettings = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.TextView[@text='USER SETTINGS']")).getText();
					Assert.assertEquals(lblUserSettings, attributeValue);
					break;
			}
		}
	}
	
	@And("I Enter User Name Password and Confirm Password on User Settings screen")
	public void I_Validate_UserNamePassword_on_USER_SETTINGS_page(List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "CurrentPassword":
					ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/current_password")).sendKeys(attributeValue);
					break;
				case "NewPassword":
					ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/new_password")).sendKeys(attributeValue);
					break;
				case "ConfirmPassword":
					ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/confirm_password")).sendKeys(attributeValue);
					break;	
			}
		}
	}
	
	@And("I Validate Labels on Success Message Alert")
	public void I_Validate_Labels_on_Success_Message_Alert(List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "Success":
					String lblSuccess = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/alertTitle")).getText();
					Assert.assertEquals(lblSuccess, attributeValue);
					break;
				case "successfullychanged":
					String lblsuccessfullychanged = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/message")).getText();
					Assert.assertEquals(lblsuccessfullychanged, attributeValue);
					break;
			}
		}
	}
	
	
	@And("I Validate Holding Settings SubSection Labels")
	public void I_Validate_Holding_Settings_SubSection_Labels (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "AddressDetails":
					String lblAddressDetails = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/address_details")).getText();
					Assert.assertEquals(lblAddressDetails, attributeValue);
					break;
				case "CommunicationPreferences":
					String lblCommunicationPreferences = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/communication_preferences")).getText();
					Assert.assertEquals(lblCommunicationPreferences, attributeValue);
					break;
				case "PaymentInstructions":
					String lblPaymentInstructions = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/payment_instructions")).getText();
					Assert.assertEquals(lblPaymentInstructions, attributeValue);
					break;
			}
		}
	}
	
	
	@And("I Validate App Settings SubSection Labels")
	public void I_Validate_App_Settings_SubSection_Labels (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "Managepin":
					String lblManagepin = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/manage_pin")).getText();
					Assert.assertEquals(lblManagepin, attributeValue);
					break;
				case "ManageFingerprintandFaceID":
					String lblManageFingerprintandFaceID = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/manage_fingerprint_face_id")).getText();
					Assert.assertEquals(lblManageFingerprintandFaceID, attributeValue);
					break;
			}
		}
	}
	
	
	@And("I Validate Logout Logout SubSection Labels")
	public void AccountsScreenLabels (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "Logout":
					String lblManagepin = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/alertTitle")).getText();
					Assert.assertEquals(lblManagepin, attributeValue);
					break;
				case "Areyousure":
					String lblManageFingerprintandFaceID = ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/message")).getText();
					Assert.assertEquals(lblManageFingerprintandFaceID, attributeValue);
					break;
			}
		}
	}
	
	@When("User click on Cancel Button on device")
	public void Cancel_Button_on_device() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/button2")).click();
		Hardwait.staticWait(10000);
	}
	
	@When("I click on ok button on Pop up")
	public void I_click_on_ok_button_on_Pop_up() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/button1")).click();
		Hardwait.staticWait(10000);
	}
	
	@When("User click on Logout Button on device")
	public void Logout_Button_on_device() {
		Hardwait.staticWait(10000);
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("android:id/button1")).click();
		Hardwait.staticWait(10000);
	}
	
	
	@Then("I Click on Logout button")
	public void i_click_on_logout_button() {
		accountSettingsObj.actions.IOSScrollDown();
		accountSettingsObj.iosElementbtnLogout.IOSElementClick();
	}	
	
	@When("i validate the pop up Alert dialog for Logout")
	public void i_validate_the_pop_up_alert_dialog_for_logout() {
		accountSettingsObj.iosElementlblLogout.iosElementgetLabelIsDisplayed();
		accountSettingsObj.iosElementlblAreYouSureYouwanttoLogout.iosElementgetLabelIsDisplayed();
		accountSettingsObj.iosElementlblCancel.iosElementgetLabelIsDisplayed();
	}
	
	@When("I Click on Alert Logout Button")
	public void i_click_on_alert_logout_button() {
		accountSettingsObj.iosElementbtnLogOut.IOSElementClick();
		try {
			Hardwait.staticWait(10000);
			loginPageObj.iosElementpopupbtnContinue.IOSElementClick();
			Hardwait.staticWait(10000);
		}catch (StaleElementReferenceException e) {
			System.out.println("Caught StaleElementReferenceException!!");
		}catch (ElementNotInteractableException e) {
			System.out.println("Caught ElementNotInteractableException!!");
		}catch (TimeoutException e) {
			System.out.println("Caught TimeoutException!!");
		}catch (NullPointerException e) {
			System.out.println("Caught NullPointerException!!");
		}
	}
	
	
	@When("I Click on App Settings Accounts Menu Button")
	public void i_click_on_app_settings_accounts_menu_button() {
		accountSettingsObj.iosElementbtnAccountSettings.IOSElementClick();
	}
	
	@When("I Click on Re-visit Onboarding Accounts Menu Button")
	public void i_click_on_Re_visit_Onboarding_accounts_menu_button() {
		accountSettingsObj.iosElementbtnReVisitOnBoarding.IOSElementClick();
	}
	
	
	@When("I Click on Terms & Conditions Accounts Menu Button")
	public void i_click_on_Terms_Conditions_accounts_menu_button() {
		accountSettingsObj.iosElementbtnTermsConditions.IOSElementClick();
	}
	
	@When("I Click on User Settings Accounts Menu Button")
	public void i_click_on_user_settings_accounts_menu_button() {
		accountSettingsObj.iosElementbtnUserSettings.IOSElementClick();
	}
	
	@When("i Click on Delete Account Option")
	public void i_click_on_delete_account_option() {
	    accountSettingsObj.iosElementbtnDeleteAccount.IOSElementClick();
	}
	
	@Then("I click on Cancel Button on IOS")
	public void i_click_on_cancel_button_on_ios() {
		accountSettingsObj.iosElementbtnCancelAccount.IOSElementClick();
	
	}
	
	@When("I Validate landing on terms & Conditions screen")
	public void i_validate_landing_on_terms_conditions_screen() {
		accountSettingsObj.iosElementlblTermsConditionsTitle.iosElementgetLabelIsDisplayed();
		accountSettingsObj.actions.IOSScrollDown();
	}
	
	@Then("I click on Manage Pin on App Settings iOS")
	public void i_click_on_manage_pin_on_app_settings_i_os() {
		accountSettingsObj.iosElementbtnManagePin.IOSElementClick();
	}
	
	
	@Then("I Enable PIN on App Settings iOS")
	public void i_enable_pin_on_app_settings_i_os() {
		accountSettingsObj.iosElemementbtnEnablePin.IOSElementClick();
	}
	
	
	@And("User should navigate to App Settings Screen with below Details")
	public void User_should_navigate_to_App_Settings_Screen_with_below_Details (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "TgleBtnEnablePIN":
					accountSettingsObj.iosElemementbtnEnablePin.IOSElementIsEnabled();
					break;
				case "BtnChnagePIN":
					accountSettingsObj.iosElementbtnChangePin.IOSElementIsDisplayed();
					break;
			}
		}
	}
	
	@When("I click on Back Button on iOS device")
	public void i_click_on_back_button_on_i_os_device() {
		accountSettingsObj.iosElementbtnNavigationBackBtn.IOSElementClick();
	}	
	
	@When("I click on Back Button 2 on iOS device")
	public void i_click_on_back_button2_on_i_os_device() {
		accountSettingsObj.iosElementbtnNavigationBackBtn2.IOSElementClick();
	}
	
	@Then("I Remove Account From Device on IOS")
	public void i_remove_account_from_device_on_ios() {
		accountSettingsObj.iosElementbtnRemoveAccountFromDevice.IOSElementClick();
	}
	
	@When("I click on cancel on IOS for Remove Accounton IOS")
	public void i_click_on_cancel_on_ios_for_remove_accounton_ios() {
		accountSettingsObj.iosElementbtnCancelAccountFromDevice.IOSElementClick();
	}
	
	@And("User should navigate to User Settings Screen with below Details")
	public void User_should_navigate_to_User_Settings_Screen_with_below_Details (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "ChangePortfolioPasswordlbl":
						accountSettingsObj.iosElementlblPortfolioPasswordDevice.iosElementgetLabelIsDisplayed();
					break;
				case "ChangeLoginEmaillbl":
						accountSettingsObj.iosElementlblChangeLoginEmailDevice.iosElementgetLabelIsDisplayed();
					break;
				case "ResetMultiFactorAuthenticationlbl":
						accountSettingsObj.iosElementlblResetMultiFactorAuthDevice.iosElementgetLabelIsDisplayed();
					break;
				case "DeleteAccountlbl":
						accountSettingsObj.iosElementlblDeleteAccountDevice.iosElementgetLabelIsDisplayed();
					break;	
			}
		}
	}
	
	@When("I click on Change Portfolio Password")
	public void i_click_on_change_portfolio_password() {
	    accountSettingsObj.iosElementbtnPortfolioPasswordDevice.IOSElementClick();
	}
	
//	| CurrentPassword | Investor@333    |
//    | NewPassword     | Investor@444    |
//    | ConfirmPassword | Investor@444    |
	
	@And("I Enter the values for Change Portfolio Passord for IOS")
	public void I_Enter_the_values_for_Change_Portfolio_Passord_for_IOS (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeName = portfolio.get("AttributeName");
			String attributeValue = portfolio.get("AttributeValue");
			switch (attributeName) {
				case "CurrentPassword":
					    accountSettingsObj.iosElementbtnCurrentPasswordDevice.IOSElementClick();
						accountSettingsObj.iosElementtxtCurrentPasswordDevice.IOSDeviceInputvalues(attributeValue);
					break;
				case "NewPassword":
//					    accountSettingsObj.iosElementbtnNewPasswordDevice.IOSElementClick();
						accountSettingsObj.iosElementtxtNewPasswordDevice.IOSDeviceInputvalues(attributeValue);
					break;
				case "ConfirmPassword":
//					    accountSettingsObj.iosElementbtnConfirmPasswordDevice.IOSElementClick();
						accountSettingsObj.iosElementtxtConfirmPasswordDevice.IOSDeviceInputvalues(attributeValue);
					break;
			}
		}
	}
	
	@When("I click on Change Login Email Password for IOS")
	public void i_click_on_change_login_email_password_for_ios() {
		accountSettingsObj.iosElementbtnDoneDevice.IOSElementClick();
		accountSettingsObj.iosElementbtnConfirmDevice.IOSElementClick();
	}
	
	
	@Then("I validate the Label {string} and {string}")
	public void i_validate_the_label_and(String lblSuccess, String lblYourPasswordhasBeenSuccessfullyChanged) throws Exception{
		Thread.sleep(15000);
//		accountSettingsObj.iosElementlblSuccessDevice.iosElementgetLabelIsDisplayed();
//		accountSettingsObj.iosElementlblYourPasswordhasBeenSuccessDevice.iosElementgetLabelIsDisplayed();
	}

	@Then("I click on OK Letts Go Button")
	public void i_click_on_ok_letts_go_button() {
		accountSettingsObj.iosElementbtnOkGotItDevice.IOSElementTap();
	}
	
	
	@And("I Validate Landing on Accouns Screen with Below Details")
	public void i_validate_landing_on_accouns_screen_with_below_details (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(10000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "lblUserSettings":
					accountSettingsObj.iosElementlblUserSettings.iosElementgetLabelIsDisplayed();
					break;
				case "lblHoldingSettings":
					accountSettingsObj.iosElementlblHoldingSettings.iosElementgetLabelIsDisplayed();
				break;
				case "lblAppSettings":
					accountSettingsObj.iosElementlblAppSettings.iosElementgetLabelIsDisplayed();
					break;
				case "lblReVisitOnBoarding":
					accountSettingsObj.iosElementlblReVisitOnBoarding.iosElementgetLabelIsDisplayed();
					break;
				case "lblTermsAndConditions":
					accountSettingsObj.iosElementlblTermsandConditions.iosElementgetLabelIsDisplayed();
					break;
				case "lblContactus":
					accountSettingsObj.iosElementlblContactUs.iosElementgetLabelIsDisplayed();
					break;
				case "lblDeleteAccount":
					accountSettingsObj.iosElementlblRemoveAccount.iosElementgetLabelIsDisplayed();
					break;	
				case "lblLogoutAccount":
					accountSettingsObj.iosElementlblAccountLogout.iosElementgetLabelIsDisplayed();
					break;	
				
				case "lblChangePortfolioPassword":
					accountSettingsObj.iosElementlblChangePortfolioPassword.iosElementgetLabelIsDisplayed();
					break;	
					
				case "lblChangeLoginEmail":
					accountSettingsObj.iosElementlblChangeLoginEmail.iosElementgetLabelIsDisplayed();
					break;	
					
				case "lblResetMultiFactorAuthentication":
					accountSettingsObj.iosElementlblResetMultifactorAuth.iosElementgetLabelIsDisplayed();
					break;	
					
				case "lblDelAccount":
					accountSettingsObj.iosElementlblDeleteAccount.iosElementgetLabelIsDisplayed();
					break;		
				
				case "lblAddressDetails":
					accountSettingsObj.iosElementlblAddressDetailsAccounts.iosElementgetLabelIsDisplayed();
					break;		

					
				case "lblCommunicationPreferences":
					accountSettingsObj.iosElementlblCommunicationPref.iosElementgetLabelIsDisplayed();
					break;		

					
				case "lblPaymentInst":
					accountSettingsObj.iosElementlblpaymentInst.iosElementgetLabelIsDisplayed();
					break;		

					
				case "lblDividentreinvestment":
					accountSettingsObj.iosElementlblDividendReinvestment.iosElementgetLabelIsDisplayed();
					break;		
					
				case "lblManagePIN":
					accountSettingsObj.iosElementlblManagePIN.iosElementgetLabelIsDisplayed();
				break;
				
				case "lblManageFaceID":
					accountSettingsObj.iosElementlblManageFaceID.iosElementgetLabelIsDisplayed();
				break;
			}
		}
	}
	
	@Then("I click on User Settings on Accounts screen IOS")
	public void i_click_on_user_settings_on_accounts_screen_ios() {
		accountSettingsObj.iosElementbtnUserSettings.IOSElementClick();
	}
	
	@Then("I click on Back Button IOS")
	public void i_click_on_back_button_ios() {
		accountSettingsObj.iosElementbtnBackButton.IOSElementClick();
	}
	
	@Then("I click on Holding Settings screen IOS")
	public void i_click_on_holding_settings_screen_ios() {
		accountSettingsObj.iosElementbtnHoldingSettings.IOSElementClick();
	}
	
	@Then("I click on App Settings screen IOS")
	public void i_click_on_app_settings_screen_ios() {
		accountSettingsObj.iosElementbtnAppSettings.IOSElementClick();
	}
	
	@Then("I click on Communication Preferences screen IOS")
	public void i_click_on_CommunicationPreferences_settings_screen_ios() {
		accountSettingsObj.iosElementbtnCommunicationPref.IOSElementClick();
	}
	
	@Then("I validate Email is updated as {string}")
	public void i_validate_email_is_updated_as(String lblEmailAddress) {
		accountSettingsObj.iosElementlblEmailAddressUpdated.iosElementgetLabelIsDisplayed(lblEmailAddress);
	}
	
	
}
