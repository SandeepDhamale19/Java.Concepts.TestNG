package stepDefination;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.ThreadLocalDriver;
import Hardwait.Hardwait;
import ScreenshotFactory.TakeScreenshot;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.Commonfunctions;
import pageObject.CommunicationPreferencesPage;
import pageObject.VotingPage;

public class VotingSteps {

	VotingPage votingPage = null;
	Commonfunctions commonfunctions = null;

	SoftAssert softAssert = new SoftAssert();

	public static WebDriver driver = null;
	JavascriptExecutor JavaScriptExec = (JavascriptExecutor) driver;

	public VotingSteps() {
		votingPage = new VotingPage();
		commonfunctions = new Commonfunctions();
	}

	/*
	 * Functionality: Click on Voting menu Date:09/02/2024 Author: Amit
	 */
	@When("I click on voting menu")
	public void i_click_on_voting_menu() {
		if (votingPage.btnlstvotingmenu.GetNoOfWebElements().size() > 0) {
			votingPage.btnvotingmenu.Click();
		}
		ExtentCucumberAdapter.addTestStepLog("Clicked on Vote Menu");
		new TakeScreenshot();
	}

	@Then("I click on {string} radio button on voting direction page")
	public void i_click_on_radio_button_on_voting_direction_page(String radiobutton) {
		String Radiobutton = radiobutton;
		switch (Radiobutton) {

		case "Discretionary":

			for (int i = 1; i <= votingPage.btnDiscretionaryradiobtn.GetListOfWebElements().size(); i++) {
				WebElement ele_Discretionary = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//input[@value='Open'])[" + i + "]"));
				if (ele_Discretionary.isSelected()) {
					ExtentCucumberAdapter.addTestStepLog("Radio button is already selected");
				} else {
					ele_Discretionary.click();
				}

				new TakeScreenshot();
			}
			break;
		}
	}

	@Then("I click on Vote button")
	public void i_click_on_vote_button() {
		votingPage.btnvote.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Vote Link");
	}

	@Then("I click on Ask a question")
	public void i_click_on_ask_a_question() {
		votingPage.btnaskquestion.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Ask a question link");
	}

	@Then("I Validate Dropdown list with value as {string}")
	public void I_Validate_DropDownListtest(String lbloption) {
		votingPage.btndropdown.Click();
		new TakeScreenshot();
		votingPage.lblOption.verifyLabelonUI(lbloption);
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}

	@Then("I validate Instructional text on screen as {string}")
	public void i_validate_instructional_text_on_screen_as(String lblInstructionalText) {
		votingPage.lblInstructionalText.verifyLabelonUI(lblInstructionalText);
		new TakeScreenshot();
	}

	@Then("I validate title of page as {string}")
	public void i_validate_title_of_page_as(String title) {
		Hardwait.staticWait(5000);
		votingPage.btnheader.scrollToElement();
		votingPage.lblheader.verifyLabelonUI(title);
		new TakeScreenshot();
	}

	@Then("I validate subtitle of page as {string}")
	public void i_validate_subtitle_of_page_as(String title) {

		Hardwait.staticWait(10000);
		votingPage.btnsubheader1.scrollToElement();

		votingPage.lblsubheader1.verifyLabelonUI(title);
		new TakeScreenshot();
	}

	@Then("I validate {string} header is displayed")
	public void i_validate_header_is_displayed(String string) {
		votingPage.lblsubheader3.verifyLabelonUI(string);
		new TakeScreenshot();
	}

	@Then("I validate the success message {string}")
	public void i_validate_the_success_message(String string) {
		Hardwait.staticWait(15000);
		votingPage.lblsubheader1.verifyLabelonUI(string);
		new TakeScreenshot();
	}

	@Then("I validate the Meeting subheader as {string}")
	public void i_validate_the_meeting_subheader_as(String subtitle) {
		votingPage.btnsubheaderAction.scrollToElement();
		votingPage.lblsubheader.verifyLabelonUI(subtitle);
		new TakeScreenshot();
	}

	@Then("Validate the instructional note1 as {string}")
	public void validate_the_instructional_note1_as(String instructionaltext) {
		votingPage.lblinstrText.verifyLabelonUI(instructionaltext);
		new TakeScreenshot();
	}

	@Then("Validate the instructional note2 as {string}")
	public void validate_the_instructional_note2_as(String instructionaltext) {
		votingPage.lblsubheader1.verifyLabelonUI(instructionaltext);
		new TakeScreenshot();
	}

	@Then("validate the Note section with text {string}")
	public void validate_the_note_section_with_text(String notetext) {
		votingPage.lblnotetext.verifyLabelonUI(notetext);
		new TakeScreenshot();
	}

	@Then("validate the instructional text is diplayed in Proxy Appointment page")
	public void validate_the_instructional_text_is_diplayed_in_proxy_appointment_page() {
		votingPage.lblinstructionaltext.getLabelIsDisplayed();
		new TakeScreenshot();
	}

	@Then("I validate the declaration text as {string}")
	public void i_validate_the_declaration_text_as(String declarationtext) {
		votingPage.lblsubheader2.verifyLabelonUI(declarationtext);
		new TakeScreenshot();
	}

	@Then("validate information display area is displayed")
	public void validate_information_display_area_is_displayed() {
		votingPage.btninfodisplay.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("validate info display area in Voting directions page")
	public void validate_info_display_area_in_voting_directions_page() {
		votingPage.gridinfodisplay.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("validate info display area in confirm page")
	public void validate_info_display_area_in_confirm_page() {
		votingPage.gridinfodisplay.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("validate info display area in Proxy Appointment page")
	public void validate_info_display_area_in_Proxy_Appointment_page() {
		votingPage.gridinfodisplay.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("validate resolution list in grid format with option {string},{string}")
	public void validate_resolution_list_in_grid_format_with_option(String option1, String option2) {
		votingPage.gridinfodisplay1.ValidateIsButtonDisplayed();
		votingPage.btnagainst.ValidateIsButtonDisplayed();
		votingPage.btnWithheld.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("validate back and next button is displayed")
	public void validate_back_and_next_button_is_displayed() {
		votingPage.btnback.ValidateIsButtonDisplayed();
		votingPage.btnnext.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("I click on back button")
	public void i_click_on_back_button() {
		votingPage.btnbackAction.scrollToElement();
		new TakeScreenshot();
		votingPage.btnback.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on back button");
		new TakeScreenshot();
	}

	@Then("I click on next button")
	public void i_click_on_next_button() {
		votingPage.btnnext.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Next button");
		new TakeScreenshot();
	}

	@Then("I click on Next button on Voting direction page")
	public void i_click_on_Next_button_on_Voting_direction_page() {
		votingPage.btnnext1.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Next button");
		new TakeScreenshot();
	}

	@Then("I click on Next button on Proxy appointment page")
	public void I_click_on_Next_button_on_Proxy_appointment_page() {
		votingPage.btnnext2.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Next button");
		new TakeScreenshot();
	}

	@Then("Validate back,cancel and Next button is displayed")
	public void validate_back_cancel_and_next_button_is_displayed() {
		votingPage.btnback.ValidateIsButtonDisplayed();
		votingPage.btnback1.ValidateIsButtonDisplayed();
		votingPage.btnnext1.ValidateIsButtonDisplayed();
		new TakeScreenshot();

	}

	@Then("Validate back,cancel and Next button is displayed in Proxy Appointment page")
	public void validate_back_cancel_and_next_button_is_displayed_in_Proxy_Appointment_page() {
		votingPage.btnback.ValidateIsButtonDisplayed();
		votingPage.btnback1.ValidateIsButtonDisplayed();
		votingPage.btnnext2.ValidateIsButtonDisplayed();
		new TakeScreenshot();

	}

	@Then("Validate back,cancel and Confirm button is displayed in confirm page")
	public void validate_back_cancel_and_Confirm_button_is_displayed_in_confirm_page() {
		votingPage.btnback.ValidateIsButtonDisplayed();
		votingPage.btnback1.ValidateIsButtonDisplayed();
		votingPage.btnnext2.ValidateIsButtonDisplayed();
		new TakeScreenshot();

	}

	@Then("validate Done button and Vote on Next Meeting button is dispalyed")
	public void validate_done_button_and_vote_on_next_meeting_button_is_dispalyed() {
		votingPage.btndone.ValidateIsButtonDisplayed();
		votingPage.btnnextmeeting.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("validate vote on next meeting button is displayed")
	public void validate_vote_on_next_meeting_button_is_displayed() {
		votingPage.lblinstructional.scrollToElement();
		Hardwait.staticWait(3000);
		if (votingPage.btnnextmeeting.IsDisplayed()) {
			ExtentCucumberAdapter.addTestStepLog("Vote on next meeting button is displayed on UI");
		}

		else {
			ExtentCucumberAdapter.addTestStepLog("Vote on next meeting button is not displayed on UI");
		}
		new TakeScreenshot();
	}

	@Then("I click on Vote on next meeting")
	public void i_click_on_vote_on_next_meeting() {
		votingPage.btnnextmeeting.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Vote on next meeting button");
		new TakeScreenshot();
	}

	@Then("I click on Confirm button on confirm page")
	public void i_click_on_confirm_button_on_confirm_page() {
		votingPage.btnnext2.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on confirm button");
	}

	@And("I click on Done button on voting success page")
	public void I_click_on_Done_button_on_voting_success_page() {
		votingPage.btndone.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Done button");
	}

	@Then("i click on back button on Proxy appointment page")
	public void i_click_on_back_button_on_Proxy_appointment_page() {
		votingPage.btnback1.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on back button");
	}

	@Then("i click on back button on confirm page")
	public void i_click_on_back_button_on_confirm_page() {
		votingPage.btnback1.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on back button");
	}

	@Then("I click on submit button")
	public void i_click_on_submit_button() {
		votingPage.btnsubmit.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Submit button");
	}

	@Then("validate the yes and No Radio button")
	public void validate_the_yes_and_no_radio_button() {
		votingPage.radiobtnyes.ValidateIsButtonDisplayed();
		new TakeScreenshot();
		votingPage.radiobtnno.ValidateIsButtonDisplayed();
	}

	@Then("validate two radio button are displayed")
	public void validate_two_radio_button_are_displayed() {
		votingPage.btncharirman.ValidateIsButtonDisplayed();
		votingPage.btnanotherperson.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("I validate Return to Meeting list button is available")
	public void i_validate_return_to_meeting_list_button_is_available() {
		votingPage.btnrtnmeetinglist.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("I validate Submit another question button is available")
	public void i_validate_submit_another_question_button_is_available() {
		votingPage.btnsubmitanotherquestion.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("i click on Submit another question button")
	public void i_click_on_submit_another_question_button() {
		votingPage.btnsubmitanotherquestion.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Submit another question");
		new TakeScreenshot();
	}
	
	@Then("I click on Return to meeting list button")
	public void i_click_on_return_to_meeting_list_button() {
		votingPage.btnrtnmeetinglist.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Return to Meeting list");
		new TakeScreenshot();
	}

	@Then("I verify the instructional text is displayed")
	public void i_verify_the_instructional_text_is_displayed() {
		votingPage.lblinstructionaltext1.IsDisplayed();
		String inst1 = ThreadLocalDriver.getDriver().findElement(By.xpath("//form//p")).getText();
		ExtentCucumberAdapter.addTestStepLog("Instructional text is diplayed as -" + inst1);
		new TakeScreenshot();
	}

	@Then("I verify other instructional text is displayed")
	public void i_verify_other_instructional_text_is_displayed() {
		votingPage.lblinstructionaltext4.IsDisplayed();
		String inst2 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//form//p)[2]")).getText();
		ExtentCucumberAdapter.addTestStepLog("Instructional text is diplayed as -" + inst2);
		new TakeScreenshot();
	}

	@Then("I validate the instructional text on Thank you page")
	public void i_validate_the_instructional_text_on_thank_you_page() {
		String inst1 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//p)[5]")).getText();
		ExtentCucumberAdapter.addTestStepLog("Instructional text is diplayed as -" + inst1);

		String inst2 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//p)[6]")).getText();
		ExtentCucumberAdapter.addTestStepLog("Instructional text is diplayed as -" + inst2);

		new TakeScreenshot();
	}

	@Then("I validate the declaration text")
	public void i_validate_the_declaration_text() {
		String inst1 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//p)[6]")).getText();
		ExtentCucumberAdapter.addTestStepLog("Declaration text is diplayed as -" + inst1);
		new TakeScreenshot();
	}

	@Then("I enter text in question text textbox")
	public void i_enter_text_in_question_text_textbox() {

		String text = commonfunctions.generateRandomAlphaString(20);
		votingPage.questiontextbox.ClearInputvalues();
		votingPage.questiontextbox.Inputvalues(text);
		ExtentCucumberAdapter.addTestStepLog("Entered text in question text box");
		new TakeScreenshot();
	}

	@Then("I verify the instructional text is displayed for receipt section")
	public void i_verify_the_instructional_text_is_displayed_for_receipt_section() {
		votingPage.lblinstructional.scrollToElement();
		Hardwait.staticWait(3000);
		votingPage.lblinstructionaltext2.IsDisplayed();
		String inst1 = ThreadLocalDriver.getDriver().findElement(By.xpath("//form//div//p")).getText();
		ExtentCucumberAdapter.addTestStepLog("Instructional text is diplayed as " + inst1);
		votingPage.lblinstructionaltext3.IsDisplayed();
		String inst2 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//p//strong)[2]")).getText();
		ExtentCucumberAdapter.addTestStepLog("Instructional text is diplayed as " + inst2);
		new TakeScreenshot();
	}

	@Then("I select I\\/We wish to appoint another person to vote on my\\/our behalf at the meeting radio button")
	public void i_select_i_we_wish_to_appoint_another_person_to_vote_on_my_our_behalf_at_the_meeting_radio_button() {
		votingPage.btnanotherperson.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog(
				"Clicked on I/We wish to appoint another person to vote on my/our behalf at the meeting radio button");
	}

	@Then("I select I\\/We wish to appoint the Chair of the Meeting radio button")
	public void i_select_i_we_wish_to_appoint_the_Chair_of_the_the_meeting_radio_button() {
		votingPage.btncharirman.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on I/We wish to appoint the Chair of the Meeting radio button");
	}

	@Then("validate I\\/We wish to appoint the Chair of the Meeting radio button is selected by default")
	public void validate_i_we_wish_to_appoint_the_chair_of_the_meeting_radio_button_is_selected_by_default() {
		votingPage.btncharirman.IsSelected();
		ExtentCucumberAdapter
				.addTestStepLog("I/We wish to appoint the Chair of the Meeting radio button is selected by default");
		new TakeScreenshot();
	}

	@Then("i select radio button No for attend this event")
	public void i_select_radio_button_no_for_attend_this_event() {
		votingPage.radiobtnno.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on No Radio button");
		new TakeScreenshot();
	}

	@Then("validate resolution list displayed in grid format {string},{string},{string}")
	public void validate_resolution_list_displayed_in_grid_format(String string, String string2, String string3) {
		votingPage.lblFor.verifyLabelonUI(string);
		votingPage.lblAgainst.verifyLabelonUI(string2);
		votingPage.lblDiscretionary.verifyLabelonUI(string3);
		new TakeScreenshot();
	}

	@Then("validate green tick is marked for {string}")
	public void validate_green_tick_is_marked_for(String string) {
		votingPage.btntick.IsDisplayed();
		ExtentCucumberAdapter.addTestStepLog("Green tick is displayed for " + string);
		new TakeScreenshot();
	}

	@Then("validate question for dropdown is available")
	public void validate_question_for_dropdown_is_available() {
		votingPage.selquestionfor.selectByValue("The Chair");
		ExtentCucumberAdapter.addTestStepLog("Question for dropdown is available and The chair option is selected");
		new TakeScreenshot();
	}

	@Then("validate question text textbox is avialble")
	public void validate_question_text_textbox_is_avialble() {
		String questiontext = ThreadLocalDriver.getDriver().findElement(By.xpath("//label[@for='QuestionText']"))
				.getText();
		ExtentCucumberAdapter.addTestStepLog(questiontext + " text box is availble on UI");
		new TakeScreenshot();
	}

	@Then("validate back and submit button is availble")
	public void validate_back_and_submit_button_is_availble() {
		votingPage.btnback1.IsDisplayed();
		votingPage.btnsubmit.IsDisplayed();
		new TakeScreenshot();

	}

	@Then("I click on Print icon")
	public void i_click_on_print_icon() {
		votingPage.btnPrinter.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Print Icon");
		new TakeScreenshot();
		Robot robot;
		try {
			robot = new Robot();
			Hardwait.staticWait(5000);
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("validate Transaction details is displayed as below")
	public void validate_transaction_details_is_displayed_as_below(List<Map<String, String>> TransactionDetails)
			throws Exception {
		for (Map<String, String> voting : TransactionDetails) {
			Thread.sleep(5000);
			System.out.println(voting.get("AttributeName") + ":" + voting.get("AttributeValue"));
			// String attributeValue = voting.get("AttributeValue");
			String attributeName = voting.get("AttributeName");
			switch (attributeName) {

			case "Transaction ID":

				String TransactionIDlavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tr[1]//td)[2]")).getText();
				ExtentCucumberAdapter.addTestStepLog("Transaction ID is " + TransactionIDlavel);

				break;

			case "Transaction Date":

				String TransactionDatelavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tr[2]//td)[1]")).getText();
				ExtentCucumberAdapter.addTestStepLog("Transaction Date is " + TransactionDatelavel);
				new TakeScreenshot();
				break;
			}
		}
	}

	@Then("I verify the result grid headers")
	public void i_verify_the_result_grid_headers(List<Map<String, String>> GridDetails) throws Exception {
		for (Map<String, String> voting : GridDetails) {
			Thread.sleep(5000);
			System.out.println(voting.get("AttributeName") + ":" + voting.get("AttributeValue"));
			String attributeValue = voting.get("AttributeValue");
			String attributeName = voting.get("AttributeName");
			switch (attributeName) {
			case "issuer":
				String issuerlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[2]"))
						.getText();
				Assert.assertEquals(issuerlavel, attributeValue);
				
				break;

			case "Ivc":
				String Ivclavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[3]"))
						.getText();
				Assert.assertEquals(Ivclavel, attributeValue);
				break;

			case "Meetingname":
				String Meetingnamelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[5]"))
						.getText();
				Assert.assertEquals(Meetingnamelavel, attributeValue);
				break;

			case "Meeting Id":
				String Meeting_Idlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[6]"))
						.getText();
				Assert.assertEquals(Meeting_Idlavel, attributeValue);
				break;

			case "Security code":
				String Security_codelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[7]"))
						.getText();
				softAssert.assertEquals(Security_codelavel, attributeValue);
				break;

			case "Voting DeadLine Date":
				String Voting_DeadLine_Datelavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("//table//tr[1]//th[8]")).getText();
				Assert.assertEquals(Voting_DeadLine_Datelavel, attributeValue);
				break;

			case "status":
				String statuslavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[9]"))
						.getText();
				Assert.assertEquals(statuslavel, attributeValue);
				break;

			case "Action":
				String Actionlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[13]"))
						.getText();
				Assert.assertEquals(Actionlavel, attributeValue);
				new TakeScreenshot();
				break;

			}
		}
	}

	@Then("I validate the below textbox and enter values")
	public void i_validate_the_below_textbox_and_enter_values(List<Map<String, String>> dataTable) throws Exception {
		for (Map<String, String> voting : dataTable) {
			Thread.sleep(5000);
			System.out.println(voting.get("AttributeName") + ":" + voting.get("AttributeValue"));
			String attributeValue = voting.get("AttributeValue");
			String attributeName = voting.get("AttributeName");
			switch (attributeName) {
			case "First Name":
				votingPage.firstnametextbox.IsDisplayed();
				ExtentCucumberAdapter.addTestStepLog("First name textbox is displayed");
				if (attributeValue.equalsIgnoreCase("Random"))
					attributeValue = commonfunctions.generateRandomAlphaString(4);
				votingPage.firstnametextbox.ClearInputvalues();
				votingPage.firstnametextbox.Inputvalues(attributeValue);
				break;

			case "Last Name":
				votingPage.Lastnametextbox.IsDisplayed();
				ExtentCucumberAdapter.addTestStepLog("Last name textbox is displayed");
				if (attributeValue.equalsIgnoreCase("Random"))
					attributeValue = commonfunctions.generateRandomAlphaString(4);
				votingPage.Lastnametextbox.ClearInputvalues();
				votingPage.Lastnametextbox.Inputvalues(attributeValue);
				break;

			case "Reference Id":
				votingPage.Referenceidtextbox.IsDisplayed();
				ExtentCucumberAdapter.addTestStepLog("Reference Id textbox is displayed");
				if (attributeValue.equalsIgnoreCase("Random"))
					attributeValue = commonfunctions.generateRandomNumericString(6);
				votingPage.Referenceidtextbox.ClearInputvalues();
				votingPage.Referenceidtextbox.Inputvalues(attributeValue);
				new TakeScreenshot();
				break;
			}
		}
	}

	@Then("I verify the information display area")
	public void i_verify_the_information_display_area(List<Map<String, String>> displaydata) throws Exception {
		for (Map<String, String> voting : displaydata) {
			Thread.sleep(5000);
			System.out.println(voting.get("AttributeName") + ":" + voting.get("AttributeValue"));
			String attributeValue = voting.get("AttributeValue");
			String attributeName = voting.get("AttributeName");
			switch (attributeName) {
			case "Meeting Name":
				votingPage.btnmeetingname.scrollToElement();
				Thread.sleep(2000);
				String meetingNamelavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("//table//tbody//tr[1]//td")).getText();
				// Assert.assertEquals(meetingNamelavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Meeting name is " + meetingNamelavel);
				break;

			case "Meeting On":
				String meetingonlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tbody//tr[2]//td"))
						.getText();
				String meetingondate = meetingonlavel.substring(0, 8);
				boolean datevalidation = commonfunctions.validateDateFormat(meetingondate);
				if (datevalidation == true) {
					ExtentCucumberAdapter.addTestStepLog("Meeting On Date Format Validated");
				} else {
					ExtentCucumberAdapter.addTestStepLog("Meeting On Date is displayed in incorrect format ");
					Assert.fail("Meeting On Date is displayed in incorrect format ");
				}

				String meetingontime = meetingonlavel.substring(10, 19);
				boolean timevalidation = commonfunctions.validateTimeFormat(meetingontime);
				if (timevalidation == true) {
					ExtentCucumberAdapter.addTestStepLog("Meeting On Time Format Validated");
				} else {
					ExtentCucumberAdapter.addTestStepLog("Meeting On Time is displayed in incorrect format ");
					Assert.fail("Meeting On Time is displayed in incorrect format ");
				}
				ExtentCucumberAdapter.addTestStepLog("Meeting on is " + meetingonlavel);
				break;

			case "Cut-off date":
				String Cutoffdatelavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tbody//tr[3]//td)[1]")).getText();
				String cutoffdate = Cutoffdatelavel.substring(0, 8);
				boolean cutoffdatevalidation = commonfunctions.validateDateFormat(cutoffdate);
				if (cutoffdatevalidation == true) {
					ExtentCucumberAdapter.addTestStepLog("Cut-off Date Format Validated");
				} else {
					ExtentCucumberAdapter.addTestStepLog("Cut-off Date is displayed in incorrect format ");
					Assert.fail("Cut-off Date is displayed in incorrect format ");
				}

				String cutofftime = Cutoffdatelavel.substring(10, 19);
				boolean cutofftimevalidation = commonfunctions.validateTimeFormat(cutofftime);
				if (cutofftimevalidation == true) {
					ExtentCucumberAdapter.addTestStepLog("Cut-off Time Format Validated");
				} else {
					ExtentCucumberAdapter.addTestStepLog("Cut-off Time is displayed in incorrect format ");
					Assert.fail("Cut-off Time is displayed in incorrect format ");
				}
				ExtentCucumberAdapter.addTestStepLog("Cut off date is " + Cutoffdatelavel);
				break;

			case "Address":
				String Addresslavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tbody//tr[3]//td)[2]")).getText();
				// softAssert.assertEquals(Addresslavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Address is " + Addresslavel);
				new TakeScreenshot();
				break;
			}
		}
	}

}
