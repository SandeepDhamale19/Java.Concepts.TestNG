package stepDefination;

import java.awt.AWTException;
import org.openqa.selenium.*;
import java.awt.Robot;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.google.common.collect.ImmutableList;

import DriverFactory.IOSDriverInstance;
import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalIOSDriver;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import Hardwait.Hardwait;
import ScreenshotFactory.TakeScreenshot;
import Selenium.LocatorType;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.HideKeyboardStrategy;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.Then.Thens;
import io.cucumber.java.en.When;
import pageObject.AddHoldingPage;

public class AddHoldingSteps {
	AddHoldingPage addHoldingPage = null;

	public AddHoldingSteps() {
		addHoldingPage = new AddHoldingPage();
	}

	@Given("IC landing page is displayed for {string}")
	public void ic_landing_page_is_displayed_for_something(String applicationTitle) throws Throwable {
		addHoldingPage.lblApplicationTitle.verifyText(applicationTitle);
	}

	@When("I validate Header should be displayed as Login Page")
	public void I_validate_Header_should_be_displayed_as_Login_Page() throws Throwable {
		addHoldingPage.IconApplicationLogo.ValidateIsButtonDisplayed();
	}

	@When("Click on skip button on Holdings Page")
	public void Click_on_skip_button_on_Holdings_Page() throws Throwable {
		if (addHoldingPage.lnkSkip.GetNoOfWebElements().size() > 0) {
			addHoldingPage.btnSkip.Click();
//        	addHoldingPage.btnConfirm.Click();
		}
	}

	@When("Click on skip button on Holdings Pages")
	public void Click_on_skip_button_on_Holdings_Pages() throws Throwable {
		if (addHoldingPage.lnkSkip.GetNoOfWebElements().size() > 0) {
			addHoldingPage.btnSkip.Click();
		}
	}

	@Given("I Enter value for Issuer Name {string} in issue name field as {string}")
	public void i_enter_value_for_issuer_name_in_issue_name_field(String issuerKey, String issuerValue) {
		Hardwait.staticWait(3000);
		addHoldingPage.txtIssuer.Inputvalues(issuerKey);
		addHoldingPage.dynamicIssuerDropDownSel(issuerValue).Click();
	}

	@And("I enter IVC {string}")
	public void i_enter_ivc(String string) {
		addHoldingPage.txtivc.Inputvalues(string);
	}

	@And("I Validate {string} Page should be displayed")
	public void IValidateAddHoldingPage(String lbladdHolding) {
		addHoldingPage.lbladdHolding.verifyLabelonUI(lbladdHolding);
	}

	@Then("I validate Footer on Add Holding Screen {string}")
	public void IValidateAddHoldingPageaddHoldingfooter(String lbladdHoldingfooter) {
		addHoldingPage.lbladdHoldingFooter.verifyLabelonUI(lbladdHoldingfooter);
	}

	@Then("I Validate {string} Page Instructional Text should be displayed")
	public void verify_instructional_textAddHolding(String lblInstructionalText) {
		System.out.println(addHoldingPage.getLablelInstructionsText());
		Assert.assertEquals(lblInstructionalText, addHoldingPage.getLablelInstructionsText());
	}

	@Given("I Validate Issuer Name {string} label on Page should be displayed")
	public void i_validate_issuer_name_label_on_page_should_be_displayed(String lblIssuerName) {
		addHoldingPage.lblIssuerName.verifyLabelonUI(lblIssuerName);
	}

	@Given("I Validate IVC {string} label on  Page should be displayed")
	public void i_validate_ivc_label_on_page_should_be_displayed(String lblIVC) {
		addHoldingPage.lblIVC.verifyLabelonUI(lblIVC);
	}

	@Given("I Validate PostCode {string} label on  Page should be displayed")
	public void i_validate_post_code_label_on_page_should_be_displayed(String lblPostalCode) {
		addHoldingPage.lblPostCode.verifyLabelonUI(lblPostalCode);
	}

	@Given("I Validate LastName {string}  label on Page should be displayed")
	public void i_validate_last_name_label_on_page_should_be_displayed(String lblLastName) {
		addHoldingPage.lblLastName.verifyLabelonUI(lblLastName);
	}

	@Given("I Validate Outside UK {string}  label on Page should be displayed")
	public void i_validate_outside_uk_label_on_page_should_be_displayed(String lblOutsideUK) {
		addHoldingPage.lblOutsideUK.verifyLabelonUI(lblOutsideUK);
	}

	@And("I click on Cancel Button")
	public void IClickONCancelButton() {
		addHoldingPage.btnCancel.Click();
	}

	@Then("I Validate Landing on {string} Screen")
	public void ICValidateLandingOnPortfolioScreen(String lblPortfolio) {
		addHoldingPage.lblPortfolio.verifyLabelonUI(lblPortfolio);
	}

	@Given("I enter PostalCode {string}")
	public void i_enter_postal_code(String string) {
		addHoldingPage.txtPostCode.Inputvalues(string);
	}

	@Given("I enter FirstName {string}")
	public void i_enter_First_Name(String string) {
		addHoldingPage.txtFirstName.Inputvalues(string);
	}

	@Then("I Click on Outside UK")
	public void i_Click_On_OutsideUK() {
		addHoldingPage.btnOutsideUK.Click();
	}

	@Given("I enter LastName {string}")
	public void i_enter_last_name(String lastName) {
		addHoldingPage.txtLastName.Inputvalues(lastName);
	}

	@Given("I enter LastName {string} Outside UK")
	public void i_enter_last_nameOutsideUK(String lastName) {
		addHoldingPage.txtlastnameOutside.Inputvalues(lastName);
	}

	@Then("I click on checkbox I elect to recieve all communications electronically with username")
	public void i_click_on_checkbox_i_elect_to_recieve_all_communications_electronically_with_username() {
		addHoldingPage.chkIElect.Click();
	}

	@Then("I Validate to click on confirm button")
	public void i_validate_to_click_on_confirm_button() {
		addHoldingPage.btnAddHoldingContinue.Click();
	}

	@Then("Validate Success message {string} On add holdings page")
	public void validate_success_message_on_add_holdings_page(String sucessMessage) {
		addHoldingPage.lblSuccessMessage.verifyText(sucessMessage);
	}

	@And("I Validate Label Instructional Text {string} on screen")
	public void validateInstuctionalText_message_on_add_holdings_page(String sucessMessage) {
		addHoldingPage.lblInstructionalMessage.verifyText(sucessMessage);
	}

	@Then("the user is clicking on Add Holding")
	public void When_the_user_is_clicking_on_Add_Holding_Button() {
		if (addHoldingPage.btnlstAddHolding.GetNoOfWebElements().size() > 0) {
			addHoldingPage.btnAddHoldings.Click();
		}
	}

	@Then("the user is clicking on Manage Holding")
	public void When_the_user_is_clicking_on_Manage_Holding_Button() {
		if (addHoldingPage.btnlstAddHolding.GetNoOfWebElements().size() > 0) {
			addHoldingPage.btnManageHoldings.Click();
		}
	}

	@Then("I click on View Holdings on Success screen for Add Holding")
	public void I_click_on_View_Holdings_on_Success_screen_for_Add_Holding() {
		addHoldingPage.btnViewHoldingAction.scrollToElement();
		addHoldingPage.btnViewHoldings.Click();
	}

	@Then("I Validate landing on {string} add holding screen")
	public void I_Validate_landing_on_Add_Holding_screen(String lblAddHolding) {
		addHoldingPage.androidElementlblAddHolding.androiElementverifyLabelonUI(lblAddHolding);
	}

	@Then("I click on submit button add holding screen")
	public void I_clickSubmitbutton_on_Add_Holding_screen() {
		addHoldingPage.scrollUp.ScrollDown();
		addHoldingPage.androidElementbtnSubmitUK.AndroidElementClick();
	}
	
	@Then("I click on submit button add holding screen IOS")
	public void I_clickSubmitbutton_on_Add_Holding_screenIOS() {
		addHoldingPage.scrollUp.IOSScrollDown();
		addHoldingPage.iosElementBtnSubmitUK.IOSElementClick();
	}

	@And("I Validate {string} on add holdings UI")
	public void addHoldingsUIScreen(String lbladdholdingsUI) {
		Hardwait.staticWait(10000);
		addHoldingPage.androidElementlblAddHoldingSuccessfully.androiElementverifyLabelonUI(lbladdholdingsUI);
	}
	
	@And("I Validate {string} on add holdings UI IOS")
	public void addHoldingsUIScreenIOS(String lbladdholdingsUI) {
		Hardwait.staticWait(10000);
		addHoldingPage.iosElementlblAddHoldingSuccessfully.iosElementgetLabelIsDisplayed();
	}
	
	
	@Then("I click on done on add holdings UI")
	public void addHoldingsdoneUIScreen() {
		addHoldingPage.scrollUp.ScrollDown();
		addHoldingPage.androidElementbtndoneHoldingSuccessfully.AndroidElementClick();
	}
	
	@Then("I click on done on add holdings UI IOS")
	public void addHoldingsdoneUIScreenIOS() {
		addHoldingPage.iosElementBtnDoneUK.IOSElementClick();
	}
	
	@And("I enter values on Add holding screen with data")
	public void I_Validate_App_Settings_SubSection_Labels(List<Map<String, String>> portfolioDetails) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> portfolio : portfolioDetails) {
			System.out.println(portfolio.get("AttributeName") + ":" + portfolio.get("AttributeValue"));
			String attributeValue = portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
			case "issuername":
				addHoldingPage.androidElementselIssuerName.AndroidElementClick();
				addHoldingPage.androidElementselIssuerNameInput.AndroidDeviceInputvalues(attributeValue);
				addHoldingPage.androidElementselIssuer.AndroidElementClick();
				break;
			case "ivc":
				addHoldingPage.androidElementInputIVC.AndroidDeviceInputvalues(attributeValue);
				break;
			case "withinuk":
				addHoldingPage.androidElementRbtnWithInUK.AndroidElementClick();
				break;
			case "outsideuk":
				addHoldingPage.androidElementRbtnOutSideUK.AndroidElementClick();
				break;
			case "postcode":
				addHoldingPage.androidElementInputPostCode.AndroidDeviceInputvalues(attributeValue);
				break;
			case "lastname":
				addHoldingPage.androidElementInputLastName.AndroidDeviceInputvalues(attributeValue);
				break;
			case "firstname":
				addHoldingPage.androidElementInputFirstName.AndroidDeviceInputvalues(attributeValue);
				break;
			}
		}
	}
	
	
	@And("I enter values on Add holding screen with data for IOS")
	public void I_Validate_App_Settings_SubSection_LabelsforIOS(List<Map<String, String>> portfolioDetails) throws Exception {
		Thread.sleep(5000);
		for (Map<String, String> portfolio : portfolioDetails) {
			System.out.println(portfolio.get("AttributeName") + ":" + portfolio.get("AttributeValue"));
			String attributeName = portfolio.get("AttributeName");
			String attributeValue = portfolio.get("AttributeValue");
			switch (attributeName) {
			case "issuername":
				addHoldingPage.iosElementbtnIssuerName.IOSElementClick();
				addHoldingPage.iosElementtxtIssuerName.IOSDeviceInputvalues(attributeValue);
				addHoldingPage.iosElementSelIssuerName.IOSElementClick();
				break;
			case "ivc":
				addHoldingPage.iosElementtxtIVC.IOSDeviceInputvalues(attributeValue);
				break;
			case "withinuk":
				addHoldingPage.iosElementbtnWithINUK.IOSElementClick();
				break;
			case "outsideuk":
				addHoldingPage.iosElementbtnOutsideUK.IOSElementClick();
				break;
			case "postcode":
				addHoldingPage.iosElementTxtPostCode.IOSDeviceInputvalues(attributeValue);
				Hardwait.staticWait(5000);
				if(ThreadLocalIOSDriver.getDriver().isKeyboardShown()) {   
					ThreadLocalIOSDriver.getDriver().findElement(AppiumBy.xpath("//XCUIElementTypeButton[@name='Done']")).click();
				}
				break;
			case "lastname":
				addHoldingPage.iosElementTxtLastName.IOSDeviceInputvalues(attributeValue);
				if(ThreadLocalIOSDriver.getDriver().isKeyboardShown()) {   
					ThreadLocalIOSDriver.getDriver().findElement(AppiumBy.xpath("//XCUIElementTypeButton[@name='Done']")).click();
				}
				break;
			case "firstname":
				addHoldingPage.iosElementTxtFirstName.IOSDeviceInputvalues(attributeValue);
				if(ThreadLocalIOSDriver.getDriver().isKeyboardShown()) {   
					ThreadLocalIOSDriver.getDriver().findElement(AppiumBy.xpath("//XCUIElementTypeButton[@name='Done']")).click();
				}
				break;
			}
		}
	}
	
	

	@Then("I Land on Add Holding Screen")
	public void i_land_on_add_holding_screen() {
		addHoldingPage.iosElementlblAddHolding.iosElementgetLabelIsDisplayed();
	}
	
	
	@Then("I click on close button")
	public void i_click_on_close_button() {
		addHoldingPage.iosElementbtnClose.IOSElementClick();
	}
	
}
