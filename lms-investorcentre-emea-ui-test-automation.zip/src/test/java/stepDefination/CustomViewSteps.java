package stepDefination;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import ActionsFactory.AlertsAction;
import DriverFactory.ThreadLocalDriver;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import Hardwait.Hardwait;
import ScreenshotFactory.TakeScreenshot;
import Selenium.LocatorType;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.Then.Thens;
import io.cucumber.java.en.When;
import pageObject.AddHoldingPage;
import pageObject.CustomViewPage;

public class CustomViewSteps {
	CustomViewPage customViewPage = null;

	public CustomViewSteps() {
		customViewPage = new CustomViewPage();
	}

	@And("I validate Ladning on {string} Screen")
	public void ic_landing_page_is_displayed_for_something(String customViewTitle) throws Throwable {
		Hardwait.staticWait(8000);
		customViewPage.lblCustomview.verifyLabelonUI(customViewTitle);
	}

	@Then("I select the Filter Type {string} for custom view")
	public void i_select_the_Filter_Type_for_custom_view(String selfilterType) throws Throwable {
		Hardwait.staticWait(2000);
		customViewPage.selFilterType.selectByVisibleText(selfilterType);
	}

	@And("I Select the Holdings data for {string} on custom view")
	public void i_Select_the_Holdings_data_for_on_custom_view(String selfilterType) {
		Hardwait.staticWait(2000);
		ThreadLocalDriver.getDriver().findElement(By.xpath("//label[contains(text(),'" + selfilterType + "')]"))
				.click();
	}

	@Then("I Enter the value for View Name {string}")
	public void i_Enter_the_value_for_View_Name(String selfilterType) throws Throwable {
		customViewPage.txtViewName.Inputvalues(selfilterType);
	}

	@And("I Click on Done")
	public void i_Click_on_DoneUI() throws Throwable {
		customViewPage.btnDone.Click();
	}

	@And("I click on Edit for Custom View")
	public void EditCustomrView() {
		customViewPage.btnEdit.Click();
	}

	@When("I Delete the Custom view created")
	public void i_Delete_the_Custom_view_created() {
		customViewPage.btnDelete.Click();
		Hardwait.staticWait(2000);
		AlertsAction alert = new AlertsAction();
		alert.alertAccept();
	}
}
