package stepDefination;

import org.testng.Assert;

import Hardwait.Hardwait;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pageObject.CommunicationPreferencesPage;
import pageObject.SettingsPage;

public class SettingsSteps {
	SettingsPage settingsPage=null;
	CommunicationPreferencesPage communicationPreferences_PageObject=null;
	public SettingsSteps() {
		settingsPage=new SettingsPage();
		communicationPreferences_PageObject=new CommunicationPreferencesPage();
	}
	
	@Then("I Click on Settings Link")
	public void I_Click_on_Settings_Link() {
		Hardwait.staticWait(3000);
		settingsPage.btnSettings.Click();
	}
	
	@And("I Validate {string} page should be displayed")
	public void asldhaskdhksadghsadg(String lblSettings) {
		Hardwait.staticWait(5000);
		settingsPage.lblSettings.verifyLabelonUI(lblSettings);
	}
	
	@Then("I Validate Cancel Button is Clicked on  Manage Delete Account")
	public void kadhkazsbiasbgcgc() {
		settingsPage.btnCancelDeleteAccount.Click();
	}
	
	@Then("I Valdidate Instructional Text on Settings Screen {string}")
	public void aksjbxakcgiag(String lblSettingsInstText) {
		settingsPage.lblChangeYourInvestor.verifyLabelonUI(lblSettingsInstText);
	}
	
	@Then("Click on Manage Password hyperlink")
	public void kasjbdasbdsakbd() {
		settingsPage.btnmanagePassword.Click();
	}
	
	@And("I validate {string} Header is Displayed")
	public void ajhsbdkasjbdksabd(String lblManageLoginPassword) {
		Hardwait.staticWait(3000);
		settingsPage.lblManageLoginPassword.verifyLabelonUI(lblManageLoginPassword);
	}
	
	@Then("I Validate Body of Manage Login Password")
	public void akhjsbdkasbdkasbd()
	{
		settingsPage.lblChangePassordInstText.verifyLabelonUI("Please enter and confirm your new login password.");
		settingsPage.lblCurrentPasswordText.verifyText("Current Password");
		settingsPage.lblnewPasswordText.verifyText("New Login Password");
		settingsPage.lblConfirmPasswordText.verifyText("Confirm Password");
		settingsPage.actiontxtInputPassword.ActionMouseHover();
		settingsPage.lblPasswordMustContacin.verifyLabelonUI("Password must contain:");
		settingsPage.btnClose.Click();
	}
	
	@Then("I Validate floating popup for password validation")
	public void I_Validate_floating_popup_for_password_validation() {
		settingsPage.actiontxtInputPassword.ActionMouseHover();
		settingsPage.lblPasswordMustContacin.verifyLabelonUI("Password must contain:");
		
		settingsPage.lblAtLeast10Characters.verifyLabelonUI("At least 10 and no more than 32 characters");
		settingsPage.lblAtLeastOneUpperCase.verifyLabelonUI("At least one upper case character");
		settingsPage.lblAtLeastOneLowerCase.verifyLabelonUI("At least one lower case character");
		settingsPage.lblAtLeastOneDigit.verifyLabelonUI("At least one digit");
		settingsPage.lblAtLeastOneSpecialCharacters.verifyLabelonUI("At least one special character");
		settingsPage.lblMustNotContainpartofUserName.verifyLabelonUI("Must not contain part of username");
		settingsPage.lblMustNotContainFirst_LastName.verifyLabelonUI("Must not contain 'First' or 'Last name'");
		settingsPage.lblYourPrevious4PasswordsCannotBeUsed.verifyLabelonUI("Your previous 4 passwords cannot be used");
		settingsPage.lblMustNotcontaincommonwords.verifyLabelonUI("Must not contain common words");
		
		
		settingsPage.IconAtLeast10Characters.ValidateIsButtonDisplayed();
		settingsPage.IconAtLeastOneUpperCase.ValidateIsButtonDisplayed();
		settingsPage.IconAtLeastOneLowerCase.ValidateIsButtonDisplayed();
		settingsPage.IconAtLeastOneDigit.ValidateIsButtonDisplayed();
		settingsPage.IconAtLeastOneSpecialCharacters.ValidateIsButtonDisplayed();
		settingsPage.IconMustNotContainpartofUserName.ValidateIsButtonDisplayed();
		settingsPage.IconMustNotContainFirst_LastName.ValidateIsButtonDisplayed();
		settingsPage.IconYourPrevious4PasswordsCannotBeUsed.ValidateIsButtonDisplayed();
		settingsPage.IconMustNotcontaincommonwords.ValidateIsButtonDisplayed();
		
//		
		settingsPage.txtInputPassword.Inputvalues("Linkgroup@2011");
		String lblStrong = settingsPage.lblstrongtext.getTextlabel();
		Assert.assertEquals("Strong", lblStrong);
//
		settingsPage.IconGreenAtLeast10Characters.ValidateIsButtonDisplayed();
		settingsPage.IconGreenAtLeastOneUpperCase.ValidateIsButtonDisplayed();
		settingsPage.IconGreenAtLeastOneLowerCase.ValidateIsButtonDisplayed();
		settingsPage.IconGreenAtLeastOneDigit.ValidateIsButtonDisplayed();
		settingsPage.IconGreenAtLeastOneSpecialCharacters.ValidateIsButtonDisplayed();
		
	}
	
	@And("I validate Help Icon besides New Login Password")
	public void kajsbdkasjnbdkjsand() {
		settingsPage.IconHelpLinkBesidesNewLogin.Click();
        String ParentWindow = communicationPreferences_PageObject.windowsFactory.getWindowSession();
        communicationPreferences_PageObject.windowsFactory.SwitchToWindow();
        communicationPreferences_PageObject.windowsFactory.getWindowTitle("Help");
        communicationPreferences_PageObject.lblFAQ.verifyLabelonUI("FAQ");
        String ChildWindow = communicationPreferences_PageObject.windowsFactory.getWindowSession();
        communicationPreferences_PageObject.windowsFactory.CloseCurrentWindow(ChildWindow);
        communicationPreferences_PageObject.windowsFactory.switchToWindow(ParentWindow);
	}
	
	
	@And ("i valdite Now Log IN password is Masked {string}")
	public void skjbckjc_bkdbcc(String lblpassword) {
		settingsPage.txtInputPassword.Inputvalues(lblpassword);
		Assert.assertEquals("password", settingsPage.lblInputPassword.getAttributeName("type"));
		String lblStrong = settingsPage.lblstrongtext.getTextlabel();
		Assert.assertEquals("Strong", lblStrong);
		settingsPage.lblPasswordMustContacin.verifyLabelonUI("Password must contain:");
		settingsPage.btnClose.Click();
	}
	
	
	@And("i valdite Confirm password is Masked {string}")
	public void askhjbdkasbjhscjc(String lblpassword) {
		settingsPage.txtInputConfirmPassword.Inputvalues(lblpassword);
		Assert.assertEquals("password", settingsPage.lblInputConfirmPassword.getAttributeName("type"));
	}
	
	@And("i valdite Current password is Masked {string}")
	public void ahjsbdjashbjhabsj(String lblpassword)
	{
		settingsPage.txtInputCurrentPassword.Inputvalues(lblpassword);
		Assert.assertEquals("password", settingsPage.lblInputCurrentPassword.getAttributeName("type"));
	}
	
	@Then("I Validate Validate that user is directed back to Settings page when cancel button is clicked")
	public void skjbckhsdcbjhdsvcdgbjysgf() {
		settingsPage.btnbackButton.Click();
	}

	@Then("I Click on Change button")
	public void akjsbdjkabcaksbcdcb() {
		settingsPage.btnChange.Click();
		Hardwait.staticWait(2000);
	}
	
	@And("I valdiate Error Message {string} and {string}")
	public void shabcjhdvcbjdgfc(String lblerrorCurrentMsg1,String lblerrorNewMsg2) {
		settingsPage.lblErrorMessageCurrentPwd.verifyLabelonUI(lblerrorCurrentMsg1);
		settingsPage.lblErrorMessageNewPwd.verifyLabelonUI(lblerrorNewMsg2);
	}
	
	@Then("I Valdidate Hyperlinks is displayed on Settings Screen")
	public void i_validate_hyperlinks_is_displayed_on_settings_screen_manage_email_login_and_mange_password_and_security_code_registration_and_manage_multi_factor_authentication_mfa_and_delete_account() {
		settingsPage.btnManageEmailLogin.ValidateIsButtonDisplayed();
		settingsPage.btnmanagePassword.ValidateIsButtonDisplayed();
		settingsPage.btnResetMFAFactor.ValidateIsButtonDisplayed();
		settingsPage.btnDeleteAccount.ValidateIsButtonDisplayed();
	}
	
	@Then("I Click on Hyperlink Manage Email Login and validate landing screen {string}")
	public void i_click_on_hyperlink_manage_email_login_and_validate_landing_screen(String lblTitle) {
		settingsPage.btnManageEmailLogin.Click();
		settingsPage.lblManageEmailLogin.verifyLabelonUI(lblTitle);
	}
	
	@Then("I Validate Cancel Button")
	public void I_Validate_Cancel_Button() {
		settingsPage.btncancel.Click();
	}
	
	@Then("I Click on Hyperlink Manage Password and validate landing screen {string}")
	public void i_click_on_hyperlink_manage_password_and_validate_landing_screen(String lblTitle) {
		settingsPage.btnmanagePassword.Click();
		settingsPage.lblManageLoginPassword.verifyLabelonUI(lblTitle);
	}
	
	@And("I Validate the Instruction text as {string} is displayed on Settings Page")
	public void I_Validate_the_Instruction_text_asSettingsPage(String lblSettingsPage) {
		settingsPage.lblChangeYourInvestor.verifyLabelonUI(lblSettingsPage);
	}
	
	
	@Then("I Click on Hyperlink Manage MultiFactor Authentication MFA and validate landing screen {string}")
	public void i_click_on_hyperlink_manage_multi_factor_authentication_mfa_and_validate_landing_screen(String lblTitle) {
		settingsPage.btnResetMFAFactor.Click();
		settingsPage.lblResetMFAFactorForm.verifyLabelonUI(lblTitle);
	}
	
	@Then("I Validate Cancel Button is Clicked on  Manage Multifactor Authentication Page")
	public void kabsdkjasbd_saxgdiagd() {
		settingsPage.btncancelButtonMFA.Click();
	}
	
	
	@Then("I Click on Hyperlink Manage Delete Account and validate landing screen {string}")
	public void i_click_on_hyperlink_manage_delete_account_and_validate_landing_screen(String lblTitle) {
		settingsPage.btnDeleteAccount.Click();
		settingsPage.lblDeleteAccountForm.verifyLabelonUI(lblTitle);
	}
	
	@Then("I Validate Delete Account Content on Screen")
	public void kajhdanasjbkasjbkbc() {
		settingsPage.lblDeleteAccountInstructionText1.verifyLabelonUI("Do you want to delete your Portfolio account?");
		settingsPage.lblDeleteAccountInstructionText2.verifyLabelonUI("This will permanently delete your Investor Centre Portfolio account and you will no longer be able to login to your Portfolio via APP or web (desktop).");
		settingsPage.lblDeleteAccountInstructionText3.verifyLabelonUI("It will not impact your investments.");
		settingsPage.lblDeleteAccountInstructionText4.verifyLabelonUI("Once deleted you will have to re-register if you wish to view your holdings under a Portfolio.");
		settingsPage.btnDelete.ValidateIsButtonDisplayed();
		settingsPage.btnCancelDeleteAccount.ValidateIsButtonDisplayed();
	}
	
}

