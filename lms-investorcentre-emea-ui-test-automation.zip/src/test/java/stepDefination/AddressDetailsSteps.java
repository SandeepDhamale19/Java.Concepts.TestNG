package stepDefination;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.github.javafaker.Faker;

import Hardwait.Hardwait;
import WebTableFactory.WebTableFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.AddressDetailsPage;

public class AddressDetailsSteps {
	
		AddressDetailsPage addressDetailsPage=null;
	
		public AddressDetailsSteps() {
			addressDetailsPage=new AddressDetailsPage();
		}	
	
	
	@And("I Enter Address Details as per below Details")
	public void I_Validate_Navigation_to_Tabs_on_LIC (List<Map<String,String>> addressDetails) {
		addressDetailsPage.InputAddressDetails(addressDetails);
	}

	
	@And("I Validate Replication for Address Details as per below Details")
	public void I_ValidateReplication_Navigation_to_Tabs_on_LIC (List<Map<String,String>> addressDetails) {
		addressDetailsPage.ValidateAddressDetails(addressDetails);
	}
	
	@Then("I Validate if Address Details has updated successfully")
	public void I_Validate_if_Address_Details_has_updated_successfully () {
		addressDetailsPage.ValdiateAddressDetails();
	}

	
	@When("I Click on confirm button")
	public void I_Click_on_confirm_button() {
		addressDetailsPage.btnConfirm.Click();
		Hardwait.staticWait(120000);
	}
	
	@And("I Validate SuccessMessage on Screen {string}")
	public void I_Validate_SuccessMessage_on_Screen(String lblSuccessMessage) {
		Hardwait.staticWait(3000);
		addressDetailsPage.lblAddressUpdateSuccessMessage.verifyText(lblSuccessMessage);
	}
	
	@And("I Validate Address Update Complete Label on Screen {string} and Instructional Text {string}")
	public void I_Validate_Address_Update_Complete_Label_on_Screen(String lblAddressUpdateCOmplete,String lblInstructionalText) {
		Hardwait.staticWait(3000);
		addressDetailsPage.lblAddressUpdateComplete.verifyLabelonUI(lblAddressUpdateCOmplete);
		addressDetailsPage.lblInstructionalText.verifyText(lblInstructionalText);
	}
	
	@And("I Validate Landing On {string} Screen")
	public void I_Validate_Landing_On_Address_Details_Screen(String lblAddressDetails) {
        Hardwait.staticWait(3000);
        addressDetailsPage.lblAddressUpdate.verifyText(lblAddressDetails);
    }
	
	@And("I Validate Label Address Deatails  On {string} Screen")
	 public void I_Validate_Label_Address_Deatails_On_Address_Details_Screen(String lblAddressDetails) {
        Hardwait.staticWait(3000);
        addressDetailsPage.lblEnterAddressDetails.verifyText(lblAddressDetails);
    }
    
	@Then("I Valdiate {string} and Text box to update street address 5th row line items and 6th row for {string}")
	public void I_Valdiate_Street_Adress_and_Text_box_to_update_street_address_5th_row_line_items_and_6th_row_for_postcode(String lblStAddress,String lblPostCode) {
		addressDetailsPage.lblStreetAdtress.verifyLabelonUI(lblStAddress);
		addressDetailsPage.lblPOstCode.verifyLabelonUI(lblPostCode);
		addressDetailsPage.txtAddressLine1.IsDisplayed();
		addressDetailsPage.txtAddressLine2.IsDisplayed();
		addressDetailsPage.txtAddressLine3.IsDisplayed();
		addressDetailsPage.txtAddressLine4.IsDisplayed();
		addressDetailsPage.txtAddressLine5.IsDisplayed();
		addressDetailsPage.txtPostCode.IsDisplayed();
	}
	
	@Then("I Vaidate Two radio buttons to choose {string} and {string}")
	public void I_Vaidate_Two_radio_buttons_to_choose(String lblApplythisUpdatetoAllavaliableHoldings,String lblIndividuallyselecttheHoldings) {
		addressDetailsPage.btnselectotherholdingstoapplythisupdateto.ValidateIsButtonDisplayed();
		addressDetailsPage.lblselectotherholdingstoapplythisupdateto.verifyLabelonUI("Select other holdings to apply this update to");

		addressDetailsPage.btnselectIndividuallyselecttheholdings.ValidateIsButtonDisplayed();
        addressDetailsPage.btnApplyToAllHoldings_1.ValidateIsButtonDisplayed();
        
        addressDetailsPage.lblselectIndividuallyselecttheholdings.verifyLabelonUI(lblIndividuallyselecttheHoldings);
        addressDetailsPage.lblApplyToAllHoldings_1.verifyLabelonUI(lblApplythisUpdatetoAllavaliableHoldings);
	}
	
	
	@Then("I Validate that check box to  select other holding to apply this update to  gets selected when clicked on check box_SIT")
	public void I_Validate_that_check_box_to_select_other_holding_to_apply_this_update_to_gets_selected_when_clicked_on_check_box_SIT() {
		addressDetailsPage.btnselectotherholdingstoapplythisupdateto.Click();
		addressDetailsPage.rbApplyToAllHoldings_1.ValidateIsButtonDisplayed();
//		addressDetailsPage.rbApplyToAllHoldings_2.ValidateIsButtonDisplayed();
	}
	
	@And("I Validate Radio button Individually select the holdings to apply this update to should get selected and below elements should be displayed {string} and {string} should be displayed")
	public void kahgdjahsdbvjhsadb(String btnselectAll,String DeselectAll)
	{
		addressDetailsPage.btnSelectall.ValidateIsButtonDisplayed();
		addressDetailsPage.btnDeSelectall.ValidateIsButtonDisplayed();
	}
	
	@Then("I Validate the Tablel Labels for Individually select the holdings")
	public void aksjhdasjhdgsajhdjas() {
		addressDetailsPage.lblColHeader.verifyLabelonUI("IVC");
		addressDetailsPage.lblRegistrationDetails.verifyLabelonUI("Registration Details");
		addressDetailsPage.lblIssuer.verifyLabelonUI("Issuer");
		addressDetailsPage.lblCurrentAddress.verifyLabelonUI("Current Address");
		addressDetailsPage.lblUpdate.verifyLabelonUI("Update");
		WebTableFactory.validateDatainWebTable(addressDetailsPage.listIVC.GetListOfWebElements().size(), addressDetailsPage.listIVC.GetNoOfWebElements(), "IVC", "0*******141");
		WebTableFactory.validateDatainWebTable(addressDetailsPage.listRegistrationDetails.GetListOfWebElements().size(), addressDetailsPage.listRegistrationDetails.GetNoOfWebElements(), "RegistrationDetails", "PHILIP WATSON");
		WebTableFactory.validateDatainWebTable(addressDetailsPage.listIssuer.GetListOfWebElements().size(), addressDetailsPage.listIssuer.GetNoOfWebElements(), "Issuer", "ASE");
		WebTableFactory.validateDatainWebTable(addressDetailsPage.listCurrentAddress.GetListOfWebElements().size(), addressDetailsPage.listCurrentAddress.GetNoOfWebElements(), "AddressDetails", "DCVE 61 NEW,MC SCYMYG NEW,64986 TCBEQUUOJ NEW,MALAGA SPAIN NEW,NEW,DD4 8UN");
	}
	
	
	@Then("I Validate whether the checkboxes in Update column are getting selected deselected")
	public void I_Validate_whether_the_checkboxes_in_Update_column_are_getting_selected_deselected() {
		for (int i = 0; i < addressDetailsPage.listUpdate.GetListOfWebElements().size(); i++) {
			addressDetailsPage.listUpdate.GetNoOfWebElements().get(i).click();
		}
	}
	
	@Then("I Validate Select all and Deselect all button")
	public void I_Validate_Select_all_and_Deselect_all_button() {
		addressDetailsPage.btnselectAll.Click();
		addressDetailsPage.btnDeSelectall.Click();
		addressDetailsPage.btnselectAll.Click();
	}

	@Then("I Validate to Confirm Update Addres {string}")
	public void I_Validate_to_Confirm_Update_Address(String lblConfirmAddress)
	{
		 Hardwait.staticWait(3000);
		addressDetailsPage.lblConfirmAddress.verifyLabelonUI(lblConfirmAddress);
	}
	
}
