package stepDefination;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import ActionsFactory.WindowsFactory;
import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalDriver;
import Hardwait.Hardwait;
import ScreenshotFactory.TakeScreenshot;
import WebTableFactory.WebTableFactory;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.AddHoldingPage;
import pageObject.CommunicationPreferencesPage;
import pageObject.PortfolioPage;

import org.testng.asserts.SoftAssert;
public class PortfolioSteps {
	
PortfolioPage portfolioObj=null;
CommunicationPreferencesPage communicationPreferences_PageObject=null;
SoftAssert softAssert = new SoftAssert();

	public PortfolioSteps() {
		portfolioObj=new PortfolioPage();
		communicationPreferences_PageObject=new CommunicationPreferencesPage();
	}
	
	
	@And("^I Validate holdings added on potfolio Screen$")
	public void I_Validate_holdings_added_on_potfolio_Screen(List<Map<String,String>> holdingDetails) {
		for(Map<String, String> holding:holdingDetails) {
			portfolioObj.lblIVCno.verifyText(holding.get("IVC"));
			portfolioObj.lblRegisteredDetailsName.validatelabelonUI(holding.get("Registered_Details"));
		}
		portfolioObj.lnkViewDetails.Click();
	 }

	@And("I Validate Navigation to Tabs on LIC")
	public void I_Validate_Navigation_to_Tabs_on_LIC (List<Map<String,String>> portfolioDetails) throws Exception{
		for(Map<String, String> portfolio:portfolioDetails) {
			Thread.sleep(10000);
			System.out.println(portfolio.get("NavigateTo")+":"+portfolio.get("Screen"));
			switch (portfolio.get("NavigateTo")) {
				case "Communications":
						portfolioObj.tabCommunications.ActionMouseHover();
						if (portfolio.get("Screen").equalsIgnoreCase("Preferences")) {
							Hardwait.staticWait(1000);
							portfolioObj.tabPreferences.Click();
						}
						if (portfolio.get("Screen").equalsIgnoreCase("Address Details")) {
							Hardwait.staticWait(1000);
							portfolioObj.tabAddressDetails.Click();
						}
					break;
				case "Holdings":
					portfolioObj.tabHoldings.ActionMouseHover();
					if (portfolio.get("Screen").equalsIgnoreCase("Transaction")) {
						Hardwait.staticWait(1000);
						portfolioObj.tabTransactionHistory.Click();
					}
					if (portfolio.get("Screen").equalsIgnoreCase("Portfolio")) {
						Hardwait.staticWait(1000);
						portfolioObj.tabPortfolio.Click();
					}
					if (portfolio.get("Screen").equalsIgnoreCase("Balance History")) {
						Hardwait.staticWait(1000);
						portfolioObj.tabBalanceHistory.Click();
					}
				break;
				case "Payments":
					portfolioObj.tabPayment.ActionMouseHover();
					if (portfolio.get("Screen").equalsIgnoreCase("Payment History")) {
						Hardwait.staticWait(1000);
						portfolioObj.tabPaymentHistory.Click();
					}
					if (portfolio.get("Screen").equalsIgnoreCase("Payment Instructions")) {
						Hardwait.staticWait(1000);
						portfolioObj.tabPaymentInstructions.ActionMouseclick();
					}
				break;
				
				default:
					break;
			}
		}
	}
	
	@Then("I Validate landing on {string} Screen")
	public void I_Validate_landing_on_Communication_Preferences_Screen(String lblcommunicationPref) {
		Hardwait.staticWait(15000);
		communicationPreferences_PageObject.lblcommpref.scrollToElement();
		communicationPreferences_PageObject.lblCommunicationPreferences.verifyText(lblcommunicationPref);
		new TakeScreenshot();
	}
	
	
	@Then ("I Click on Help Icon")
	public void I_Click_on_Help_Icon() {
        communicationPreferences_PageObject.btnHelp.Click();
        new TakeScreenshot();
        String ParentWindow = communicationPreferences_PageObject.windowsFactory.getWindowSession();
        communicationPreferences_PageObject.windowsFactory.SwitchToWindow();
        communicationPreferences_PageObject.windowsFactory.getWindowTitle("Help");
        communicationPreferences_PageObject.lblFAQ.verifyLabelonUI("FAQ");
        String ChildWindow = communicationPreferences_PageObject.windowsFactory.getWindowSession();
        communicationPreferences_PageObject.windowsFactory.CloseCurrentWindow(ChildWindow);
        communicationPreferences_PageObject.windowsFactory.switchToWindow(ParentWindow);
    }
	
	@And("I Validate Printer Icon , Help Icon on Screen")
	public void I_Validate_Printer_Icon_on_Screen() {
		communicationPreferences_PageObject.btnPrinter.ValidateIsButtonDisplayed();
		new TakeScreenshot();
		communicationPreferences_PageObject.btnHelp.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}
	
	@Then("I Validate Dropdown list with label as {string} , {string} , {string}")
	public void I_Validate_DropDownList(String lblView,String lblEmail,String lblOther) {
		communicationPreferences_PageObject.lblView.verifyLabelonUI(lblView);
		communicationPreferences_PageObject.lblEmailAddress.verifyLabelonUI(lblEmail);
		communicationPreferences_PageObject.lblOthers.verifyLabelonUI(lblOther);
		
	}
		
	@And("I Validate Instructional Text 1 on screen {string}")
	public void I_Validate_InstructionalText1(String lblInstText) {
		communicationPreferences_PageObject.lblInstructionalText1.verifyLabelonUI(lblInstText);
	}
	
	@And("I Validate Instructional Text 2 on screen {string}")
	public void I_Validate_InstructionalText2(String lblInstText) {
		communicationPreferences_PageObject.lblInstructionalText2.verifyLabelonUI(lblInstText);
	}
	
	@And("I Validate Instructional Text 3 on screen {string}")
	public void I_Validate_InstructionalText3(String lblInstText) {
		communicationPreferences_PageObject.lblInstructionalText3.verifyLabelonUI(lblInstText);
	}
	
	@Then("I Validate Radio Button with label {string} and {string}")
	public void I_Validate_Radio_Button_with_label(String lblInstText,String lblInstText2) {
		communicationPreferences_PageObject.lblInstructionalText4.verifyLabelonUI(lblInstText);
		communicationPreferences_PageObject.lblInstructionalRadioText5.verifyLabelonUI(lblInstText2);
		Boolean flag = communicationPreferences_PageObject.chkallCommunicationElectronically.IsSelected();
		softAssert.assertEquals(true, flag);
	}
	
	
	@And("I Validate Radio button with logged in user primary email id by default selected Radio button with label text as Other along with text box Textbox will be in disabled mode")
	public void I_Validate_Radio_ButtonwithLoggedinuserPrimary() {
		Boolean chkflagEmail = communicationPreferences_PageObject.chkPrimaryEmail.IsSelected();
		softAssert.assertEquals(true, chkflagEmail);
		
		Boolean chkflagOther = communicationPreferences_PageObject.chkOtherEmail.IsSelected();
		softAssert.assertEquals(false, chkflagOther);
		
		Boolean inputflagEmail = communicationPreferences_PageObject.txtEmailAddress.IsEnabled();
		softAssert.assertEquals(false, inputflagEmail);
		
	}
	
	@And("I Validate Other Radio button should get selected and radio button with logged in users emai id should get diselected and Textbox should get enabled for entering inputs")
	public void I_Validate_Other_Radio_button_should_get_selected_and_radio_button_with_logged_in_users() {
		communicationPreferences_PageObject.chkOtherEmail.Click();
		
		Boolean chkflagEmail = communicationPreferences_PageObject.chkPrimaryEmail.IsSelected();
		softAssert.assertEquals(false, chkflagEmail);
		
		Boolean inputflagEmail = communicationPreferences_PageObject.txtEmailAddress.IsEnabled();
		softAssert.assertEquals(true, inputflagEmail);
	}

	@When("the user is clicking on Manage Portfolio")
	public void the_user_is_clicking_on_Manage_Portfolio() {
			portfolioObj.btnManagePortfolio.Click();
			Hardwait.staticWait(4000);
	}
	
	@And("I click on Back to Portfolio")
	public void I_click_on_Back_to_Portfolio() {
			Hardwait.staticWait(2000);
			portfolioObj.btnBackToPortfolio.Click();
	}
	
	
	@And("I Validate All Holdings Table Valid Data")
	public void I_Validate_All_Holdings_TableValid_Data(List<Map<String,String>> tableIVC) {
		Hardwait.staticWait(3000);
		List<WebElement> portfolioElements = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr"));
		List<String> ob_lblIVC = new ArrayList<String>();
		List<String> ob_lblRegisteredDetails = new ArrayList<String>();
		List<String> ob_lblSecurityCode = new ArrayList<String>();
		
		for (int i = 0; i < portfolioElements.size(); i++) {
			String lblIVC = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[3]")).get(i).getText();
			String lblRegisteredDetails = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[4]")).get(i).getText();
			String lblSecurityCode = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[5]")).get(i).getText();
			System.out.println(lblIVC+"\t"+lblRegisteredDetails+"\t"+lblSecurityCode);
			ob_lblIVC.add(lblIVC);
			ob_lblRegisteredDetails.add(lblRegisteredDetails);
			ob_lblSecurityCode.add(lblSecurityCode);
		}
		
		for (int i = 0; i < portfolioElements.size(); i++) {
			String lblSecurityCode = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[8]")).get(i).getText();
			String lblBalance = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[9]")).get(i).getText();
			String lblValue = ThreadLocalDriver.getDriver().findElements(By.xpath("//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[10]")).get(i).getText();
			
//			Float  SecurityCodefloat = Float.valueOf(lblSecurityCode);
//			Float  Balancefloat = Float.valueOf(lblBalance);
//			Float  Valuefloat = Float.valueOf(lblValue);
			
//			Float  check_Value=0.0f;
//			
//			check_Value = SecurityCodefloat + Balancefloat;
			
//			if (!check_Value.equals(Valuefloat)) {
//				Assert.fail("Value is Not Matching With Table!!");
//			}
			
		}
		
		System.out.println(ob_lblIVC);
		System.out.println(ob_lblRegisteredDetails);
		System.out.println(ob_lblSecurityCode);
		
		List<String> ob_lblIVCUnique=ob_lblIVC.stream().distinct().collect(Collectors.toList());
		List<String> ob_lblRegisteredDetailsUnique=ob_lblRegisteredDetails.stream().distinct().collect(Collectors.toList());
		List<String> ob_lblSecurityCodeUnique=ob_lblSecurityCode.stream().distinct().collect(Collectors.toList());
		
		System.out.println(ob_lblIVCUnique);
		System.out.println(ob_lblRegisteredDetails);
		System.out.println(ob_lblSecurityCode);
		
		ArrayList<String> ob_testIVC = new ArrayList<String>();
		ArrayList<String> ob_testRegisteredDetails = new ArrayList<String>();
		ArrayList<String> ob_testSecurityCode = new ArrayList<String>();
		
		for(Map<String, String> dataIVC:tableIVC) {
			ob_testIVC.add(dataIVC.get("IVC"));
			ob_testRegisteredDetails.add(dataIVC.get("Registered_Details"));
			ob_testSecurityCode.add(dataIVC.get("Issuer"));
		}
		
		Boolean FlagTest = false;
		if ( ob_lblIVCUnique.equals(ob_testIVC) &&  ob_lblRegisteredDetailsUnique
				.equals(ob_testRegisteredDetails) /* && ob_lblSecurityCodeUnique.equals(ob_testSecurityCode) */) {
			FlagTest=true;
		}
		
		if (!FlagTest) {
			Assert.fail("Holdings Added is not matching with the Manage Holding Data");
		}
		
	}
	
	@When("I click on Logout Button")
	public void clickOnLogoutButton() {
		portfolioObj.btnLogout.Click();
	}
	
	@And("I Validate Landing on Login Page with {string}")
	public void validateLanding(String lblLandingPage) {
		String lblWelcomePageCheck = ThreadLocalDriver.getDriver().findElement(By.xpath("//h1[@class='login-welcome-title']")).getText().replace("\n", " ");
		System.out.println(lblWelcomePageCheck);
		Assert.assertEquals(lblLandingPage, lblWelcomePageCheck);
	}
	

	@And("I Validate {string} , {string} and Displaying {string} in tabular format")
	public void i_validate_and_displaying_in_tabular_format(String lblmanagePortfolio, String lblAddHolding, String lblAllHoldings) {
		portfolioObj.btnManagePortfolio.ValidateIsButtonDisplayed();
		portfolioObj.btnNewHolding.ValidateIsButtonDisplayed();
		portfolioObj.lblAllHolding.verifyLabelonUI(lblAllHoldings);
    }
	
	
	@And("I Validate table data from All Holdings with IVC {string} and Registered details {string}")
	public void I_Validate_table_data_from_Transaction_History(String IVC ,String RegisteredDetails) {
		List<WebElement> Row_IVC = portfolioObj.lblAllHoldingsIVC.GetNoOfWebElements();
		WebTableFactory.validateDatainWebTable(Row_IVC.size(), Row_IVC, "IVC", IVC);
		
		List<WebElement> Row_RegisteredDetails = portfolioObj.lblRegisteredDetails.GetNoOfWebElements();
		WebTableFactory.validateDatainWebTable(Row_RegisteredDetails.size(), Row_RegisteredDetails, "RegisteredDeatils", RegisteredDetails);
		
	}
	
	@And("I Validate table data from All Holdings with Column names")
	public void IValidateColumnsAllHoldings() {
		
		portfolioObj.lblColHeader.getLabelIsDisplayed();
		portfolioObj.lblColRegDetails.getLabelIsDisplayed();
		portfolioObj.lblColSecurityCode.getLabelIsDisplayed();
		portfolioObj.lblLastCode.getLabelIsDisplayed();
		portfolioObj.lblBalance.getLabelIsDisplayed();
		portfolioObj.lblLastCodeGBP2.getLabelIsDisplayed();
		portfolioObj.lblAction.getLabelIsDisplayed();
		portfolioObj.lblTotalIsDisplayed.getLabelIsDisplayed();
	}
	
	@And("I Validate on Portfolio screen when {string}")
	public void I_Validate_on_Portfolio_screen_when(String lblNoHoldings) {
		portfolioObj.lblNoHoldings.verifyLabelonUI(lblNoHoldings);
	}
	
	@Then("I validate on Displaying All Holdings {string} should be displayed")
	public void i_validate_on_Displaying_All_Holdings_should_be_displayed(String lblAllHoldings) {
        portfolioObj.lblNoRecordsfound.verifyLabelonUI(lblAllHoldings);
    }
	
	@When("I Click on Back Button device android")
	public void BackButton() {
<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<AUTO GENERATED BY CONFLICT EXTENSION<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Test_Automation_Hub
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.uat:id/back_btn")).click();
====================================AUTO GENERATED BY CONFLICT EXTENSION====================================
		ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.id("com.linkgroup.android_investorcentre.sit:id/back_btn")).click();
	}
	
	@And("I Validate labels on Potfolio added Holdings screen")
	public void I_Validate_App_Settings_SubSection_Labels (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "issuername":
					portfolioObj.androidElementlblIssuer.androiElementverifyLabelonUI(attributeValue);
					break;
				case "issuervalue":
					portfolioObj.androidElementlblIssuerValue.androiElementverifyLabelonUI(attributeValue);	
					break;
				case "holdingname":
					portfolioObj.androidElementlblIssuerName.androiElementverifyLabelonUI(attributeValue);	
					break;	
				case "TotalPortfolioTitle":
					portfolioObj.androidElementlblTotlaPortfolioValue.androiElementverifyLabelonUI(attributeValue);	
					break;	
				case "TotalPortfolioValue":
					portfolioObj.androidElementlblTotlaPortfolioInvestorValue.androiElementverifyLabelonUI(attributeValue);	
					break;	
			
			}
		}
	}
	
	
	@And("I Validate labels on Potfolio added Holdings screen IOS")
	public void I_Validate_App_Settings_SubSection_LabelsIOS(List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "issuername":
					portfolioObj.iosElementlblIssuerNamelist1.iosElementverifyLabelonUI(attributeValue);
					break;
				case "issuervalue":
					portfolioObj.iosElementlblIssuerValue.iosElementverifyLabelonUI(attributeValue);	
					break;
				case "holdingname":
					portfolioObj.iosElementlblIssuerName.iosElementverifyLabelonUI(attributeValue);	
					break;	
				case "TotalPortfolioTitle":
					portfolioObj.iosElementlblTotlaPortfolioValue.iosElementgetLabelIsDisplayed();
					break;	
				case "TotalPortfolioValue":
					portfolioObj.iosElementlblTotlaPortfolioInvestorValue.iosElementverifyLabelonUI(attributeValue);	
					break;	
			
			}
		}
	}
	
	
	@And("I click on chevron for Individual user")
	public void I_click_on_chevron_for_Individual_user() {
		portfolioObj.androidElementbtnchecvronIndividualuser.AndroidElementClick();
	}
	
	
	@And("I click on chevron for Individual Holdings")
	public void I_click_on_chevron_for_Individual_Holdings() {
		portfolioObj.androidElementbtnchecvronIndividualHolding.AndroidElementClick();
	}
	
	@Then("I click on Holdings card button")
	public void I_click_on_Holdings_card_button() {
		portfolioObj.androidElementbtnHoldingCard.AndroidElementClick();
	}
	
	@When("i click on Communication card Button")
	public void i_click_on_Communication_card_Button() {
		portfolioObj.androidElementbtnCommunicationcard.AndroidElementClick();
	}
	
	@Then("i click on edit button for Address details")
	public void i_click_on_edit_button_for_Address_details() {
		portfolioObj.androidElementbtnAddressDetailsEdit.AndroidElementClick();
	}
	
	
	@Then("i click on Update button for Address details")
	public void i_click_on_Update_button_for_Address_details() throws Exception{
		portfolioObj.scroll.ScrollDown();
		portfolioObj.androidElementbtnUdpateButtonPortfolio.AndroidElementClick();
	}
	
	@Then("i click on back button for Address UI")
	public void i_click_on_back_button_for_Address_UI() {
		portfolioObj.androidElementbtnBack.AndroidElementClick();
	}
	
	
	@Then("i click on Confirm Button on Confirm Address details screen")
	public void i_click_on_Confirm_Button_on_Confirm_Address_details_screen() throws Exception{
		portfolioObj.androidElementbtnConfirmPortfolio.AndroidElementClick();
	}
	
	@Then("i click on Done button Success UI")
	public void i_click_on_Done_button_Success_UI() throws Exception{
		portfolioObj.scroll.ScrollDown();
		portfolioObj.androidElementbtnDonePortfolio.AndroidElementClick();
	}
	
	
	@And("I validate the labels on UI for the body of Holdings submenu")
	public void I_validate_the_labels_on_UI_for_the_body_of_Holdings_submenu (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "transaction":
//					portfolioObj.androidElementlblTransaction.androiElementverifyLabelonUI(attributeValue);
				String title = 	ThreadLocalAndroidDriver.getDriver().findElement(AppiumBy.xpath("//android.widget.TextView[@text='Transactions']")).getText();
				System.out.println(title);
					break;
				case "balance":
					portfolioObj.androidElementlblBalance.androiElementverifyLabelonUI(attributeValue);	
					break;
				case "balancelbl":
					portfolioObj.androidElementlblBalancelbl.androiElementverifyLabelonUI(attributeValue);	
					break;
				case "balancevalue":
					portfolioObj.androidElementlblBalancevalue.androiElementverifyLabelonUI(attributeValue);	
					break;	
			}
		}
	}
	
	
	@And("I Validate labels on Communication Options Card")
	public void I_Validate_labels_on_Communication_Options_Card (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "communicationOptionLabel":
						portfolioObj.androidElementlblCommunicationOptionLabel.androiElementverifyLabelonUI(attributeValue);
					break;
				case "communicationOptionEdit":
						portfolioObj.androidElementbtnCommOptionEdit.AndroidElementIsDisplayed();	
					break;
				case "communicationOptionEmail":
						portfolioObj.androidElementlblCommEmail.androidElementgetLabelIsDisplayed();	
					break;	
				case "communicationOptionAllCommunicationElectroncally":
					portfolioObj.androidElementlblCommOptionElectronic.androiElementverifyLabelonUI(attributeValue);
					break;	
			}
		}
	}
	
	
	@And("I Validate labels on Address Options Card")
	public void I_Validate_labels_on_Address_Options_Card (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "AddressDetailsLabel":
						portfolioObj.androidElementlblAddressDetails.androiElementverifyLabelonUI(attributeValue);
					break;
				case "AddressDetailsdata":
						Boolean flag = portfolioObj.androidElementlblAddress.androidElementgetLabelIsDisplayed();
					break;
			}
		}
	}
	
	
	
	@And("I Validate Address Details UI")
	public void I_Validate_Address_Details_UI (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "AddressDetails":
						portfolioObj.androidElementlblAddressDetailsTitle.androiElementverifyLabelonUI(attributeValue);
					break;
				case "viewby":
						portfolioObj.androidElementlblViewBy.androiElementverifyLabelonUI(attributeValue);
					break;
				case "EnteryourAddressdetails":
						Boolean boolEle = portfolioObj.androidElementlblEnteryourDetails.androidElementgetLabelIsDisplayed();
				break;
				case "Location":
						portfolioObj.androidElementlbllocationTitle.androiElementverifyLabelonUI(attributeValue);
				break;
				case "withinuk":
						portfolioObj.androidElementlblWininUK.androiElementverifyLabelonUI(attributeValue);
				break;	
				case "Outsideuk":
						portfolioObj.androidElementlblOutSideUK.androiElementverifyLabelonUI(attributeValue);
				break;
				case "streetAddress":
					portfolioObj.androidElementlblStreetAddress.androiElementverifyLabelonUI(attributeValue);
				break;
				case "stAddressLin1":
					portfolioObj.androidElementlblStreetAddressLin1.AndroidDeviceClearInputvalues();
					portfolioObj.androidElementlblStreetAddressLin1.AndroidDeviceInputvalues(attributeValue);
				break;
				case "stAddressLin2":
					portfolioObj.androidElementlblStreetAddressLin2.AndroidDeviceClearInputvalues();
					portfolioObj.androidElementlblStreetAddressLin2.AndroidDeviceInputvalues(attributeValue);
				break;	
				case "stAddressLin3":
					portfolioObj.androidElementlblStreetAddressLin3.AndroidDeviceClearInputvalues();
					portfolioObj.androidElementlblStreetAddressLin3.AndroidDeviceInputvalues(attributeValue);
				break;
				case "stAddressLin4":
					portfolioObj.androidElementlblStreetAddressLin4.AndroidDeviceClearInputvalues();
					portfolioObj.androidElementlblStreetAddressLin4.AndroidDeviceInputvalues(attributeValue);
				break;
				case "stAddressLin5":
					portfolioObj.androidElementlblStreetAddressLin5.AndroidDeviceClearInputvalues();
					portfolioObj.androidElementlblStreetAddressLin5.AndroidDeviceInputvalues(attributeValue);
				break;
				case "scrolldown":
					portfolioObj.scroll.ScrollDown();
				break;
				case "postalcodelbl":
					portfolioObj.androidElementlblPOstalCode.androiElementverifyLabelonUI(attributeValue);
				break;
				case "postalcode":
					portfolioObj.androidElementInputPostalCode.AndroidDeviceInputvalues(attributeValue);
				break;
				case "UpdateSettingslbl":
					portfolioObj.androidElementlblupdateSettings.androiElementverifyLabelonUI(attributeValue);
				break;
				case "applytoallholdinglbl":
					portfolioObj.androidElementlblapplytoallHoldings.androiElementverifyLabelonUI(attributeValue);
				break;
				case "applytoallholdingbtn":
					portfolioObj.androidElementbtnapplytoallHoldings.AndroidElementClick();
				break;
				case "applytoindividualholdinglbl":
					portfolioObj.androidElementlblapplytoIndividualHolding.androiElementverifyLabelonUI(attributeValue);
				break;
				case "applytoindividualholdingbtn":
					portfolioObj.androidElementbtnapplytoIndividualHoldings.AndroidElementClick();
				break;
				case "IdividuallyselectHoldinglbl":
					portfolioObj.androidElementlblIndividuallySelectHolding.androiElementverifyLabelonUI(attributeValue);
				break;
				case "IdividuallyselectHoldingbtn":
					portfolioObj.androidElementbtnIndividuallySelectHolding.AndroidElementClick();
				break;
			}
		}
	}
	
	
	@And("I Validate Change Address Details pop up UI")
	public void I_Validate_ChangeAddress_Details_UI (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "AddressDetailslbl":
						portfolioObj.androidElementlblAddresspopupUIdetails.androiElementverifyLabelonUI(attributeValue);
					break;
				case "IndividualHoldinglbl":
						portfolioObj.androidElementlblIndividualHolding.androiElementverifyLabelonUI(attributeValue);
					break;
				case "Togglebtn":
					portfolioObj.androidElementlblsrnswitch.AndroidElementIsDisplayed();
				break;
				case "RegisteredHoldingbl":
					portfolioObj.androidElementlblregisteredHolde.androiElementverifyLabelonUI(attributeValue);
				break;
				case "Issuerlbl":
					portfolioObj.androidElementlblAddressIssuer.androiElementverifyLabelonUI(attributeValue);
				 break;
				case "Addresslbl":
					portfolioObj.androidElementlblChangeAddress.androiElementverifyLabelonUI(attributeValue);
				break;
				case "Applybtn":
					portfolioObj.androidElementApplybtn.AndroidElementClick();
				break;
			}
		}
	}

	@And("I Validate Confirmation Details UI")
	public void I_Validate_Confirmation_Details_UI (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "confirmlbl":
						portfolioObj.androidElementlblConfirmationScreen.androiElementverifyLabelonUI(attributeValue);
					break;
				case "Pleaseconfirmthatyouwantlbl":
						portfolioObj.androidElementlblPleaseConfirmthatyouwanttoProceed.androiElementverifyLabelonUI(attributeValue);
					break;
				case "addresslbl":
						portfolioObj.androidElementlblComfirmAddressDetails.androidElementgetLabelIsDisplayed();
				break;
				case "addressdata":
//						portfolioObj.androidElementlblAddressdataDetails.androiElementverifyLabelonUI(attributeValue);
				break;
				case "applytolbl":
					portfolioObj.androidElementlblAddressdataApplyTo.androiElementverifyLabelonUI(attributeValue);
			break;
				case "ivclbl":
					portfolioObj.androidElementlblIVC.androiElementverifyLabelonUI(attributeValue);
			break;
				case "RegisteredHolderlbl":
					portfolioObj.androidElementlblRegisteredHolder.androiElementverifyLabelonUI(attributeValue);
			break;
				case "issuerlbl":
					portfolioObj.androidElementconfirmlblIssuer.androiElementverifyLabelonUI(attributeValue);
			break;
			}
		}
	}
	
	
	@And("I Validate Success Screen UI")
	public void I_Validate_Success_Details_UI (List<Map<String,String>> portfolioDetails) throws Exception{
		Thread.sleep(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
				case "Successlbl":
						portfolioObj.androidElementlblSuccess.androiElementverifyLabelonUI(attributeValue);
					break;
				case "Addressdetailslbl":
						portfolioObj.androidElementlblAddressdetails.androiElementverifyLabelonUI(attributeValue);
					break;
				case "Aletterwillbelbl":
						portfolioObj.androidElementlblAletterwillbesent.androidElementgetLabelIsDisplayed();
				break;
			}
		}
	}
	
	@Then("I Click on Communications Option Edit Button")
	public void i_click_on_communications_option_edit_button() {
		portfolioObj.androidElementbtnCommunicationOptionEdit.AndroidElementClick();
		Hardwait.staticWait(20000);
	}	
	
	@Then("I Validate Landing on Portfolio Screen on IOS")
	public void i_validate_landing_on_portfolio_screen_on_ios() {
		portfolioObj.iosElementlblPOrtfolio.iosElementgetLabelIsDisplayed();
	}
	
	@Then("I Validate Landing on Add Holding Screen on IOS")
	public void i_validate_landing_on_AddHolding_screen_on_ios() {
		portfolioObj.iosElementlblAddHolding.iosElementgetLabelIsDisplayed();
	}
	
	@Then("I Click on Accounts menu Button")
	public void i_click_on_accounts_menu_button() {
		Hardwait.staticWait(3000);
		portfolioObj.iosElementbtnAcctountMenu.IOSElementClick();
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>AUTO GENERATED BY CONFLICT EXTENSION>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Feature_Varun
	}
	
	
	
	
}
