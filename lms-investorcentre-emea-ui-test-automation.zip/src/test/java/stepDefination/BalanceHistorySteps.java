package stepDefination;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import ActionsFactory.FindIOSElements;
import DateFactory.DateFunction;
import DriverFactory.ThreadLocalIOSDriver;
import Hardwait.Hardwait;
import WebTableFactory.WebTableFactory;
import io.appium.java_client.AppiumBy;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.BalanceHistoryPage;

public class BalanceHistorySteps {
	
	BalanceHistoryPage BalanceHistory_PageObject=null;

	SoftAssert softAssert=new SoftAssert();

		public BalanceHistorySteps() {
			BalanceHistory_PageObject=new BalanceHistoryPage();
		}
	
		
		@And("I Select Balance Date in filter date to {string}")
		public void  I_Select_Balance_Date_in_filter_date(String filterdate) {
			BalanceHistory_PageObject.txtDate.ClearInputText();
			BalanceHistory_PageObject.txtDate.Inputvalues(filterdate);
		}
		
		
	@Then("I validate date filter is applied to {string}")
	public void I_Validate_Date_is_applied_with_filter(String filterDate) throws Exception{
		String filterdate = DateFunction.dateFormatChange(filterDate);
		String lblfilterDate = BalanceHistory_PageObject.lblFilter.getTextlabel();
		Assert.assertEquals(filterdate, lblfilterDate);
	}
	
	@And("I Validate IVC is applied with filter to {string} for Balance History")
	public void I_Validate_table_data_from_Balance_History(String IVCData) {
		Hardwait.staticWait(5000);
		List<WebElement> Row_Issuer = BalanceHistory_PageObject.lblIVC.GetNoOfWebElements();
		WebTableFactory.validateDatainWebTable(Row_Issuer.size(), Row_Issuer, "IVC", IVCData);
	}
	
	@Then("I Tap on chevron icon of any individual Issuer Card")
	public void i_tap_on_chevron_icon_of_any_individual_issuer_card() {
	   BalanceHistory_PageObject.iosElementIndividualIssuer.IOSElementClick();
	}

	@When("I Tap on chevron icon of any individual Holding")
	public void i_tap_on_chevron_icon_of_any_individual_holding() {
		BalanceHistory_PageObject.iosElementIndividualHoldings.IOSElementClick();
	}
		
	@When("I Tap on chevron icon of any individual Holding {string}")
	public void i_tap_on_chevron_icon_of_any_individual_holding(String IndividualHoldings) {
		ThreadLocalIOSDriver.getDriver().findElement(AppiumBy.xpath("(//XCUIElementTypeStaticText[@label='"+IndividualHoldings+"'])[1]")).click();
	}
	
	@When("I Tap on Holdings tab")
	public void i_tap_on_holdings_tab() {
		BalanceHistory_PageObject.iosElementbtnHoldings.IOSElementClick();
	}

	@When("I Tap on Validate Below sections in Holdings Tab")
	public void i_tap_on_validate_below_sections_in_holdings_tab(List<Map<String,String>> portfolioDetails) {
		Hardwait.staticWait(5000);
		for(Map<String, String> portfolio:portfolioDetails) {
			System.out.println(portfolio.get("AttributeName")+":"+portfolio.get("AttributeValue"));
			String attributeValue=portfolio.get("AttributeValue");
			String attributeName = portfolio.get("AttributeName");
			switch (attributeName) {
			case "TransactionSectionLabel":
					BalanceHistory_PageObject.lblTransactionSectionLabel.iosElementgetLabelIsDisplayed();
				break;
				case "BalanceSectionlbl":
					BalanceHistory_PageObject.lblBalanceSectionLabel.iosElementgetLabelIsDisplayed();
					break;
				case "ViewBylbl":
					BalanceHistory_PageObject.lblBalanceLabelrow.iosElementgetLabelIsDisplayed();
					break;
				default:
				break;
			}
		}
	}
	
}
