package stepDefination;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.ThreadLocalDriver;
import Hardwait.Hardwait;
import ScreenshotFactory.TakeScreenshot;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pageObject.Commonfunctions;
import pageObject.DripPage;

public class Drip {

	DripPage drippage = null;

	Commonfunctions commonfunctions = null;

	SoftAssert softAssert = new SoftAssert();

	public static WebDriver driver = null;
	JavascriptExecutor JavaScriptExec = (JavascriptExecutor) driver;

	public Drip() {
		drippage = new DripPage();
		commonfunctions = new Commonfunctions();
	}

	@Then("I navigate to Devident Reinvestment screen")
	public void i_navigate_to_devident_reinvestment_screen() {
		drippage.tabPayment.ActionMouseHover();
		drippage.tabDividendReinvestment.Click();
		drippage.lblheader.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Dividend Reinvestment tab");
	}

	@Then("I click on Create instruction link for zero balance holding")
	public void i_click_on_create_instruction_link_for_zero_balance_holding() {
		drippage.linkcreateinstrcution.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Create instruction link for zero balance holding");
	}
	
	@Then("I click on Create instruction link for available balance holding")
	public void i_click_on_create_instruction_link_for_available_balance_holding() {
		drippage.linkcreateinstrcution1.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Create instruction link for available balance holding");
	}
	
	@Then("I terminate the instruction")
	public void I_terminate_the_instruction() throws Exception {
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
		drippage.linkterminateinstrcution2.Click();
		Thread.sleep(5000);
		drippage.btntermscondition.Click();
		drippage.btnconfirm.Click();
		Thread.sleep(5000);
		drippage.btnconfirm.Click();
		drippage.btndone.ValidateIsButtonDisplayed();
		drippage.btndone.Click();		
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
	}
	
	@Then("I terminate the instruction for available balance holding")
	public void I_terminate_the_instruction_for_available_balance_holding() throws Exception {
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
		drippage.linkterminateinstrcution3.Click();
		Thread.sleep(5000);
		drippage.btntermscondition.Click();
		drippage.btnconfirm.Click();
		Thread.sleep(5000);
		drippage.btnconfirm.Click();
		drippage.btndone.ValidateIsButtonDisplayed();
		drippage.btndone.Click();		
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
	}
	
	@Then("I create instruction for zero balance holding")
	public void I_create_instruction_for_zero_balance_holding() throws Exception {
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
		drippage.linkcreateinstrcution2.Click();
		Thread.sleep(5000);
		drippage.btntermscondition.Click();
		drippage.btnconfirm.Click();
		Thread.sleep(5000);
		drippage.btnconfirm.Click();
		drippage.btndone.ValidateIsButtonDisplayed();
		drippage.btndone.Click();		
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
	}
	
	@Then("I create instruction for available balance holding")
	public void I_create_instruction_for_available_balance_holding() throws Exception {
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
		drippage.linkcreateinstrcution3.Click();
		Thread.sleep(5000);
		drippage.btntermscondition.Click();
		drippage.btnconfirm.Click();
		Thread.sleep(5000);
		drippage.btnconfirm.Click();
		drippage.btndone.ValidateIsButtonDisplayed();
		drippage.btndone.Click();		
		Thread.sleep(120000);
		ThreadLocalDriver.getDriver().navigate().refresh();
	}

	@Then("I click on Terminate instruction link for zero balance holding")
	public void i_click_on_Terminate_instruction_link_for_zero_balance_holding() {
		drippage.linkterminateinstrcution.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Terminate instruction link for zero balance holding");
	}
	
	@Then("I click on Terminate instruction link for available balance holding")
	public void i_click_on_Terminate_instruction_link_for_available_balance_holding() {
		drippage.linkterminateinstrcution1.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Terminate instruction link for available balance holding");
	}
	
	@Then("validate landed on {string} page")
	public void validate_landed_on_page(String subheader) {
		Hardwait.staticWait(15000);
		drippage.lblsubheader.verifyLabelonUI(subheader);
		new TakeScreenshot();
	}

	@Then("validate instructional text is displayed as {string}")
	public void validate_instructional_text_is_displayed(String note) {
		drippage.lblnote.scrollToElement();
		new TakeScreenshot();
		drippage.lblinstNote.verifyLabelonUI(note);
	}

	@Then("validate {string} link is displayed")
	public void validate_link_is_displayed(String link) {
		drippage.lbllink.verifyLabelonUI(link);
		new TakeScreenshot();
	}
	
	@Then("Validate the success message as {string}")
	public void validate_the_success_message_as(String successMessage) throws Exception {
		Thread.sleep(10000);
	    drippage.lblsubheader.verifyLabelonUI(successMessage);
	    new TakeScreenshot();
	}
	
	@Then("validate status of issuer is changed to {string}")
	public void validate_status_of_issuer_is_changed_to(String DC) throws Exception {
		try {
			Thread.sleep(120000);
			ThreadLocalDriver.getDriver().navigate().refresh();
			drippage.lbldevidentchoice.verifyLabelonUI(DC);
		} catch (Exception e) {
			Thread.sleep(60000);
			ThreadLocalDriver.getDriver().navigate().refresh();
			drippage.lbldevidentchoice.verifyLabelonUI(DC);
		}
		
		new TakeScreenshot();
	}
	
	@Then("validate After termination status of issuer is changed to {string}")
	public void validate_After_termination_status_of_issuer_is_changed_to(String DC) throws Exception {
		try {
			Thread.sleep(120000);
			ThreadLocalDriver.getDriver().navigate().refresh();
			drippage.lbldevidentchoice1.verifyLabelonUI(DC);
		} catch (Exception e) {
			Thread.sleep(60000);
			ThreadLocalDriver.getDriver().navigate().refresh();
			drippage.lbldevidentchoice1.verifyLabelonUI(DC);
		}
		
		new TakeScreenshot();
	}

	@Then("validate terms and condition checkbox is displayed")
	public void validate_terms_and_condition_checkbox_is_displayed() {
		drippage.btntermscondition.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("validate cancel and Continue button is displayed")
	public void validate_cancel_and_continue_button_is_displayed() {
		drippage.btnback.ValidateIsButtonDisplayed();
		drippage.btnconfirm.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("I valide the cancel,back and continue button")
	public void i_valide_the_cancel_back_and_continue_button() {
		drippage.btnback.ValidateIsButtonDisplayed();
		drippage.btnconfirm.ValidateIsButtonDisplayed();
		drippage.btnBack.ValidateIsButtonDisplayed();
		new TakeScreenshot();
	}

	@Then("I validate and click on Done button")
	public void i_validate_and_click_on_done_button() {
		drippage.btndone.ValidateIsButtonDisplayed();
		drippage.btndone.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Done button on Confirm receipt page");
		new TakeScreenshot();
	}

	@Then("i click on I confirm the above checkbox")
	public void i_click_on_i_confirm_the_above_checkbox() {
		drippage.btntermscondition.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on I confirm the above checkbox");
	}

	@Then("I click on continue button")
	public void i_click_on_continue_button() {
		drippage.btnconfirm.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on confirm button");
	}

	@Then("I click on cancel button")
	public void i_click_on_cancel_button() {
		drippage.btnback.Click();
		new TakeScreenshot();
		ExtentCucumberAdapter.addTestStepLog("Clicked on cancel button");
	}

	@Then("i click on Click here to view full terms link")
	public void i_click_on_click_here_to_view_full_terms_link() {
		drippage.btnlink.Click();
		ExtentCucumberAdapter.addTestStepLog("Clicked on Click here to view full terms link");

	}
	
	@Then("I click on back button on confirm reinvestment page")
	public void i_click_on_back_button_on_confirm_reinvestment_page() {
	    drippage.btnBack.Click();
	    ExtentCucumberAdapter.addTestStepLog("Clicked on back button");
	    new TakeScreenshot();
	}
	
	@Then("i select {string} from payment type dropdown")
	public void i_select_from_payment_type_dropdown(String paymentType) {
	    drippage.selpaymentType.selectByValue(paymentType);
	    ExtentCucumberAdapter.addTestStepLog("Selected payment type as " +paymentType);
	    new TakeScreenshot();
	}
	
	@Then("I enter {string} in Sort Code textbox")
	public void I_enter_in_sort_code_textbox(String Sort) { 
		drippage.sortcodetextbox.ClearInputvalues();
		drippage.sortcodetextbox.Inputvalues(Sort);
		ExtentCucumberAdapter.addTestStepLog("Entered sort code as  " +Sort);
	    new TakeScreenshot();
	}
	
	@Then("I enter {string} in Account number textbox for UK")
	public void I_enter_in_account_number_textbox_for_UK(String AccountNumber) {
		drippage.actnotextbox.ClearInputvalues();
		drippage.actnotextbox.Inputvalues(AccountNumber);
		ExtentCucumberAdapter.addTestStepLog("Entered Account no as  " +AccountNumber);
	    new TakeScreenshot();
	}
	
	@Then("I enter {string} in Building society roll number textbox")
	public void I_enter_in_building_society_roll_number_textbox(String rollno) {
		if (rollno.equalsIgnoreCase("Random"))
			rollno = commonfunctions.generateRandomNumericString(6);
		drippage.bsrntextbox.ClearInputvalues();
		drippage.bsrntextbox.Inputvalues(rollno);
		ExtentCucumberAdapter.addTestStepLog("Entered Building society roll number as  " +rollno);
	    new TakeScreenshot();
	}
	@Then("I click on click here to edit Link on confirm receipt page")
	public void I_click_on_click_here_to_edit_link_on_confirm_receipt_page() throws Exception {
		Thread.sleep(5000);
		drippage.clickheretoedit.scrollToElement();
	    drippage.clickheretoeditlink.Click();
	    ExtentCucumberAdapter.addTestStepLog("Clicked on click here to edit link");
	    new TakeScreenshot();
	}
	
	@Then("I click on next button on Payment instruction page")
	public void i_click_on_next_button_on_payment_instruction_page() {
	    drippage.btnnext.Click();
	    ExtentCucumberAdapter.addTestStepLog("Clicked on Next button");
	    new TakeScreenshot();
	}
	
	@And("I click on Confirm button")
	public void I_click_on_Confirm_button() {
	    drippage.btnconfirm1.Click();
	    ExtentCucumberAdapter.addTestStepLog("Clicked on Confirm button");
	    new TakeScreenshot();
	}
	
	@Then("validate successfully navigated to terms and condition page")
	public void validate_successfully_navigated_to_terms_and_condition_page() throws Exception  {
		Thread.sleep(5000);
		ArrayList<String> tabs = new ArrayList<String>(ThreadLocalDriver.getDriver().getWindowHandles());
		ThreadLocalDriver.getDriver().switchTo().window(tabs.get(1));
		String lblDRIPTNC = ThreadLocalDriver.getDriver().findElement(By.xpath("(//P)[1]")).getText();
		String lblDRIPTNC1 = ThreadLocalDriver.getDriver().findElement(By.xpath("(//P)[2]")).getText();
		ExtentCucumberAdapter.addTestStepLog("Lavel found on T&C page is " +lblDRIPTNC  );
		ExtentCucumberAdapter.addTestStepLog("Lavel found on T&C page is " +lblDRIPTNC1 );
		new TakeScreenshot();
		ThreadLocalDriver.getDriver().close();
		ThreadLocalDriver.getDriver().switchTo().window(tabs.get(0));
		new TakeScreenshot();
	}

	@Then("I verify the result grid with below data")
	public void i_verify_the_result_grid_with_below_data(List<Map<String, String>> GridDetails) throws Exception {
		for (Map<String, String> drip : GridDetails) {
			Thread.sleep(5000);
			System.out.println(drip.get("AttributeName") + ":" + drip.get("AttributeValue"));
			String attributeValue = drip.get("AttributeValue");
			String attributeName = drip.get("AttributeName");
			switch (attributeName) {
			case "Issuer code":
				String Issuercodelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[3]"))
						.getText();
				Assert.assertEquals(Issuercodelavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has Issuer code column ");
				break;

			case "ivc":
				String ivclavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[5]"))
						.getText();
				Assert.assertEquals(ivclavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has IVC column ");
				break;

			case "plan":
				String planlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[7]"))
						.getText();
				Assert.assertEquals(planlavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has Plan column ");
				List<WebElement> DRIP = drippage.lblDRIP.GetNoOfWebElements();
				if (DRIP.size() > 0) {
					ExtentCucumberAdapter.addTestStepLog("Plan column consist of DRIP data -" + DRIP.size());
				}
				List<WebElement> SCRIP = drippage.lblSCRIP.GetNoOfWebElements();
				if (SCRIP.size() > 0) {
					ExtentCucumberAdapter.addTestStepLog("Plan column consist of SCRIP data -" + SCRIP.size());
				}
				break;

			case "balance":
				String balancelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[8]"))
						.getText();
				Assert.assertEquals(balancelavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has Balance column ");
				List<String> balance = drippage.lblbalance.GetListOfWebElements();
				String first = balance.get(0);
				String first1 = first.replace(",", "");
				int firstelement = Integer.parseInt(first1);
				if (firstelement >= 0) {
					ExtentCucumberAdapter
							.addTestStepLog("Balance column contains value greater then and equal to zero");
				}

				ExtentCucumberAdapter.addTestStepLog("Balance column contains value -" + balance);
				break;

			case "Dividendchoice":
				String Dividendchoicelavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("//table//tr[1]//th[9]")).getText();
				Assert.assertEquals(Dividendchoicelavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has devident choice column ");
				List<WebElement> devidentreinvest = drippage.lblreinvestdevident.GetNoOfWebElements();
				if (devidentreinvest.size() > 0) {
					ExtentCucumberAdapter.addTestStepLog(
							"Devident choice column consist of reinvest devident data -" + devidentreinvest.size());
				}
				List<WebElement> donotreinvest = drippage.lbldonotreinvest.GetNoOfWebElements();
				if (donotreinvest.size() > 0) {
					ExtentCucumberAdapter.addTestStepLog(
							"Devident choice column consist of do not reinvest data -" + donotreinvest.size());
				}
				break;

			case "action":
				String actionlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tr[1]//th[15]"))
						.getText();
				Assert.assertEquals(actionlavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has Action column");
				List<WebElement> terminateinstruction = drippage.lblterminateinstruction.GetNoOfWebElements();
				if (terminateinstruction.size() > 0) {
					ExtentCucumberAdapter.addTestStepLog(
							"Action column consist of terminate instruction data -" + terminateinstruction.size());
				}
				List<WebElement> createInstruction = drippage.lblcreatinstruction.GetNoOfWebElements();
				if (createInstruction.size() > 0) {
					ExtentCucumberAdapter.addTestStepLog(
							"Action column consist of create instruction data -" + createInstruction.size());
				}
				new TakeScreenshot();
				break;
			}
		}
	}

	@Then("I validate the confirm reinvestment page with below data")
	public void i_validate_the_confirm_reinvestment_page_with_below_data(List<Map<String, String>> ConfirmpageDetails)
			throws Exception {
		for (Map<String, String> drip : ConfirmpageDetails) {
			Thread.sleep(5000);
			System.out.println(drip.get("AttributeName") + ":" + drip.get("AttributeValue"));
			String attributeValue = drip.get("AttributeValue");
			String attributeName = drip.get("AttributeName");
			switch (attributeName) {

			case "Security":
				drippage.lblsecurity.scrollToElement();
				String Securitylavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tbody//tr[1]//td)[1]")).getText();
				//Assert.assertEquals(Securitylavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has security details " +Securitylavel);
				break;

			case "Holder":
				String Holderlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tbody//tr[2]//td"))
						.getText();
				//Assert.assertEquals(Holderlavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has Holder details " +Holderlavel);
				break;

			case "Holding":
				String Holdinglavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tbody//tr[3]//td"))
						.getText();
				Assert.assertEquals(Holdinglavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has Holding details ");
				break;

			case "Plan":
				String Planlavel = ThreadLocalDriver.getDriver().findElement(By.xpath("//table//tbody//tr[4]//td"))
						.getText();
				Assert.assertEquals(Planlavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Result grid has plan details as DRIP");
				break;

			case "Instruction text":
				String Instructiontextlavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("//table//..//preceding-sibling::p")).getText();
				Assert.assertEquals(Instructiontextlavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Instructional text has been succesfully verified ");
				break;

			case "Dividend Choice:":
				String DividendChoicelavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tbody//tr[1]//td)[2]")).getText();
				Assert.assertEquals(DividendChoicelavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Devident choice field verified ");
				new TakeScreenshot();
				break;
			}
		}
	}

	@Then("I validate the below details on Confirm receipt page")
	public void i_validate_the_below_details_on_confirm_receipt_page(List<Map<String, String>> confirmation)
			throws Exception {
		for (Map<String, String> drip : confirmation) {
			Thread.sleep(5000);
			System.out.println(drip.get("AttributeName") + ":" + drip.get("AttributeValue"));
			String attributeValue = drip.get("AttributeValue");
			String attributeName = drip.get("AttributeName");
			switch (attributeName) {

			case "Instruction Lodged":

				String InstructionLodgedlavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//..//preceding-sibling::p)[2]")).getText();
				Assert.assertEquals(InstructionLodgedlavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Instruction lodged section has been successfully verified");
				break;

			case "Dividend Choice":

				String DividendChoicelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("(//table//tr//td)[5]"))
						.getText();
				Assert.assertEquals(DividendChoicelavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Devident choice section has been successfully verified");
				break;

			case "Transaction ID":

				String TransactionIDlavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tr[2]//td)[2]")).getText();
				//Assert.assertEquals(TransactionIDlavel, attributeValue);
				ExtentCucumberAdapter.addTestStepLog("Transaction ID is " +TransactionIDlavel);
				break;

			case "Transaction Date":

				String TransactionDatelavel = ThreadLocalDriver.getDriver()
						.findElement(By.xpath("(//table//tr[3]//td)[2]")).getText();
				
				ExtentCucumberAdapter.addTestStepLog("Transaction Date is " +TransactionDatelavel);
				break;

			case "Message:":

				String Messagelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("(//table//tr[4]//td)[2]"))
						.getText();
				Assert.assertEquals(Messagelavel, attributeValue);
				new TakeScreenshot();
				ExtentCucumberAdapter.addTestStepLog("Message section has been successfully verified");
				break;
				
			case "Title":

				String Titlelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("(//table//..//following-sibling::p)[3]"))
						.getText();
				Assert.assertEquals(Titlelavel, attributeValue);
				new TakeScreenshot();
				ExtentCucumberAdapter.addTestStepLog("Title has been successfully verified");
				break;
				
			case "Link":

				String Linklavel = ThreadLocalDriver.getDriver().findElement(By.xpath("(//table//..//following-sibling::p)[4]"))
						.getText();
				softAssert.assertEquals(Linklavel, attributeValue);
				new TakeScreenshot();
				ExtentCucumberAdapter.addTestStepLog("Click here to edit link has been successfully verified");
				break;
				
			case "Payment Type":

				String Payment_Typelavel = ThreadLocalDriver.getDriver().findElement(By.xpath("(//table//tr[1]//td)[3]"))
						.getText();
				Assert.assertEquals(Payment_Typelavel, attributeValue);
				new TakeScreenshot();
				ExtentCucumberAdapter.addTestStepLog("Payment Type has been successfully verified");
				break;
			}
		}
	}
}
