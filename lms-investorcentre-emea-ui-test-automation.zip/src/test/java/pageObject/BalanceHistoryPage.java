package pageObject;

import ActionsFactory.ListActions;
import ActionsFactory.ValidateLabelUI;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import Selenium.LocatorType;

public class BalanceHistoryPage {
	
	String lblPaymentHistoryPath = "//*[@id=\"mainContent\"]/h1";
	public Label lblPaymentHistory= new Label(lblPaymentHistoryPath,LocatorType.XPATH);
	
	String txtDateToPath = "//input[@id='BalanceDate']";
	public Input txtDate = new Input(txtDateToPath,LocatorType.XPATH);
	
	String lblFilterPath = "//*[@id='filterDate']";
	public Label lblFilter = new Label(lblFilterPath, LocatorType.XPATH);  
	
	String btnGoPath = "//button[@id='btnGo']";
	public Button btnGo = new Button(btnGoPath,LocatorType.XPATH);
	
	String lblIVCPath = "//table[@id='HoldingsBalanceGrid']/tbody/tr/td[2]";
	public ListActions lblIVC = new ListActions(lblIVCPath);
	
	//IOS Elements
	//IndividualIssuer
	String iosElementIndividualIssuerPath = "(//XCUIElementTypeCell)[1]";
	public Button iosElementIndividualIssuer = new Button(iosElementIndividualIssuerPath,LocatorType.XPATH);
	
	//IndividualHoldings
	String iosElementIndividualHoldingsPath = "(//XCUIElementTypeCell)[1]";
	public Button iosElementIndividualHoldings = new Button(iosElementIndividualHoldingsPath,LocatorType.XPATH);
	
	//Holdings
	String iosElementbtnHoldingsPath = "//XCUIElementTypeStaticText[@name='Holdings']";
	public Button iosElementbtnHoldings = new Button(iosElementbtnHoldingsPath,LocatorType.XPATH);
	
	//TransactionSectionLabel
	String lblTransactionSectionLabelPath = "//XCUIElementTypeStaticText[@label='Transactions']";
	public Label lblTransactionSectionLabel = new Label(lblTransactionSectionLabelPath, LocatorType.XPATH);
	
	//BalanceSectionLabel
	String lblBalanceSectionLabelPath = "(//XCUIElementTypeStaticText[@label='Balance'])[2]";
	public Label lblBalanceSectionLabel = new Label(lblBalanceSectionLabelPath, LocatorType.XPATH);  
	
	//lblBalanceLabelrowPath
	String lblBalanceLabelrowPath = "(//XCUIElementTypeStaticText[@label='Balance'])[3]";
	public Label lblBalanceLabelrow = new Label(lblBalanceLabelrowPath, LocatorType.XPATH);  
	
	
	
}
