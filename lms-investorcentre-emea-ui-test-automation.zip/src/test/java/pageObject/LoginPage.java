package pageObject;

import java.util.ArrayList;

import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import Selenium.LocatorType;

/**
 * @author Varun Paranganath
 *05/05/2023
 *TestAutomationFramework
 */

public class LoginPage {

	String btnLoginPath = "//*[@value='Login']";
	public Button btnLogin=new Button(btnLoginPath,LocatorType.XPATH);
	
	String lblPlansPath = "//*[text()='Plans']";
	public Actions lblPlans= new Actions(lblPlansPath, LocatorType.XPATH);
	
	String btnLogonPath = "(//button[@id='btnLogin'])[1]";
	public Button btnLogon = new Button(btnLogonPath, LocatorType.XPATH);
	
	String btnLogonsubmitPath = "//input[@type='submit']";
	public Button btnLogonsubmit = new Button(btnLogonsubmitPath, LocatorType.XPATH);

	
	String btnLogintopPath = "(//*[@id=\"btnLogin\"])[1]";
	public Button btnLogintop = new Button(btnLogintopPath, LocatorType.XPATH);
	
	String txtUsernamePath = "//input[@name='identifier']";
	public Input txtUsername = new Input(txtUsernamePath, LocatorType.XPATH);
	
	String  txtPasswordPath = "//input[@type='password']";
	public Input txtPassword = new Input(txtPasswordPath, LocatorType.XPATH);
	
	String  btnNextPath = "//*[@value='Next']";
	public Button btnNext = new Button(btnNextPath, LocatorType.XPATH);
	
	String  btnshowPasswordPath = "(//*[contains(@class,'eyeicon visibility')])[1]";
	public Button btnshowPassword = new Button(btnshowPasswordPath, LocatorType.XPATH);
	
	String chkRememberMePath = "//label[@data-se-for-name='rememberMe']";
	public Button chkRememberMe = new Button(chkRememberMePath, LocatorType.XPATH);
	
	String lblResetPasswordPath = "//h2[@class='okta-form-title o-form-head']";
	public Label lblResetPassword = new Label(lblResetPasswordPath, LocatorType.XPATH);
	
	String lblRememberMePath = "//label[@data-se-for-name='rememberMe']";
	public Label lblRememberMe = new Label(lblRememberMePath, LocatorType.XPATH);
	
	String lblCookiespopUpPath = "//h2[@id='cookiesheading']";
	public Label lblCookiespopUp = new Label(lblCookiespopUpPath, LocatorType.XPATH);
	
	String btnAgreeCookiesPath = "//button[@id='acceptBtn']";
	public Button btnAgreeCookies = new Button(btnAgreeCookiesPath, LocatorType.XPATH);
	
	String btnRejectCookiesPath = "//button[@id='rejectBtn']";
	public Button btnRejectCookies = new Button(btnRejectCookiesPath, LocatorType.XPATH);
	
	String lblFAQsPath = "(//a[@class='nav-link'])[2]";
	public Label lblFAQs = new Label(lblFAQsPath, LocatorType.XPATH);
	
	
	String lblErrorMessagePath = "(//*[@role='alert'])[2]";
	public Label lblErrorMessage = new Label(lblErrorMessagePath, LocatorType.XPATH);  
	
	String btnForgetPasswordPath = "//a[@class='link js-forgot-password']";
	public Button btnForgetPassword = new Button(btnForgetPasswordPath, LocatorType.XPATH);
	
	String btnHelpPath = "//a[@class='link js-help']";
	public Button btnHelp = new Button(btnHelpPath, LocatorType.XPATH);

	String btnRegisterNowTopPath = "//button[@id='btnRegisterNowTop']";
	public Button btnRegisterNowTop = new Button(btnRegisterNowTopPath, LocatorType.XPATH);
	
	String lblVerifyEmailPath = "//div[@id='PostSuccessfulVerification']/h2";
	public Label lblVerifyEmail = new Label(lblVerifyEmailPath, LocatorType.XPATH);
	
	String lblEnterEmailPath = "//label[@for='Email']";
	public Label lblEnterEmail = new Label(lblEnterEmailPath, LocatorType.XPATH);
	
	String btnRegisterNowPath = "//button[@id='btnRegisterNow']";
	public Button btnRegisterNow = new Button(btnRegisterNowPath, LocatorType.XPATH);
	
	String btnLinkMarketServicesLogoPath = "(//img[@alt='Investor Centre' and @class='logo'])[2]";
	public Button btnLinkMarketServicesLogo = new Button(btnLinkMarketServicesLogoPath, LocatorType.XPATH);
	
	String lblLinkMarketServicesLogoPath = "//p[@id='beforegenerate']";
	public Label lblLinkMarketServicesLogo = new Label(lblLinkMarketServicesLogoPath, LocatorType.XPATH);
	
	String txtEmailpath = "//label[@for='Email']";
	public Label txtEmail = new Label(txtEmailpath, LocatorType.XPATH); 
	
	String chkCapchaPath = "//div[@class='rc-anchor-center-item rc-anchor-checkbox-holder']";
	public Button chkCapcha = new Button(chkCapchaPath, LocatorType.XPATH);
	
	String lblamNotARobotPath = "//label[@id='recaptcha-anchor-label']";
	public Label lblamNotARobot = new Label(lblamNotARobotPath, LocatorType.XPATH);
	
	String btnGeneratePinPath = "//button[@id='btnGenerateEmailPin']";
	public Button btnGeneratePin = new Button(btnGeneratePinPath, LocatorType.XPATH);
	
	String btnCancelPath = "//span[@id='CancelVerifyEmail']";
	public Button btnCancel = new Button(btnCancelPath, LocatorType.XPATH);
	
	
	public Label lblInstructionslText;
	String lblInstructionslTextPath;
	
	public String getLablelInstructionsText() {
		lblInstructionslTextPath = "//*[@id='loginContent']/div[1]";
		 lblInstructionslText = new Label(lblInstructionslTextPath, LocatorType.XPATH);
		   java.util.Scanner scanner = new java.util.Scanner(lblInstructionslText.getTextlabel());
			  StringBuffer sb = new StringBuffer();
				while (scanner.hasNextLine()) {
				  sb.append(scanner.nextLine());
				}
		return sb.toString();
	}
	
	// Android UI Actions //
	String androidElementbtnLoginPath = "//android.widget.Button[@text='OK']";
	public Button btnandroidElementbtnLoginPath=new Button(androidElementbtnLoginPath,LocatorType.XPATH);
	
	String androidElementSelPleaseSelectPath = "//android.widget.TextView[@text='Please select...']";
	public Button androidElementSelPleaseSelect=new Button(androidElementSelPleaseSelectPath,LocatorType.XPATH);

	String androidElementSelUKPath = "//android.widget.TextView[@index=3]";
	public Button androidElementSelUK=new Button(androidElementSelUKPath,LocatorType.XPATH);
	
	String androidElementbtnContinuePath = "//android.widget.Button[@text='Continue']";
	public Button androidElementbtnContinue=new Button(androidElementbtnContinuePath,LocatorType.XPATH);

	String androidElementlblWelcomeToHomeScreenPath = "//android.widget.TextView[@index=1]";
	public Label androidElementlblWelcomeToHomeScreen=new Label(androidElementlblWelcomeToHomeScreenPath,LocatorType.XPATH);
	
	
	// IOS UI Actions //
	String iosElementlblWelcometoLinkPath = "//XCUIElementTypeStaticText[@name='Welcome to Link Market Services']";
	public Label iosElementlblWelcometoLink=new Label(iosElementlblWelcometoLinkPath,LocatorType.XPATH);
	
	String iosElementSelPleaseSelectPath = "//XCUIElementTypeStaticText[@name='Please select...']";
	public Button iosElementSelPleaseSelect=new Button(iosElementSelPleaseSelectPath,LocatorType.XPATH);
	
	String iosElementSelUKPath = "//XCUIElementTypeStaticText[@name='United Kingdom']";
	public Button iosElementSelUK=new Button(iosElementSelUKPath,LocatorType.XPATH);
	
	String iosElementbtnContinuePath = "//XCUIElementTypeStaticText[@name='Continue']";
	public Button iosElementbtnContinue=new Button(iosElementbtnContinuePath,LocatorType.XPATH);
	
	String iosElementbtnLoginPath = "//XCUIElementTypeButton[@name='Login']";
	public Button iosElementbtnLogin=new Button(iosElementbtnLoginPath,LocatorType.XPATH);
	
	String iosElementpopupbtnContinuePath= "//XCUIElementTypeButton[@name='Continue']";
	public Button iosElementpopupbtnContinue=new Button(iosElementpopupbtnContinuePath,LocatorType.XPATH);
	
	String iosElementlblManageHoldingPath = "//XCUIElementTypeStaticText[@name='Manage Holdings']";
	public Label iosElementlblManageHolding=new Label(iosElementlblManageHoldingPath,LocatorType.XPATH);
	
	String iosElementlblEnterEmailPath = "//XCUIElementTypeStaticText[@name='Enter email']";
	public Label iosElementlblEnterEmail=new Label(iosElementlblEnterEmailPath,LocatorType.XPATH);
	
	String iosElementlblEnterPasswordPath = "//XCUIElementTypeStaticText[@name='Enter password']";
	public Label iosElementlblEnterPassword=new Label(iosElementlblEnterPasswordPath,LocatorType.XPATH);
	
	String iosElementlblKeepMeSignedInPath = "//XCUIElementTypeStaticText[@name='Keep me signed in']";
	public Label iosElementlblKeepMeSignedIn=new Label(iosElementlblKeepMeSignedInPath,LocatorType.XPATH);
	
	String iosElementtxtUsernamePath = "//XCUIElementTypeTextField";
	public Input iosElementtxtUsername=new Input(iosElementtxtUsernamePath,LocatorType.XPATH);

	String iosElementtxtPasswordPath = "//XCUIElementTypeSecureTextField";
	public Input iosElementtxtPassword=new Input(iosElementtxtPasswordPath,LocatorType.XPATH);
	
	String iosElementbtnLoginManageHoldingsPath= "(//XCUIElementTypeButton[@name=\"Login\"])[2]";
	public Button iosElementbtnLoginManageHoldings=new Button(iosElementbtnLoginManageHoldingsPath,LocatorType.XPATH);
			
	
	//Create PIN
	String iosElementlblSetupPinPath = "//XCUIElementTypeStaticText[@name='Setup PIN']";
	public Label iosElementlblSetupPin=new Label(iosElementlblSetupPinPath,LocatorType.XPATH);
	
	String iosElementlblSetup6DigitPinPath = "//XCUIElementTypeStaticText[@name='Setup a 6 digit PIN to securely login to the app. Would you like to setup a PIN?']";
	public Label iosElementlblSetup6DigitPin=new Label(iosElementlblSetup6DigitPinPath,LocatorType.XPATH);
	
	String iosElementlblYesSetupPinPath = "//XCUIElementTypeStaticText[@name='Yes, setup PIN']";
	public Label iosElementlblYesSetupPin=new Label(iosElementlblYesSetupPinPath,LocatorType.XPATH);

	String iosElementlblMayBeLaterPath = "//XCUIElementTypeStaticText[@name='Maybe later']";
	public Label iosElementlblMayBeLater=new Label(iosElementlblMayBeLaterPath,LocatorType.XPATH);
	
	public Button iosElementbtnMayBeLater=new Button(iosElementlblMayBeLaterPath,LocatorType.XPATH);
	
	String iosElementbtnSkipPath = "//XCUIElementTypeStaticText[@name='Skip']";
	public Button iosElementbtnSkip=new Button(iosElementbtnSkipPath,LocatorType.XPATH);
	
	String iosElementbtnNextPath = "//XCUIElementTypeButton[@name='next orange']";
	public Button iosElementbtnNext=new Button(iosElementbtnNextPath,LocatorType.XPATH);
	
	String iosElementlblEverythingYouNeedToManagePath = "//XCUIElementTypeStaticText[@name='Everything you need to manage your portfolio']";
	public Label iosElementlblEverythingYouNeedToManage=new Label(iosElementlblEverythingYouNeedToManagePath,LocatorType.XPATH);
	
	String iosElementlblQuicklyCheckPaymentsPath = "//XCUIElementTypeStaticText[@name='Quickly check payments and balances']";
	public Label iosElementlblQuicklyCheckPayments=new Label(iosElementlblQuicklyCheckPaymentsPath,LocatorType.XPATH);
	
	String iosElementlblAddHoldingsAsYourPortfolioPath = "//XCUIElementTypeStaticText[@name='Add holdings as your portfolio grows']";
	public Label iosElementlblAddHoldingsAsYourPortfolio=new Label(iosElementlblAddHoldingsAsYourPortfolioPath,LocatorType.XPATH);
	
	String iosElementlblEasilyManageYourSettingsAndPreferencesPath = "//XCUIElementTypeStaticText[@name='Easily manage your settings and preferences']";
	public Label iosElementlblEasilyManageYourSettingsAndPreferences=new Label(iosElementlblEasilyManageYourSettingsAndPreferencesPath,LocatorType.XPATH);

	String iosElementbtnGetStartedPath = "//XCUIElementTypeStaticText[@name='Get Started']";
	public Button iosElementbtnGetStarted=new Button(iosElementbtnGetStartedPath,LocatorType.XPATH);
	
	String iosElementbtnYesSetupPinPath = "//XCUIElementTypeStaticText[@name='Yes, setup PIN']";
	public Button iosElementbtnYesSetupPin=new Button(iosElementbtnYesSetupPinPath,LocatorType.XPATH);
  
	
	String iosElementlblCreatePinPath = "//XCUIElementTypeStaticText[@name='Create PIN']";
	public Label iosElementlblCreatePin=new Label(iosElementlblCreatePinPath,LocatorType.XPATH);

	String iosElementlblEnter6DigitPinPath = "//XCUIElementTypeStaticText[@name='Enter a 6-digit pin to securely log in to the app.']";
	public Label iosElementlblEnter6DigitPin=new Label(iosElementlblEnter6DigitPinPath,LocatorType.XPATH);

	String iosElementlblEnterPin1Path = "(//XCUIElementTypeOther/XCUIElementTypeStaticText[1])[last()]";
	public Input iosElementlblEnterPin1=new Input(iosElementlblEnterPin1Path,LocatorType.XPATH);

	String iosElementlblEnterPin2Path = "(//XCUIElementTypeOther/XCUIElementTypeStaticText[2])[last()]";
	public Input iosElementlblEnterPin2=new Input(iosElementlblEnterPin2Path,LocatorType.XPATH);

	
	String iosElementlblEnterPin3Path = "(//XCUIElementTypeOther/XCUIElementTypeStaticText[3])[last()]";
	public Input iosElementlblEnterPin3=new Input(iosElementlblEnterPin3Path,LocatorType.XPATH);

	
	String iosElementlblEnterPin4Path = "(//XCUIElementTypeOther/XCUIElementTypeStaticText[4])[last()]";
	public Input iosElementlblEnterPin4=new Input(iosElementlblEnterPin4Path,LocatorType.XPATH);

	
	String iosElementlblEnterPin5Path = "(//XCUIElementTypeOther/XCUIElementTypeStaticText[5])[last()]";
	public Input iosElementlblEnterPin5=new Input(iosElementlblEnterPin5Path,LocatorType.XPATH);

	
	String iosElementlblEnterPin6Path = "(//XCUIElementTypeOther/XCUIElementTypeStaticText[6])[last()]";
	public Input iosElementlblEnterPin6=new Input(iosElementlblEnterPin6Path,LocatorType.XPATH);
	
	String iosElementbtnSubmitPath = "//XCUIElementTypeStaticText[@name='Submit']";
	public Button iosElementbtnSubmit=new Button(iosElementbtnSubmitPath,LocatorType.XPATH);
	
	
	String iosElementlblConfirmPinPath = "//XCUIElementTypeStaticText[@name='Confirm PIN']";
	public Label iosElementlblConfirmPin=new Label(iosElementlblConfirmPinPath,LocatorType.XPATH);

	String iosElementlblReEnter6DigitPinPath = "//XCUIElementTypeStaticText[@name='Re-enter your 6-digit pin to confirm.']";
	public Label iosElementlblReEnter6DigitPin=new Label(iosElementlblReEnter6DigitPinPath,LocatorType.XPATH);
	
	String iosElementbtnConfirmPath = "//XCUIElementTypeButton[@name='Confirm']";
	public Button iosElementbtnConfirm=new Button(iosElementbtnConfirmPath,LocatorType.XPATH);
	
	String iosElementlblSuccessPath = "//XCUIElementTypeStaticText[@name='Success']";
	public Label iosElementlblSuccess=new Label(iosElementlblSuccessPath,LocatorType.XPATH);
	
	String iosElementlblPinAuthPath = "//XCUIElementTypeStaticText[@name='PIN authentication has been successfully setup.']";
	public Label iosElementlblPinAuth=new Label(iosElementlblPinAuthPath,LocatorType.XPATH);
	
	String iosElementbtnDonePath = "//XCUIElementTypeButton[@name='Done']";
	public Button iosElementbtnDone=new Button(iosElementbtnDonePath,LocatorType.XPATH);

	String iosElementbtnLoginPinPath = "//XCUIElementTypeStaticText[@name='Login']";
	public Button iosElementbtnLoginPin=new Button(iosElementbtnLoginPinPath,LocatorType.XPATH);
	
	public Actions action = new Actions();
	
}
