package pageObject;

import ActionsFactory.ListActions;
import ActionsFactory.ValidateLabelUI;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Selenium.LocatorType;

public class PaymentInstructionsPage {
	
	String lblPaymentInstructionsPath = "//*[@id='mainContent']/h1";
	public Label lblPaymentInstructions= new Label(lblPaymentInstructionsPath,LocatorType.XPATH);
	
	String lblConfirmPaymentInstructionsPath = "//div[@id='mainContent']/h2";
	public Label lblConfirmPaymentInstructions= new Label(lblConfirmPaymentInstructionsPath,LocatorType.XPATH);
	
	String selAllHoldingPath = "//select[@id='ViewKey']";
	public ListActions lnkAllHoldingPath = new ListActions(selAllHoldingPath);
	public Select selAllHolding = new Select(selAllHoldingPath, LocatorType.XPATH);
	
	String lblViewPath = "//label[@for='ViewKey']";
	public Label lblView= new Label(lblViewPath,LocatorType.XPATH);
	
	String selCountryPath = "//select[@id='CountryCode']";
	public Select selCountry = new Select(selCountryPath, LocatorType.XPATH);
	
	String selPaymentTypePath = "//select[@id='PaymentMode']";
	public Select selPaymentType = new Select(selPaymentTypePath, LocatorType.XPATH);
	
	String txtSortCodePath = "//input[@id='SortCode']";
	public Input txtSortCode = new Input(txtSortCodePath, LocatorType.XPATH);
	
	String txtAccountNumberPath = "//input[@id='AccountNumber']";
	public Input txtAccountNumber = new Input(txtAccountNumberPath, LocatorType.XPATH);
	
	String txtBuildingSocietyRollNumberPath = "//input[@id='BuildingSocietyRollNumber']";
	public Input txtBuildingSocietyRollNumber = new Input(txtBuildingSocietyRollNumberPath, LocatorType.XPATH);
	
	
	String txtSwiftBICPath = "//input[@id='SwiftCode']";
	public Input txtSwiftBIC = new Input(txtSwiftBICPath, LocatorType.XPATH);
	
	String txtBankNamePath = "//input[@id='BankName']";
	public Input txtBankName = new Input(txtBankNamePath, LocatorType.XPATH);

	String txtBankAddressLine1Path = "//input[@id='BankAddressLine1']";
	public Input txtBankAddressLine1 = new Input(txtBankAddressLine1Path, LocatorType.XPATH);
	
	String txtBankAddressLine2Path = "//input[@id='BankAddressLine2']";
	public Input txtBankAddressLine2 = new Input(txtBankAddressLine2Path, LocatorType.XPATH);

	String txtCityPath = "//input[@id='City']";
	public Input txtCity = new Input(txtCityPath, LocatorType.XPATH);
	
	String txtPostCodePath = "//input[@id='PostCode']";
	public Input txtPostCode = new Input(txtPostCodePath, LocatorType.XPATH);
	
	String txtIBANPath = "//input[@id='Iban']";
	public Input txtIBAN = new Input(txtIBANPath, LocatorType.XPATH);
	
	String txtBankNumberPath = "//input[@id='BankNumber']";
	public Input txtBankNumber = new Input(txtBankNumberPath, LocatorType.XPATH);
	
	String txtBranchNumberPath = "//input[@id='BranchNumber']";
	public Input txtBranchNumber = new Input(txtBranchNumberPath, LocatorType.XPATH);
	
	String txtBankCodePath = "//input[@id='BankCode']";
	public Input txtBankCode = new Input(txtBankCodePath, LocatorType.XPATH);
	
	String txtIFSCCodePath = "//input[@id='Ifsc']";
	public Input txtIFSCCode = new Input(txtIFSCCodePath, LocatorType.XPATH);
	
	String chkIndividuallySelecttheHoldingsPath = "//div[@id='otherHoldings' and contains(@style,'margin-top: -20px; float: left; width: 700px;')]";
	public Button chkIndividuallySelecttheHoldings = new Button(chkIndividuallySelecttheHoldingsPath,LocatorType.XPATH); 
	
	String chkApplyThisUpdatePath = "//div[@id='otherHoldings' and contains(@style,'margin-top: -20px; float: left; width: 700px; display: none;')]";
	public Button chkApplyThisUpdate = new Button(chkApplyThisUpdatePath,LocatorType.XPATH); 

	String btnNextPath = "//button[@id='btnNext']";
	public Button btnNext = new Button(btnNextPath,LocatorType.XPATH); 
	
	String btnbackPath = "//button[@id='btnBack']";
	public Button btnback = new Button(btnbackPath,LocatorType.XPATH);
	
	String btnConfirmPath = "//*[@id='btnConfirm']";
	public Button btnConfirm = new Button(btnConfirmPath, LocatorType.XPATH);
	
	
	//IOS Elements
	String iosElementlblEditPath = "(//XCUIElementTypeStaticText[@name='Edit'])[1]";
	public Label iosElementlblEdit= new Label(iosElementlblEditPath, LocatorType.XPATH);
	public Button iosElementbtnEdit= new Button(iosElementlblEditPath, LocatorType.XPATH);
	
	String iosElementbtnUpdatePath = "//XCUIElementTypeButton[@name='Update']";
	public Button iosElementbtnUpdate= new Button(iosElementbtnUpdatePath, LocatorType.XPATH);
	
	String iosElementbtnSelectCountryPath = "(//XCUIElementTypeTextView)[2]";
	public Button iosElementbtnSelectCountry= new Button(iosElementbtnSelectCountryPath, LocatorType.XPATH);
	public Input iosElementtxtSelectCountry= new Input(iosElementbtnSelectCountryPath, LocatorType.XPATH);
	
	public Button iosElementPaymentInst= new Button();
	public Label iosElementValidatelabelPaymentInst= new Label();
	public Input iosElementHideKeyboard= new Input();
	public Actions action= new Actions();
	
	String iosElementtxtSelectIBANPath = "//XCUIElementTypeTextField[@value='IBAN']";
	public Input iosElementtxtSelectIBAN= new Input(iosElementtxtSelectIBANPath, LocatorType.XPATH);
	
	String iosElementtxtSelectBankNamePath = "//XCUIElementTypeTextField[@value='Bank Name']";
	public Input iosElementtxtSelectBankName= new Input(iosElementtxtSelectBankNamePath, LocatorType.XPATH);
	
	String iosElementtxtBankCodePath = "//XCUIElementTypeTextField[@value='Bank code']";
	public Input iosElementtxtBankCode= new Input(iosElementtxtBankCodePath, LocatorType.XPATH);

	String iosElementtxtBankNumberPath = "//XCUIElementTypeTextField[@value='Bank number']";
	public Input iosElementtxtBankNumber= new Input(iosElementtxtBankNumberPath, LocatorType.XPATH);
	
	String iosElementtxtBranchNumberPath = "//XCUIElementTypeTextField[@value='Branch number']";
	public Input iosElementtxtBranchNumber= new Input(iosElementtxtBranchNumberPath, LocatorType.XPATH);
	
	String iosElementtxtAddressLine1Path = "//XCUIElementTypeTextField[@value='Address line 1']";
	public Input iosElementtxtAddressLine1= new Input(iosElementtxtAddressLine1Path, LocatorType.XPATH);

	String iosElementtxtAddressLine2Path = "//XCUIElementTypeTextField[@value='Address line 2']";
	public Input iosElementtxtAddressLine2= new Input(iosElementtxtAddressLine2Path, LocatorType.XPATH);
	
	String iosElementtxtCityPath = "//XCUIElementTypeTextField[@value='City']";
	public Input iosElementtxtCity= new Input(iosElementtxtCityPath, LocatorType.XPATH);
	
	String iosElementtxtSWIFTBICPath = "//XCUIElementTypeTextField[@value='SWIFT/BIC']";
	public Input iosElementtxtSWIFTBIC= new Input(iosElementtxtSWIFTBICPath, LocatorType.XPATH);

	String iosElementtxtAccountnumberPath = "//XCUIElementTypeTextField[@value='Account number']";
	public Input iosElementtxtAccountnumber= new Input(iosElementtxtAccountnumberPath, LocatorType.XPATH);
	
	String iosElementtxtIFSCNumberPath = "//XCUIElementTypeTextField[@value='IFSC']";
	public Input iosElementtxtIFSCNumber= new Input(iosElementtxtIFSCNumberPath, LocatorType.XPATH);

	String iosElementtxtBankBranchCodePath = "//XCUIElementTypeTextField[@value='Bank/branch code']";
	public Input iosElementtxtBankBranchCode= new Input(iosElementtxtBankBranchCodePath, LocatorType.XPATH);
	
	String iosElementtxtABARoutingNumberCodePath = "//XCUIElementTypeTextField[@value='ABA Routing Number']";
	public Input iosElementtxtABARoutingNumberCode= new Input(iosElementtxtABARoutingNumberCodePath, LocatorType.XPATH);

	String iosElementtxtAccountNumberSuffixPath = "//XCUIElementTypeTextField[@value='Account number/suffix']";
	public Input iosElementtxtAccountNumberSuffix= new Input(iosElementtxtAccountNumberSuffixPath, LocatorType.XPATH);
	
	String iosElementtxtZipPostalCodePath = "//XCUIElementTypeTextField[@value='ZIP/Postcode/Eircode']";
	public Input iosElementtxtZipPostalCode= new Input(iosElementtxtZipPostalCodePath, LocatorType.XPATH);
	
	String iosElementtxtSortCodePath = "//XCUIElementTypeTextField[@value='Sort Code']";
	public Input iosElementtxtSortCode= new Input(iosElementtxtSortCodePath, LocatorType.XPATH);

	String iosElementtxtBuildingsocietyrollnumberPath = "//XCUIElementTypeTextField[@value='Building society roll number']";
	public Input iosElementtxtBuildingsocietyrollnumber = new Input(iosElementtxtBuildingsocietyrollnumberPath, LocatorType.XPATH);
	
	
		public Button iosElementSelectByTextValue= new Button();

		String iosElementToggleApplytoAllHoldingsPath = "(//XCUIElementTypeSwitch)[1]";

		public Button iosElementToggleApplytoAllHoldings = new Button(iosElementToggleApplytoAllHoldingsPath,LocatorType.XPATH);

		String iosElementToggleApplytoIndividualHoldingsPath = "(//XCUIElementTypeSwitch)[2]";

		public Button iosElementToggleApplytoIndividualHoldings = new Button(iosElementToggleApplytoIndividualHoldingsPath,LocatorType.XPATH);

	
}


