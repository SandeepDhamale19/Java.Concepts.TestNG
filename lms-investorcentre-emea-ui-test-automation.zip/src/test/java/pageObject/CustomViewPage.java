package pageObject;

import ActionsFactory.AlertsAction;
import ActionsFactory.ValidateLabelUI;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Selenium.LocatorType;

public class CustomViewPage {
	
	String lblCustomviewPath = "//*[@id='filterViewBar']/h1";
	public Label lblCustomview= new Label(lblCustomviewPath,LocatorType.XPATH);
	
	String selFilterTypePath = "//select[@id='FilterType']";
	public Select selFilterType = new Select(selFilterTypePath, LocatorType.XPATH);
	
	String txtViewNamePath = "//input[@id='FilterName']";
	public Input txtViewName = new Input(txtViewNamePath,LocatorType.XPATH);
	
	String btnDonePath = "//button[@id='btnDone']";
	public Button btnDone = new Button(btnDonePath,LocatorType.XPATH);
	
	String btnEditPath= "//a[@id='btnEditCustomFilter']";
	public Button btnEdit = new Button(btnEditPath,LocatorType.XPATH);
	
	String btnDeletePath = "//button[@id='btnDeleteCustomView']";
	public Button btnDelete = new Button(btnDeletePath,LocatorType.XPATH);
	
	
	
}
