package pageObject;

import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import Selenium.LocatorType;

public class HoldingSettingsPage {

	String androidElementSelPleaseSelectholder = "com.linkgroup.android_investorcentre.uat:id/edit_text";
	public Button androidElementdropdown = new Button(androidElementSelPleaseSelectholder, LocatorType.ID);

	String androidElementPleaseSelectholder = "com.linkgroup.android_investorcentre.uat:id/communication_method_label";
	public Button androidElementdropdownValue = new Button(androidElementPleaseSelectholder, LocatorType.ID);

	String androidElementViewbydropdownValue = "//android.widget.TextView[@text='Payment information']";
	public Button androidElementviewbydropdownValue = new Button(androidElementViewbydropdownValue, LocatorType.XPATH);

	String androidElementdropdownvalue = "com.linkgroup.android_investorcentre.uat:id/electronic_communications_container";
	public Button androidElementDropdownvalue = new Button(androidElementdropdownvalue, LocatorType.ID);

	String androidElementtxtEmailAddressPath = "com.linkgroup.android_investorcentre.uat:id/other_email";
	public Input androidElementtxtEmailAddress = new Input(androidElementtxtEmailAddressPath, LocatorType.ID);

	String androidElementcommunicationPreferenceButton = "com.linkgroup.android_investorcentre.uat:id/communication_preferences";
	public Button androidElementcommprefbutton = new Button(androidElementcommunicationPreferenceButton,
			LocatorType.ID);

	/*
	 * String androidElementholdingSetting =
	 * "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.TextView";
	 * public Button androidElementholdingsetting = new
	 * Button(androidElementholdingSetting, LocatorType.XPATH);
	 */

	String androidElementotherButton = "com.linkgroup.android_investorcentre.uat:id/other";
	public Button androidElementOtherButton = new Button(androidElementotherButton, LocatorType.ID);

	String androidElementnextButton = "com.linkgroup.android_investorcentre.uat:id/button";
	public Button androidElementNextButton = new Button(androidElementnextButton, LocatorType.ID);

	String androidElementconfirmButton = "//android.widget.Button[@text='Confirm']";
	public Button androidElementConfirmButton = new Button(androidElementconfirmButton, LocatorType.XPATH);

	String androidElementdoneButton = "//android.widget.Button[@text='Done']";
	public Button androidElementDoneButton = new Button(androidElementdoneButton, LocatorType.XPATH);

	String androidElementApplyallHoldingButton = "com.linkgroup.android_investorcentre.uat:id/apply_to_all";
	public Button androidElementApplyToallHolding = new Button(androidElementApplyallHoldingButton, LocatorType.ID);

	String androidElementApplyindividualHoldingButton = "com.linkgroup.android_investorcentre.uat:id/apply_to_individual_holding_toggle";
	public Button androidElementApplyToindividualHolding = new Button(androidElementApplyindividualHoldingButton,
			LocatorType.ID);

	String androidElementApplyindividualHoldingButtonUK = "com.linkgroup.android_investorcentre.uat:id/apply_to_individual_holding_toggle_uk";
	public Button androidElementApplyindividualHoldingButtonuk = new Button(
			androidElementApplyindividualHoldingButtonUK, LocatorType.ID);

	String androidElementclickheretoapplyButton = "com.linkgroup.android_investorcentre.uat:id/apply_to_individual_holding";
	public Button androidElementClickhereToApply = new Button(androidElementclickheretoapplyButton, LocatorType.ID);

	String androidElementclickheretoapplyButtonUK = "com.linkgroup.android_investorcentre.uat:id/apply_to_individual_holding_uk";
	public Button androidElementClickhereToApplyuk = new Button(androidElementclickheretoapplyButtonUK, LocatorType.ID);

	String androidElementapplyButton = "com.linkgroup.android_investorcentre.uat:id/button";
	public Button androidElementApplybutton = new Button(androidElementapplyButton, LocatorType.ID);

	String AndroidElementbtnAddressDetails = "com.linkgroup.android_investorcentre.uat:id/address_details";
	public Button AndroidElementbtnAddressdetails = new Button(AndroidElementbtnAddressDetails, LocatorType.ID);

	String AndroidElementRadiobtnwithinUK = "com.linkgroup.android_investorcentre.uat:id/location_within_uk_ireland";
	public Button AndroidElementRadioBtnwithinUK = new Button(AndroidElementRadiobtnwithinUK, LocatorType.ID);

	String AndroidElementRadiobtnoutsideUK = "com.linkgroup.android_investorcentre.uat:id/location_outside_uk_ireland";
	public Button AndroidElementRadioBtnOutsideUK = new Button(AndroidElementRadiobtnoutsideUK, LocatorType.ID);

	String AndroidlblStreet_Adress_Textbox1 = "com.linkgroup.android_investorcentre.uat:id/street_address";
	public Input AndroidlblStreetAdressTextbox1 = new Input(AndroidlblStreet_Adress_Textbox1, LocatorType.ID);

	String AndroidlblStreet_Adress_Textbox2 = "com.linkgroup.android_investorcentre.uat:id/street_address_2";
	public Input AndroidlblStreetAdressTextbox2 = new Input(AndroidlblStreet_Adress_Textbox2, LocatorType.ID);

	String AndroidlblStreet_Adress_Textbox3 = "com.linkgroup.android_investorcentre.uat:id/street_address_3";
	public Input AndroidlblStreetAdressTextbox3 = new Input(AndroidlblStreet_Adress_Textbox3, LocatorType.ID);

	String AndroidlblStreet_Adress_Textbox4 = "com.linkgroup.android_investorcentre.uat:id/street_address_4";
	public Input AndroidlblStreetAdressTextbox4 = new Input(AndroidlblStreet_Adress_Textbox4, LocatorType.ID);

	String AndroidlblStreet_Adress_Textbox5 = "com.linkgroup.android_investorcentre.uat:id/street_address_5";
	public Input AndroidlblStreetAdressTextbox5 = new Input(AndroidlblStreet_Adress_Textbox5, LocatorType.ID);

	String AndroidElementRadiobtnToggle = "com.linkgroup.android_investorcentre.uat:id/hin_srn_switch";
	public Button AndroidElementRadioBtnToggle = new Button(AndroidElementRadiobtnToggle, LocatorType.ID);

	String AndroidElementbtnPaymentInstruction = "com.linkgroup.android_investorcentre.uat:id/payment_instructions";
	public Button AndroidElementbtnpaymentInstruction = new Button(AndroidElementbtnPaymentInstruction, LocatorType.ID);

	String AndroidElementdropdownCountry = "(//android.widget.AutoCompleteTextView[@content-desc='View by'])[2]";
	public Button AndroidElementCountrydropdown = new Button(AndroidElementdropdownCountry, LocatorType.XPATH);

	String AndroidElementTextboxCountry = "(//android.widget.AutoCompleteTextView[@content-desc='View by'])[2]";
	public Input AndroidElementtextboxCountry = new Input(AndroidElementTextboxCountry, LocatorType.XPATH);

	String AndroidElementselectCountrygambia = "//android.widget.TextView[@text='Country']";
	public Button AndroidElementselectCountryGambia = new Button(AndroidElementselectCountrygambia, LocatorType.XPATH);

	String AndroidElementselectCountryireland = "//android.widget.TextView[@text='Changing our payment details here won't update your employer's records. If you wish to update them as well, please follow your HR process.']";
	public Button AndroidElementselectCountryIreland = new Button(AndroidElementselectCountryireland, LocatorType.XPATH);

	String AndroidElementdropdownPaymentType = "com.linkgroup.android_investorcentre.uat:id/text1";
	public Button AndroidElementdropdownpaymentType = new Button(AndroidElementdropdownPaymentType, LocatorType.ID);

	String AndroidElementselectPaymentType = "com.linkgroup.android_investorcentre.uat:id/text1";
	public Button AndroidElementSelectPaymentType = new Button(AndroidElementselectPaymentType, LocatorType.ID);

	String AndroidElementTextboxiban = "//android.widget.EditText[@content-desc='IBAN']";
	public Input AndroidElementTextboxIBAN = new Input(AndroidElementTextboxiban, LocatorType.XPATH);

	String AndroidElementTextboxbankName = "//android.widget.EditText[@content-desc='Bank Name']";
	public Input AndroidElementTextboxBankName = new Input(AndroidElementTextboxbankName, LocatorType.XPATH);

	String AndroidElementTextboxaddline1 = "//android.widget.EditText[@content-desc='Address line 1']";
	public Input AndroidElementTextboxAddline1 = new Input(AndroidElementTextboxaddline1, LocatorType.XPATH);

	String AndroidElementlblAddline1 = "//android.widget.TextView[@text='Address line 2']";
	public Button AndroidElementLebelAddline1 = new Button(AndroidElementlblAddline1, LocatorType.XPATH);

	String AndroidElementTextboxaddline2 = "//android.widget.EditText[@content-desc='Address line 2']";
	public Input AndroidElementTextboxAddline2 = new Input(AndroidElementTextboxaddline2, LocatorType.XPATH);

	String AndroidElementTextboxcity = "//android.widget.EditText[@content-desc='City']";
	public Input AndroidElementTextboxCity = new Input(AndroidElementTextboxcity, LocatorType.XPATH);

	String AndroidElementTextboxzip = "//android.widget.EditText[@content-desc='ZIP/Postcode/Eircode']";
	public Input AndroidElementTextboxZip = new Input(AndroidElementTextboxzip, LocatorType.XPATH);

	String AndroidElementTextboxSWIFT = "//android.widget.EditText[@content-desc='SWIFT/BIC']";
	public Input AndroidElementTextboxSwift = new Input(AndroidElementTextboxSWIFT, LocatorType.XPATH);

	String AndroidElementTextboxActno = "//android.widget.EditText[@content-desc='Account number']";
	public Input AndroidElementTextboxAccountno = new Input(AndroidElementTextboxActno, LocatorType.XPATH);

	String AndroidElementTextboxaccountno = "//android.widget.EditText[@content-desc='Account number/suffix']";
	public Input AndroidElementTextboxAccountnumber = new Input(AndroidElementTextboxaccountno, LocatorType.XPATH);

	String AndroidElementTextboxbankcode = "//android.widget.EditText[@content-desc='Bank code']";
	public Input AndroidElementTextboxBankcode = new Input(AndroidElementTextboxbankcode, LocatorType.XPATH);

	String AndroidElementTextboxbanknumber = "//android.widget.EditText[@content-desc='Bank number']";
	public Input AndroidElementTextboxBanknumber = new Input(AndroidElementTextboxbanknumber, LocatorType.XPATH);

	String AndroidElementTextboxbranchnumber = "//android.widget.EditText[@content-desc='Branch number']";
	public Input AndroidElementTextboxBranchnumber = new Input(AndroidElementTextboxbranchnumber, LocatorType.XPATH);

	String AndroidElementTextboxifsc = "//android.widget.EditText[@content-desc='IFSC']";
	public Input AndroidElementTextboxIFSC = new Input(AndroidElementTextboxifsc, LocatorType.XPATH);

	String AndroidElementTextboxbranchCode = "//android.widget.EditText[@content-desc='Bank/branch code']";
	public Input AndroidElementTextboxBranchCode = new Input(AndroidElementTextboxbranchCode, LocatorType.XPATH);

	String AndroidElementTextboxABARoutingNumber = "//android.widget.EditText[@content-desc='ABA Routing Number']";
	public Input AndroidElementTextboxABANumber = new Input(AndroidElementTextboxABARoutingNumber, LocatorType.XPATH);
	
	String AndroidElementTextboxsortcode = "//android.widget.EditText[@content-desc='Sort Code']";
	public Input AndroidElementTextboxSortcode = new Input(AndroidElementTextboxsortcode, LocatorType.XPATH);
	
	String AndroidElementTextboxrollno = "//android.widget.EditText[@content-desc='Building society roll number']";
	public Input AndroidElementTextboxRollno = new Input(AndroidElementTextboxrollno, LocatorType.XPATH);

	String AndroidElementBackbutton = "com.linkgroup.android_investorcentre.uat:id/back_btn";
	public Button AndroidElementBackButton = new Button(AndroidElementBackbutton, LocatorType.ID);

	String AndroidElementAcceptbutton = "//android.widget.Button[@text='Agree']";
	public Button AndroidElementAcceptCookiesbutton = new Button(AndroidElementAcceptbutton, LocatorType.XPATH);

	public Actions scroll = new Actions();

	public Actions scrolltoElement = new Actions();

}
