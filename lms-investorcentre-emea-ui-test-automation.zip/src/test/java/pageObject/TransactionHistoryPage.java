package pageObject;

import ActionsFactory.ListActions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Selenium.LocatorType;

public class TransactionHistoryPage {
	
	String txtDateFromPath = "//input[@id='DateFrom']";
	public Input txtDateFrom = new Input(txtDateFromPath,LocatorType.XPATH);
	
	String txtDateToPath = "//input[@id='DateTo']";
	public Input txtDateTo = new Input(txtDateToPath,LocatorType.XPATH);
	
	String btnGoPath = "//button[@id='btnGo']";
	public Button btnGo = new Button(btnGoPath,LocatorType.XPATH);

	String lblFilterFromPath = "//*[@id='filterDateFrom']";
	public Label lblFilterFrom = new Label(lblFilterFromPath, LocatorType.XPATH);  
	
	String lblFilterToPath = "//*[@id='filterDateTo']";
	public Label lblFilterTo = new Label(lblFilterToPath, LocatorType.XPATH);  

	
	String lblIVCColumnPath = "//table[@id='TransactionsHistoryGrid']/tbody/tr/td[1]";
	public ListActions lblIVCColumn = new ListActions(lblIVCColumnPath);
	
	String lblDateColumnPath = "//table[@id='TransactionsHistoryGrid']/tbody/tr/td[6]";
	public ListActions lblDateColumn = new ListActions(lblDateColumnPath); 
	
	String lblSecurityCodePath = "//table[@id='TransactionsHistoryGrid']/tbody/tr/td[3]";
	public ListActions lblSecurityCode = new ListActions(lblSecurityCodePath);
	
	String dropdownSecurityPath = "//*[@id='SecurityCode']";
	public Select dropdownSecurity = new Select(dropdownSecurityPath,LocatorType.XPATH);
	
	String lblTransactionDateFromPath = "//label[@for='DateFrom']";
	public Label lblTransactionDateFrom = new Label(lblTransactionDateFromPath,LocatorType.XPATH);

	String lblTransactionDateToPath = "//label[@for='DateTo']";
	public Label lblTransactionDateTo = new Label(lblTransactionDateToPath,LocatorType.XPATH);
	
	String lblDisplayTransactionHistoryPath = "//*[@id='transactionsHistoryForm']/h3";
	public Label lblDisplayTransactionHistory = new Label(lblDisplayTransactionHistoryPath,LocatorType.XPATH);
	
	String lblViewPath = "//label[@for='ViewKey']";
	public Label lblView= new Label(lblViewPath,LocatorType.XPATH);
	
}
