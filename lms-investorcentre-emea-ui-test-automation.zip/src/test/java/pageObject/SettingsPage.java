package pageObject;

import ActionsFactory.JavascriptExecutorfunction;
import ActionsFactory.ListActions;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import Selenium.LocatorType;

public class SettingsPage {
	
	String btnSettingsPath="//a[@id='settingsLink']";
	public Button btnSettings= new Button(btnSettingsPath, LocatorType.XPATH);
	
	String lblSettingsPath = "//div[@id='mainContent']/h1";
	public Label lblSettings = new Label(lblSettingsPath, LocatorType.XPATH);
	
	String btnCancelDeleteAccountPath="//button[@id=\"btnCancel\"]";
	public Button btnCancelDeleteAccount= new Button(btnCancelDeleteAccountPath, LocatorType.XPATH);
	
	String lblManageEmailLoginPath = "//form[@id='ChangeEmailForm']/h1";
	public Label lblManageEmailLogin = new Label(lblManageEmailLoginPath, LocatorType.XPATH);
	
	String lblChangePasswordFormPath = "//form[@id='ChangePasswordForm']/h1";
	public Label lblChangePasswordForm = new Label(lblChangePasswordFormPath, LocatorType.XPATH);

	String lblResetMFAFactorFormPath = "//form[@id='ResetMFAFactorForm']/div/h1";
	public Label lblResetMFAFactorForm = new Label(lblResetMFAFactorFormPath, LocatorType.XPATH);
	
	String lblDeleteAccountFormPath = "//form[@id='DeleteAccountForm']/div/h1";
	public Label lblDeleteAccountForm = new Label(lblDeleteAccountFormPath, LocatorType.XPATH);
	
	String lblChangeYourInvestorPath = "//*[@id='mainContent']/div/p";
	public Label lblChangeYourInvestor = new Label(lblChangeYourInvestorPath, LocatorType.XPATH);
	
	String btnManageEmailLoginPath = "//button[@id='btnChangeEmail']";
	public Button btnManageEmailLogin = new Button(btnManageEmailLoginPath, LocatorType.XPATH);
	
	String btnmanagePasswordPath = "//button[@id='btnChangePassword']";
	public Button btnmanagePassword = new Button(btnmanagePasswordPath, LocatorType.XPATH);

	String btnResetMFAFactorPath = "//button[@id='btnResetMFAFactor']";
	public Button btnResetMFAFactor = new Button(btnResetMFAFactorPath, LocatorType.XPATH);
	
	String btncancelButtonMFAPath = "//button[@id='btnCancel']";
	public Button btncancelButtonMFA = new Button(btncancelButtonMFAPath, LocatorType.XPATH);
	
	String btnDeleteAccountPath = "//button[@id='btnDeleteAccount']";
	public Button btnDeleteAccount = new Button(btnDeleteAccountPath, LocatorType.XPATH);
	
	String lblManageLoginPasswordPath ="//form[@id='ChangePasswordForm']/h1";
	public Label lblManageLoginPassword = new Label(lblManageLoginPasswordPath, LocatorType.XPATH);
	
	String lblChangePassordInstTextPath = "//form[@id='ChangePasswordForm']/div/p";
	public Label lblChangePassordInstText = new Label(lblChangePassordInstTextPath, LocatorType.XPATH);		
	
	String lblCurrentPasswordTextPath = "//label[@for='CurrentPassword']";
	public Label lblCurrentPasswordText = new Label(lblCurrentPasswordTextPath, LocatorType.XPATH);		
	
	String lblnewPasswordTextPath = "//label[@for='NewPassword']";
	public Label lblnewPasswordText = new Label(lblnewPasswordTextPath, LocatorType.XPATH);		
 
	String lblConfirmPasswordTextPath = "//label[@for='ConfirmPassword']";
	public Label lblConfirmPasswordText = new Label(lblConfirmPasswordTextPath, LocatorType.XPATH);		
	
	String btnDeletePath = "//button[@id='btnDelete']";
	public Button btnDelete = new Button(btnDeletePath, LocatorType.XPATH);
	
	String txtInputPasswordPath = "//input[@id='NewPassword']";
	public Input txtInputPassword= new Input(txtInputPasswordPath, LocatorType.XPATH);
	public Label lblInputPassword= new Label(txtInputPasswordPath, LocatorType.XPATH);
	public Actions actiontxtInputPassword = new Actions(txtInputPasswordPath, LocatorType.XPATH);
	
	String txtInputConfirmPasswordPath = "//input[@id='ConfirmPassword']";
	public Input txtInputConfirmPassword = new Input(txtInputConfirmPasswordPath, LocatorType.XPATH);
	public Label lblInputConfirmPassword= new Label(txtInputConfirmPasswordPath, LocatorType.XPATH);
	
	String txtInputCurrentPasswordPath = "//input[@id='CurrentPassword']";
	public Input txtInputCurrentPassword = new Input(txtInputCurrentPasswordPath, LocatorType.XPATH);
	public Label lblInputCurrentPassword= new Label(txtInputCurrentPasswordPath, LocatorType.XPATH);
	
	String lblstrongtextPath = "//span[@id='passwordstrengthText']";
	public Label lblstrongtext= new Label(lblstrongtextPath, LocatorType.XPATH);
	
	String lblPasswordMustContacinPath = "(//div[@id='divMandatoryValidations_NewPassword']/b)[2]";
	public Label lblPasswordMustContacin = new Label(lblPasswordMustContacinPath, LocatorType.XPATH);
	
	String btnClosePath = "//div[@id='cluetip-close']";
	public Button btnClose= new Button(btnClosePath, LocatorType.XPATH);
	
	
	//----
	String IconHelpLinkBesidesNewLoginPath = "//div[@class='helpLink']";
	public Button IconHelpLinkBesidesNewLogin= new Button(IconHelpLinkBesidesNewLoginPath, LocatorType.XPATH);
	
	String IconAtLeast10CharactersPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/error.gif'])[6]";
	public Button IconAtLeast10Characters = new Button(IconAtLeast10CharactersPath, LocatorType.XPATH);
		
	String IconAtLeastOneUpperCasePath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/error.gif'])[7]";
	public Button IconAtLeastOneUpperCase = new Button(IconAtLeastOneUpperCasePath, LocatorType.XPATH);
	
	String IconAtLeastOneLowerCasePath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/error.gif'])[8]";
	public Button IconAtLeastOneLowerCase = new Button(IconAtLeastOneLowerCasePath, LocatorType.XPATH);

	String IconAtLeastOneDigitPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/error.gif'])[9]";
	public Button IconAtLeastOneDigit = new Button(IconAtLeastOneDigitPath, LocatorType.XPATH);

	String IconAtLeastOneSpecialCharactersPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/error.gif'])[10]";
	public Button IconAtLeastOneSpecialCharacters = new Button(IconAtLeastOneSpecialCharactersPath, LocatorType.XPATH);
	
	String IconMustNotContainpartofUserNamePath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/help.gif'])[5]";
	public Button IconMustNotContainpartofUserName = new Button(IconMustNotContainpartofUserNamePath, LocatorType.XPATH);
	
	String IconMustNotContainFirst_LastNamePath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/help.gif'])[6]";
	public Button IconMustNotContainFirst_LastName = new Button(IconMustNotContainFirst_LastNamePath, LocatorType.XPATH);
	
	String IconYourPrevious4PasswordsCannotBeUsedPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/help.gif'])[7]";
	public Button IconYourPrevious4PasswordsCannotBeUsed = new Button(IconYourPrevious4PasswordsCannotBeUsedPath, LocatorType.XPATH);
	
	String IconMustNotcontaincommonwordsPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/help.gif'])[8]";
	public Button IconMustNotcontaincommonwords = new Button(IconMustNotcontaincommonwordsPath, LocatorType.XPATH);
	
	//------
	String lblAtLeast10CharactersPath = "(//label[@class='password-rule-label'])[10]";
	public Label lblAtLeast10Characters = new Label(lblAtLeast10CharactersPath, LocatorType.XPATH);

	String lblAtLeastOneUpperCasePath = "(//label[@class='password-rule-label'])[11]";
	public Label lblAtLeastOneUpperCase = new Label(lblAtLeastOneUpperCasePath, LocatorType.XPATH);

	String lblAtLeastOneLowerCasePath = "(//label[@class='password-rule-label'])[12]";
	public Label lblAtLeastOneLowerCase = new Label(lblAtLeastOneLowerCasePath, LocatorType.XPATH);

	String lblAtLeastOneDigitPath = "(//label[@class='password-rule-label'])[13]";
	public Label lblAtLeastOneDigit = new Label(lblAtLeastOneDigitPath, LocatorType.XPATH);

	String lblAtLeastOneSpecialCharactersPath = "(//label[@class='password-rule-label'])[14]";
	public Label lblAtLeastOneSpecialCharacters = new Label(lblAtLeastOneSpecialCharactersPath, LocatorType.XPATH);

	String lblMustNotContainpartofUserNamePath = "(//label[@class='password-rule-label'])[15]";
	public Label lblMustNotContainpartofUserName = new Label(lblMustNotContainpartofUserNamePath, LocatorType.XPATH);

	String lblMustNotContainFirst_LastNamePath = "(//label[@class='password-rule-label'])[16]";
	public Label lblMustNotContainFirst_LastName = new Label(lblMustNotContainFirst_LastNamePath, LocatorType.XPATH);

	String lblYourPrevious4PasswordsCannotBeUsedPath = "(//label[@class='password-rule-label'])[17]";
	public Label lblYourPrevious4PasswordsCannotBeUsed = new Label(lblYourPrevious4PasswordsCannotBeUsedPath, LocatorType.XPATH);

	String lblMustNotcontaincommonwordsPath = "(//label[@class='password-rule-label'])[18]";
	public Label lblMustNotcontaincommonwords = new Label(lblMustNotcontaincommonwordsPath, LocatorType.XPATH);

	//----------------------------------------------------------------
	
	String IconGreenAtLeast10CharactersPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/ok.gif'])[6]";
	public Button IconGreenAtLeast10Characters = new Button(IconGreenAtLeast10CharactersPath, LocatorType.XPATH);
		
	String IconGreenAtLeastOneUpperCasePath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/ok.gif'])[7]";
	public Button IconGreenAtLeastOneUpperCase = new Button(IconGreenAtLeastOneUpperCasePath, LocatorType.XPATH);
	
	String IconGreenAtLeastOneLowerCasePath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/ok.gif'])[8]";
	public Button IconGreenAtLeastOneLowerCase = new Button(IconGreenAtLeastOneLowerCasePath, LocatorType.XPATH);

	String IconGreenAtLeastOneDigitPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/ok.gif'])[9]";
	public Button IconGreenAtLeastOneDigit = new Button(IconGreenAtLeastOneDigitPath, LocatorType.XPATH);

	String IconGreenAtLeastOneSpecialCharactersPath = "(//label[@class='password-rule-label']//preceding::img[@src='/images/icons/ok.gif'])[10]";
	public Button IconGreenAtLeastOneSpecialCharacters = new Button(IconGreenAtLeastOneSpecialCharactersPath, LocatorType.XPATH);
	
	
	String validtemaskedPasswordPath =   "//input[@id='NewPassword']";
	public Label validtemaskedPassword = new Label(validtemaskedPasswordPath, LocatorType.XPATH);
	
	String btnbackButtonPath = "//button[@id=\"btnBack\"]";
	public Button btnbackButton = new Button(btnbackButtonPath,LocatorType.XPATH);
	
	String btncancelPath = "//button[@id='btnCancelManageEmail']";
	public Button btncancel = new Button(btncancelPath,LocatorType.XPATH);
	
	String btnChangePath = "//button[@id='btnChange']";
	public Button btnChange = new Button(btnChangePath,LocatorType.XPATH); 
	
	String lblErrorMessageCurrentPwdPath =   "//label[@for='CurrentPassword' and @class='error']";
	public Label lblErrorMessageCurrentPwd = new Label(lblErrorMessageCurrentPwdPath, LocatorType.XPATH);
	
	String lblErrorMessageNewPwdPath =   "//label[@for='NewPassword' and @class='error']";
	public Label lblErrorMessageNewPwd = new Label(lblErrorMessageNewPwdPath, LocatorType.XPATH);
	
	String lblDeleteAccountInstructionText1Path = "(//div[@id='deleteAccountLoad']/p)[1]";
	public Label lblDeleteAccountInstructionText1 = new Label(lblDeleteAccountInstructionText1Path, LocatorType.XPATH);
	
	String lblDeleteAccountInstructionText2Path = "(//div[@id='deleteAccountLoad']/p)[2]";
	public Label lblDeleteAccountInstructionText2 = new Label(lblDeleteAccountInstructionText2Path, LocatorType.XPATH);

	
	String lblDeleteAccountInstructionText3Path = "(//div[@id='deleteAccountLoad']/p)[3]";
	public Label lblDeleteAccountInstructionText3 = new Label(lblDeleteAccountInstructionText3Path, LocatorType.XPATH);
	
	String lblDeleteAccountInstructionText4Path = "(//div[@id='deleteAccountLoad']/p)[4]";
	public Label lblDeleteAccountInstructionText4 = new Label(lblDeleteAccountInstructionText4Path, LocatorType.XPATH);
	
	public Label lblAddHoldingInstructionslText;
	String lblAddHoldingInstructionslTextPath;
	
	public String getLablelInstructionsText() {
		lblAddHoldingInstructionslTextPath = "//*[@id='mainBody']/div[1]/div/p";
		lblAddHoldingInstructionslText = new Label(lblAddHoldingInstructionslTextPath, LocatorType.XPATH);
		   java.util.Scanner scanner = new java.util.Scanner(lblAddHoldingInstructionslText.getTextlabel());
			  StringBuffer sb = new StringBuffer();
				while (scanner.hasNextLine()) {
				  sb.append(scanner.nextLine());
				}
		return sb.toString();
	}

}
