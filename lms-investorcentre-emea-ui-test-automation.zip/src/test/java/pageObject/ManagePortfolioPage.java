package pageObject;

import ActionsFactory.ValidateLabelUI;
import ElementsFactory.Button;
import ElementsFactory.Label;
import Selenium.LocatorType;

public class ManagePortfolioPage {
	
	String lblManagePortfolioPath = "//*[@id='mainContent']/div/h1";
	public ValidateLabelUI lblManagePortfolio= new ValidateLabelUI(lblManagePortfolioPath,LocatorType.XPATH);
	
	String btnRemovePath = "//table[@id='PortfolioGrid']/tbody/tr/td/a[text()='Remove']";
	public Button btnRemove = new Button(btnRemovePath, LocatorType.XPATH); 
	
	String btnConfirmPath = "//*[@id='btnConfirm']";
	public Button btnConfirm = new Button(btnConfirmPath, LocatorType.XPATH);
	
	String lblSuccessMsgPath = "//*[@id='mainContent']/div/h2";
	public Label lblSuccessMessage = new Label(lblSuccessMsgPath, LocatorType.XPATH);  
	
	String btnBackToPortfolioPath = "//*[@id='btnBackToPortfolio']";
	public Button btnBackToPortfolio = new Button(btnBackToPortfolioPath, LocatorType.XPATH);
	
	String lblViewPath = "//label[@for='ViewKey']";
	public Label lblView= new Label(lblViewPath,LocatorType.XPATH);
	
	String lblInstructionalText1Path = "(//*[@id=\"mainContent\"]/div/p)[1]";
	public Label lblInstructionalText1 = new Label(lblInstructionalText1Path,LocatorType.XPATH);
	
	String lblInstructionalText2Path = "(//*[@id=\"mainContent\"]/div/p)[2]";
	public Label lblInstructionalText2 = new Label(lblInstructionalText2Path,LocatorType.XPATH);
	
	String lblInstructionalText3Path = "(//*[@id=\"mainContent\"]/div/p)[3]";
	public Label lblInstructionalText3 = new Label(lblInstructionalText3Path,LocatorType.XPATH);
	
	String lblInstructionalText4Path = "//form[@id='ConfirmEditPortfolioForm']/h2";
	public Label lblInstructionalText4 = new Label(lblInstructionalText4Path,LocatorType.XPATH);
	
	String lblIVCPath = "//*[@id='ConfirmEditPortfolioForm']/table/tbody/tr[1]/th[1]";
	public Label lblIVC = new Label(lblIVCPath,LocatorType.XPATH);
	
	String lblPegisteredHoldingpathPath = "//*[@id='ConfirmEditPortfolioForm']/table/tbody/tr[2]/th[1]";
	public Label lblPegisteredHolding = new Label(lblPegisteredHoldingpathPath,LocatorType.XPATH);

	String lblIVCValuePath = "//*[@id='ConfirmEditPortfolioForm']/table/tbody/tr[1]/td[1]";
	public Label lblIVCvalue = new Label(lblIVCValuePath,LocatorType.XPATH);
	
	String lblPegisteredHoldingvaluePath = "//*[@id='ConfirmEditPortfolioForm']/table/tbody/tr[2]/td[1]";
	public Label lblPegisteredHoldingvalue = new Label(lblPegisteredHoldingvaluePath,LocatorType.XPATH);
	
	String lblInstractionPath = "//*[@id='ConfirmEditPortfolioForm']/p";
	public Label lblInstraction = new Label(lblInstractionPath,LocatorType.XPATH);

	String btnCancelPathe = "//button[@id='btnCancel']";
	public Button btnCancel = new Button(btnCancelPathe, LocatorType.XPATH);
	
}
