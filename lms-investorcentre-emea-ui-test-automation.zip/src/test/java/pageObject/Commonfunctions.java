package pageObject;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;

import com.google.common.collect.ImmutableList;

import DriverFactory.ThreadLocalAndroidDriver;


public class Commonfunctions {
	
	Date date = new Date();
    DateFormat dateFormat = new SimpleDateFormat("HH_mm_ss");
	String fileName = dateFormat.format(date).toString();
	File screenShot = new File ("\\adcfs.capita.co.uk\\Public\\LMS\\GlobalBeckenham\\UK_LIC_Automation\\LIC_ScreenShots\\"+fileName+".png");

	public  String generateRandomAlphaString(int count) {
		final String ALPHA_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_STRING.length());
			builder.append(ALPHA_STRING.charAt(character));
		}
		return builder.toString();
	}

	public  String generateRandomNumericString(int count) {
		final String ALPHA_STRING = "1234567890";
		StringBuilder builder = new StringBuilder();
		String randomNumberString;
		int temp = count;
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_STRING.length());
			builder.append(ALPHA_STRING.charAt(character));
		}
 
		randomNumberString = builder.toString();
		System.out.println(randomNumberString);
		if (Long.parseLong(randomNumberString) == 0)
			randomNumberString = generateRandomNumericString(temp);
 
		return randomNumberString;
	}

	
	public void ScrollDownPartial() {

		Dimension size = ThreadLocalAndroidDriver.getDriver().manage().window().getSize();

		System.out.println("Size"+size);

		Point midPoint = new Point((int)(size.width*0.5),(int)(size.height*0.5)); 

		int bottom=midPoint.y + (int)(midPoint.y*0.10);

		int top=midPoint.y - (int)(midPoint.y*0.10);

		Point start = new Point(midPoint.x,bottom);

		Point end = new Point(midPoint.x,top);

		PointerInput indexFinger = new PointerInput(PointerInput.Kind.TOUCH, "finger");

		Sequence scroll = new Sequence(indexFinger, 0);

		scroll.addAction(indexFinger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), start.x, start.y));

		scroll.addAction(indexFinger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));

		scroll.addAction(indexFinger.createPointerMove(Duration.ofMillis(50), PointerInput.Origin.viewport(), end.x, end.y));

		scroll.addAction(indexFinger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

		ThreadLocalAndroidDriver.getDriver().perform(ImmutableList.of(scroll));

	}
	
	public  boolean validateDateFormat(String date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date jdate = sdf.parse(date);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
 
	public  boolean validateTimeFormat(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
		try {
			Date ti = sdf.parse(time);
			return true;
		} catch (Exception e) {
			return false;
		}
}
	
}
