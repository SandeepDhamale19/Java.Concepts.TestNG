package pageObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.github.javafaker.Faker;

import ActionsFactory.ListActions;
import ActionsFactory.ValidateLabelUI;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Hardwait.Hardwait;
import Selenium.LocatorType;

public class AddressDetailsPage {
	
	String lblAddressUpdatePath = "//*[@id=\"mainContent\"]/h1";
	public Label lblAddressUpdate= new Label(lblAddressUpdatePath,LocatorType.XPATH);
	
	String selCountryPath = "//select[@id=\"Country\"]";
	public Select selCountry = new Select(selCountryPath, LocatorType.XPATH);
	
	String  txtAddressLine1Path = "//*[@id='AddressLine1']";
	public Input txtAddressLine1 = new Input(txtAddressLine1Path, LocatorType.XPATH);

	String  txtAddressLine2Path = "//*[@id='AddressLine2']";
	public Input txtAddressLine2 = new Input(txtAddressLine2Path, LocatorType.XPATH);

	String  txtAddressLine3Path = "//*[@id='AddressLine3']";
	public Input txtAddressLine3 = new Input(txtAddressLine3Path, LocatorType.XPATH);

	String  txtAddressLine4Path = "//*[@id='AddressLine4']";
	public Input txtAddressLine4 = new Input(txtAddressLine4Path, LocatorType.XPATH);

	String  txtAddressLine5Path = "//*[@id='AddressLine5']";
	public Input txtAddressLine5 = new Input(txtAddressLine5Path, LocatorType.XPATH);

	String  txtPostCodePath = "//*[@id='Postcode']";
	public Input txtPostCode = new Input(txtPostCodePath, LocatorType.XPATH);
	
	String btnselectotherholdingstoapplythisupdatetoPath = "//input[@id='IsShowOtherHoldings' and @type='checkbox']";
	public Button btnselectotherholdingstoapplythisupdateto = new Button(btnselectotherholdingstoapplythisupdatetoPath, LocatorType.XPATH);
	
	
	
	String lblselectotherholdingstoapplythisupdatetoPath = "//label[@for='IsShowOtherHoldings']";
	public Label lblselectotherholdingstoapplythisupdateto = new Label(lblselectotherholdingstoapplythisupdatetoPath, LocatorType.XPATH);

	
	String btnselectAllPath = "//button[@id='btnSelectall']";
	public Button btnselectAll = new Button(btnselectAllPath, LocatorType.XPATH);
	
	String btnOutSideUKPath = "//span[@id='spanOutsideUk']";
	public Button btnOutSideUK = new Button(btnOutSideUKPath, LocatorType.XPATH);

	
	String btnApplyToAllHoldings_1Path = "//input[@id='ApplyToAllHoldings_1']";
	public Button btnApplyToAllHoldings_1 = new Button(btnApplyToAllHoldings_1Path, LocatorType.XPATH);
	
	String lblApplyToAllHoldings_1Path = "//label[@for='ApplyToAllHoldings_1']";
	public Label lblApplyToAllHoldings_1 = new Label(lblApplyToAllHoldings_1Path, LocatorType.XPATH);
	
	String rbApplyToAllHoldings_1Path = "//input[@id='ApplyToAllHoldings_1' and @value='true']";
	public Button rbApplyToAllHoldings_1 = new Button(rbApplyToAllHoldings_1Path, LocatorType.XPATH);
	
	String rbApplyToAllHoldings_2Path = "//input[@id='ApplyToAllHoldings_2' and @value='true']";
	public Button rbApplyToAllHoldings_2 = new Button(rbApplyToAllHoldings_2Path, LocatorType.XPATH);
	
	String btnselectIndividuallyselecttheholdingsPath = "//input[@id='ApplyToAllHoldings_2']";
	public Button btnselectIndividuallyselecttheholdings = new Button(btnselectIndividuallyselecttheholdingsPath, LocatorType.XPATH);

	String lblselectIndividuallyselecttheholdingsPath = "//label[@for='ApplyToAllHoldings_2']";
	public Label lblselectIndividuallyselecttheholdings = new Label(lblselectIndividuallyselecttheholdingsPath, LocatorType.XPATH);
	
	
	String btnUpdatePath = "//button[@id='btnUpdate']";
	public Button btnUpdate = new Button(btnUpdatePath, LocatorType.XPATH);
	
	String lblAddressDetailsPath = "//table[@aria-describedby='Address']/tbody/tr[1]/td";
	public Label lblAddressDetails = new Label(lblAddressDetailsPath, LocatorType.XPATH);
	
	String btnConfirmPath = "//button[@id='btnConfirm']";
	public Button btnConfirm = new Button(btnConfirmPath, LocatorType.XPATH);

	String lblAddressUpdateSuccessMessagePath = "//*[@id='addressComplete']/h2";
	public Label lblAddressUpdateSuccessMessage = new Label(lblAddressUpdateSuccessMessagePath, LocatorType.XPATH);
	
	
	String lblEnterAddressDetailsPath = "//div[@id=\"divMainControls\"]/h2";
	public Label lblEnterAddressDetails = new Label(lblEnterAddressDetailsPath, LocatorType.XPATH);
	
	String lblStreetAdtressPath = "//label[@for='AddressLine1']";
	public Label lblStreetAdtress = new Label(lblStreetAdtressPath, LocatorType.XPATH);
	
	String lblPOstCodePath = "//label[@for='Postcode']";
	public Label lblPOstCode = new Label(lblPOstCodePath, LocatorType.XPATH);
	
	String btnSelectallPath = "//button[@id='btnSelectall']";
	public Button btnSelectall = new Button(btnSelectallPath, LocatorType.XPATH);

	String btnDeSelectallPath = "//button[@id='btnUnselectall']";
	public Button btnDeSelectall = new Button(btnDeSelectallPath, LocatorType.XPATH);
	
	
	String lblColHeaderPath = "//div[@id='jqgh_IVC']";
	public Label lblColHeader = new Label(lblColHeaderPath,LocatorType.XPATH);

	String lblRegistrationDetailsPath = "(//div[@id='jqgh_Registration Details'])[1]";
	public Label lblRegistrationDetails = new Label(lblRegistrationDetailsPath,LocatorType.XPATH);

	String lblIssuerPath = "//th[@id='ApplyHoldingsGrid_Issuer']";
	public Label lblIssuer = new Label(lblIssuerPath,LocatorType.XPATH);

	String lblCurrentAddressPath = "//th[@id='ApplyHoldingsGrid_Current Address']";
	public Label lblCurrentAddress = new Label(lblCurrentAddressPath,LocatorType.XPATH);

	String lblUpdatePath = "//div[@id='jqgh_Update']";
	public Label lblUpdate = new Label(lblUpdatePath,LocatorType.XPATH);
	
	String listIVCPath = "//table[@class='resizeGrid ui-jqgrid-btable']/tr/td[1]";
	public ListActions listIVC = new ListActions(listIVCPath);

	String listRegistrationDetailsPath = "//table[@class='resizeGrid ui-jqgrid-btable']/tr/td[1]";
	public ListActions listRegistrationDetails = new ListActions(listRegistrationDetailsPath);

	
	String listIssuerPath = "//table[@class='resizeGrid ui-jqgrid-btable']/tr/td[1]";
	public ListActions listIssuer  = new ListActions(listIssuerPath);

	String listCurrentAddressPath = "//table[@class='resizeGrid ui-jqgrid-btable']/tr/td[1]";
	public ListActions listCurrentAddress  = new ListActions(listCurrentAddressPath);

	String listUpdatePath = "//table[@class='resizeGrid ui-jqgrid-btable']/tr/td[1]";
	public ListActions listUpdate  = new ListActions(listUpdatePath);
	
	
	String lblConfirmAddressPath = "//div[@id='mainContent']/h1";
	public Label lblConfirmAddress = new Label(lblConfirmAddressPath,LocatorType.XPATH);

	String lblAddressUpdateCompletePath = "//div[@class='addressCompleteView']/h1";
	public Label lblAddressUpdateComplete = new Label(lblAddressUpdateCompletePath,LocatorType.XPATH);
	
	String lblInstructionalTextPath = "//*[@id='addressComplete']/div/p";
	public Label lblInstructionalText = new Label(lblInstructionalTextPath,LocatorType.XPATH);
	
	public static ArrayList<String> array_address_Data = null; 
	
	
	public void InputAddressDetails(List<Map<String,String>> addressDetails) {
		array_address_Data=null;
		array_address_Data = new ArrayList<String>();
		for(Map<String, String> address:addressDetails) {
			System.out.println(address.get("InputKey")+":"+address.get("InputValues"));
			
			String key = address.get("InputKey");
			String value = address.get("InputValues");
			
			Hardwait.staticWait(3000);
			Faker faker = new Faker();
			switch (key) {
				case "Street Address Line1":
					String AddressLine1 = faker.name().fullName().replaceAll("[^a-zA-Z0-9]", "");
					txtAddressLine1.ClearInputvalues();
					txtAddressLine1.Inputvalues(AddressLine1);
					ExtentCucumberAdapter.addTestStepLog("Address Line 1 "+AddressLine1);
					array_address_Data.add(AddressLine1);
					break;
				case "Street Address Line2":
					String AddressLine2 = faker.address().streetName();
					txtAddressLine2.ClearInputvalues();
					txtAddressLine2.Inputvalues(AddressLine2);
					ExtentCucumberAdapter.addTestStepLog("Address Line 2 "+AddressLine2);
					array_address_Data.add(AddressLine2);
					break;
				case "Street Address Line3":
					String AddressLine3 = faker.address().streetAddress();
					txtAddressLine3.ClearInputvalues();
					txtAddressLine3.Inputvalues(AddressLine3);
					ExtentCucumberAdapter.addTestStepLog("Address Line 3 "+AddressLine3);
					array_address_Data.add(AddressLine3);
					break;
				case "Street Address Line4":
					String AddressLine4 = faker.address().cityName();
					txtAddressLine4.ClearInputvalues();
					txtAddressLine4.Inputvalues(AddressLine4);
					ExtentCucumberAdapter.addTestStepLog("Address Line 4 "+AddressLine4);
					array_address_Data.add(AddressLine4);
					break;
				case "Street Address Line5":
					String AddressLine5 = faker.address().city();
					txtAddressLine5.ClearInputvalues();
					txtAddressLine5.Inputvalues(AddressLine5);
					ExtentCucumberAdapter.addTestStepLog("Address Line 5 "+AddressLine5);
					array_address_Data.add(AddressLine5);
					break;
				case "PostCode":
					if (value.equals("clear")) {
						txtPostCode.ClearInputvalues();
					}else {
						ArrayList<String> arr_postalCode = new ArrayList<String>();
						arr_postalCode.add("PP13 0EJ");
						arr_postalCode.add("GG7 5BT");
						arr_postalCode.add("AA1 9JB");
						arr_postalCode.add("EE5 5EU");
						Collections.shuffle(arr_postalCode);
						String postalcode = arr_postalCode.stream().findAny().orElse(null);
						txtPostCode.ClearInputvalues();
						txtPostCode.Inputvalues(postalcode);
						ExtentCucumberAdapter.addTestStepLog("Postal Code "+postalcode);
						array_address_Data.add(postalcode);
					}
					break;
				case "Select other holdings to apply this update to":
					if (value.equalsIgnoreCase("yes")) {
						btnselectotherholdingstoapplythisupdateto.Click();
					}
					break;
				case "Individually select the holdings to apply this update to":
					if (value.equalsIgnoreCase("yes")) {
						btnselectIndividuallyselecttheholdings.Click();
					}
					break;
				case "Update CheckBox":
					if (value.equalsIgnoreCase("yes")) {
						btnselectAll.Click();
					}
					break;
				case "OutsideUk":
					if (value.equalsIgnoreCase("yes")) {
						btnOutSideUK.Click();
					}
					break;		
				case "update":
					if (value.equalsIgnoreCase("yes")) {
						btnUpdate.Click();
					}
					break;		
				default:
					break;
			}
		}
	}
	
	
	public void ValidateAddressDetails(List<Map<String,String>> addressDetails) {
		for(Map<String, String> address:addressDetails) {
			String key = address.get("InputKey");
			Hardwait.staticWait(5000);
			switch (key) {
				case "Street Address Line1":
						String _ReplicatedText1 = txtAddressLine1.getInputText();
						String _InputText1 = array_address_Data.get(0).toUpperCase();
						ExtentCucumberAdapter.addTestStepLog("Replicated Test Address Line 1 "+_ReplicatedText1 +"Input Text "+_InputText1);
						Assert.assertEquals(_ReplicatedText1, _InputText1);
					break;
				case "Street Address Line2":
						String _ReplicatedText2 = txtAddressLine2.getInputText();
						String _InputText2 = array_address_Data.get(1).toUpperCase();
						ExtentCucumberAdapter.addTestStepLog("Replicated Test Address Line 2 "+_ReplicatedText2 +"Input Text "+_InputText2);
						Assert.assertEquals(_ReplicatedText2, _InputText2);
					break;
				case "Street Address Line3":
						String _ReplicatedText3 = txtAddressLine3.getInputText();
						String _InputText3 = array_address_Data.get(2).toUpperCase();
						ExtentCucumberAdapter.addTestStepLog("Replicated Test Address Line 3 "+_ReplicatedText3 +"Input Text "+_InputText3);
						Assert.assertEquals(_ReplicatedText3, _InputText3);
					break;
				case "Street Address Line4":
						String _ReplicatedText4 = txtAddressLine4.getInputText();
						String _InputText4 = array_address_Data.get(3).toUpperCase();
						ExtentCucumberAdapter.addTestStepLog("Replicated Test Address Line 4 "+_ReplicatedText4 +"Input Text "+_InputText4);
						Assert.assertEquals(_ReplicatedText4, _InputText4);
					break;
				case "Street Address Line5":
						String _ReplicatedText5 = txtAddressLine5.getInputText();
						String _InputText5 = array_address_Data.get(4).toUpperCase();
						ExtentCucumberAdapter.addTestStepLog("Replicated Test Address Line 5 "+_ReplicatedText5 +"Input Text "+_InputText5);
						Assert.assertEquals(_ReplicatedText5, _InputText5);
					break;
				case "PostCode":
					String _ReplicatedText6 = txtPostCode.getInputText();
					String _InputText6 = array_address_Data.get(5).toUpperCase();
					ExtentCucumberAdapter.addTestStepLog("Replicated Test Address Line 5 "+_ReplicatedText6 +"Input Text "+_InputText6);
					Assert.assertEquals(_ReplicatedText6, _InputText6);
					break;
				default:
					break;
			}
		}
	}
	
	public void ValdiateAddressDetails() {
		Hardwait.staticWait(5000);
		String addDetailsTxt = lblAddressDetails.getTextlabel();
		
		java.util.Scanner scanner = new java.util.Scanner(addDetailsTxt);
		ArrayList<String> array_address_UI=new ArrayList<String>();
		while (scanner.hasNextLine()) {
		  String line = scanner.nextLine();
		  System.out.println(line);
		  array_address_UI.add(line);
		}

		System.out.println("array_address_Data :"+array_address_Data);
		System.out.println("array_address_UI :"+array_address_UI);
		if (array_address_Data.equals(array_address_UI)) {
			ExtentCucumberAdapter.addTestStepLog("Address Details are Matching with Confirm Update Address Screen!! " +array_address_Data);
		}else {
			ExtentCucumberAdapter.addTestStepLog("Address Details are NOT Matching with Confirm Update Address Screen!! "+array_address_Data);
			Assert.fail("Address Details are NOT Matching with Confirm Update Address Screen!!");
		}
	}
	
}


