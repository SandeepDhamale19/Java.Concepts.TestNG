package pageObject;

import ActionsFactory.JavascriptExecutorfunction;
import ActionsFactory.ListActions;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Selenium.LocatorType;

public class DripPage {

	String tabPaymentPath = "//*[text()='Payments']";
	public Actions tabPayment = new Actions(tabPaymentPath, LocatorType.XPATH);
	
	String tabDividendReinvestmentPath = "//*[text()='Dividend Reinvestment']";
	public Button tabDividendReinvestment = new Button(tabDividendReinvestmentPath, LocatorType.XPATH);
	
	String lblheaderPath = "//h1";
	public Button lblheader= new Button(lblheaderPath,LocatorType.XPATH);
	
	String lblDRIPPath = "//td//span[@title='DRIP']";
	public ListActions lblDRIP = new ListActions(lblDRIPPath); 
	
	String lblSCRIPPath = "//td//span[@title='SCRIP']";
	public ListActions lblSCRIP = new ListActions(lblSCRIPPath); 
	
	String lblbalancePath = "//table//tr//td[8]";
	public ListActions lblbalance = new ListActions(lblbalancePath); 
	
	String lblreinvestdevidentPath = "//td//span[@title='Reinvest Dividend']";
	public ListActions lblreinvestdevident = new ListActions(lblreinvestdevidentPath); 
	
	String lbldonotreinvestPath = "//td//span[@title='Do Not Reinvest']";
	public ListActions lbldonotreinvest = new ListActions(lbldonotreinvestPath); 
	
	String lblterminateinstructionPath = "//a[contains(text(),'Terminate')]";
	public ListActions lblterminateinstruction = new ListActions(lblterminateinstructionPath); 
	
	String lblcreatinstructionPath = "//a[contains(text(),'Create')]";
	public ListActions lblcreatinstruction = new ListActions(lblcreatinstructionPath); 
	
	String linkcreateinstrcutionPath = "(//a[contains(text(),'Create')])[2]";
	public Button linkcreateinstrcution = new Button(linkcreateinstrcutionPath, LocatorType.XPATH);
	
	String linkcreateinstrcutionPath1 = "(//a[contains(text(),'Create')])[1]";
	public Button linkcreateinstrcution1 = new Button(linkcreateinstrcutionPath1, LocatorType.XPATH);
	
	String linkcreateinstrcutionPath2 = "//table//tr[5]//td//a";
	public Button linkcreateinstrcution2 = new Button(linkcreateinstrcutionPath2, LocatorType.XPATH);
	
	String linkcreateinstrcutionPath3 = "//table//tr[7]//td//a";
	public Button linkcreateinstrcution3 = new Button(linkcreateinstrcutionPath3, LocatorType.XPATH);
	
	String linkterminateinstrcutionPath = "(//a[contains(text(),'Terminate')])[3]";
	public Button linkterminateinstrcution = new Button(linkterminateinstrcutionPath, LocatorType.XPATH);
	
	String linkterminateinstrcutionPath1 = "(//a[contains(text(),'Terminate')])[3]";
	public Button linkterminateinstrcution1 = new Button(linkterminateinstrcutionPath1, LocatorType.XPATH);
	
	String linkterminateinstrcutionPath2 = "//table//tr[4]//td//a";
	public Button linkterminateinstrcution2 = new Button(linkterminateinstrcutionPath2, LocatorType.XPATH);
	
	String linkterminateinstrcutionPath3 = "//table//tr[1]//td//a";
	public Button linkterminateinstrcution3 = new Button(linkterminateinstrcutionPath3, LocatorType.XPATH);
	
	String clickheretoeditlinkPath = "//a[@id='btPaymentInstruction']";
	public Button clickheretoeditlink = new Button(clickheretoeditlinkPath, LocatorType.XPATH);
	public JavascriptExecutorfunction clickheretoedit= new JavascriptExecutorfunction(clickheretoeditlinkPath, LocatorType.XPATH);
	
	String lblsubheaderPath = "(//h2)[2]";
	public Label lblsubheader= new Label(lblsubheaderPath,LocatorType.XPATH);
	
	String lbldevidentchoicePath = "//table//tbody//tr[4]//td[9]";
	public Label lbldevidentchoice= new Label(lbldevidentchoicePath,LocatorType.XPATH);
	
	String lbldevidentchoicePath1 = "//table//tbody//tr[5]//td[9]";
	public Label lbldevidentchoice1= new Label(lbldevidentchoicePath1,LocatorType.XPATH);
	
	String lblinstNotePath = "(//div//ul[@class='list']//p)[1]";
	public Label lblinstNote= new Label(lblinstNotePath,LocatorType.XPATH);
	public JavascriptExecutorfunction lblnote= new JavascriptExecutorfunction(lblinstNotePath, LocatorType.XPATH);
	
	String lbllinkPath = "//p//a[contains(text(),'Click here to view full terms and conditions of the dividend reinvestment plan')]";
	public Label lbllink= new Label(lbllinkPath,LocatorType.XPATH);
	
	String btnlinkPath = "//p//a[contains(text(),'Click here to view full terms and conditions of the dividend reinvestment plan')]";
	public Button btnlink= new Button(btnlinkPath,LocatorType.XPATH);
	
	String btntermsconditionpath = "//input[@id='TermsAndConditionsAccepted']";
	public Button btntermscondition= new Button(btntermsconditionpath,LocatorType.XPATH);
	
	String btnbackPath = "//button[@id='btnCancel']";
	public Button btnback= new Button(btnbackPath,LocatorType.XPATH);
	
	String btnBackPath = "//button[@id='btnBack']";
	public Button btnBack= new Button(btnBackPath,LocatorType.XPATH);
	
	String btnconfirmPath = "//button[@id='btnContinue']";
	public Button btnconfirm= new Button(btnconfirmPath,LocatorType.XPATH);
	
	String btndonePath = "//button[@id='btnDone']";
	public Button btndone= new Button(btndonePath,LocatorType.XPATH);
	
	String btnnextPath = "//button[@id='btnNext']";
	public Button btnnext= new Button(btnnextPath,LocatorType.XPATH);
	
	String btnconfirmPath1 = "//button[@id='btnConfirm']";
	public Button btnconfirm1= new Button(btnconfirmPath1,LocatorType.XPATH);
	
	String sortcodetextboxPath = "//input[@id='SortCode']";
	public Input sortcodetextbox= new Input(sortcodetextboxPath,LocatorType.XPATH);
	
	String actnotextboxPath = "//input[@id='AccountNumber']";
	public Input actnotextbox= new Input(actnotextboxPath,LocatorType.XPATH);
	
	String bsrntextboxPath = "(//input[@id='BuildingSocietyRollNumber'])[1]";
	public Input bsrntextbox= new Input(bsrntextboxPath,LocatorType.XPATH);
	
	String lblsecurityPath = "//table//tbody//tr[1]//th[contains(text(),'Security:')]";
	public JavascriptExecutorfunction lblsecurity= new JavascriptExecutorfunction(lblsecurityPath, LocatorType.XPATH);
	
	String selpaymentTypePath = "//select[@id='PaymentMode']";
	public Select selpaymentType = new Select(selpaymentTypePath, LocatorType.XPATH);
}
