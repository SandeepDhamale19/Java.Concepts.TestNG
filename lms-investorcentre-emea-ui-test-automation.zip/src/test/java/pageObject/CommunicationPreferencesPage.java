package pageObject;

import ActionsFactory.JavascriptExecutorfunction;
import ActionsFactory.ListActions;
import ActionsFactory.ValidateLabelUI;
import ActionsFactory.WindowsFactory;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Selenium.LocatorType;

public class CommunicationPreferencesPage {
	
	String lblCommunicationPreferencesPath = "//*[@id='mainContent']/h1";
	public Label lblCommunicationPreferences= new Label(lblCommunicationPreferencesPath,LocatorType.XPATH);
	public JavascriptExecutorfunction lblcommpref= new JavascriptExecutorfunction(lblCommunicationPreferencesPath, LocatorType.XPATH);
	
	String btnPrinterPath = "//a[@id='printLink']";
	public Button btnPrinter= new Button(btnPrinterPath,LocatorType.XPATH);
	
	String btnHelpPath = "//a[@class='helpLink']";
	public Button btnHelp= new Button(btnHelpPath,LocatorType.XPATH);
	
	String lblViewPath = "//label[@for='ViewKey']";
	public Label lblView= new Label(lblViewPath,LocatorType.XPATH);
	
	String lblInstructionalTextPath1 = "//form[@id='PreferencesForm']/p";
	public Label lblInstructionalText1= new Label(lblInstructionalTextPath1,LocatorType.XPATH);
	
	String lblInstructionalTextPath2 = "//li[@class='bigLabel']/span";
	public Label lblInstructionalText2= new Label(lblInstructionalTextPath2,LocatorType.XPATH);
	
	String lblInstructionalTextPath3 = "//div[@class='form radioList']/p";
	public Label lblInstructionalText3= new Label(lblInstructionalTextPath3,LocatorType.XPATH);
	
	String lblInstructionalTextPath4 = "//label[@for='AnnualReportRadioCode_ECOM']";
	public Label lblInstructionalText4= new Label(lblInstructionalTextPath4,LocatorType.XPATH);
	
	String lblInstructionalRadioTextPath5 = "//li[@class=\"bigLabel\"]/span";
	public Label lblInstructionalRadioText5= new Label(lblInstructionalRadioTextPath5,LocatorType.XPATH);
	
	String lblInstructionalTextPath5 = "(//div[@id='viewBarDetails']/p)[1]";
	public Label lblInstructionalText5= new Label(lblInstructionalTextPath5,LocatorType.XPATH);
	
	String lblInstructionalTextPath6 = "(//div[@id='viewBarDetails']/p)[2]";
	public Label lblInstructionalText6= new Label(lblInstructionalTextPath6,LocatorType.XPATH);

	String chkallCommunicationElectronicallyPath = "//input[@id='AnnualReportRadioCode_ECOM']";
	public Button chkallCommunicationElectronically = new Button(chkallCommunicationElectronicallyPath, LocatorType.XPATH);
	
	String lblEmailAddressPath = "//label[@for='EmailAddress']";
	public Label lblEmailAddress = new Label(lblEmailAddressPath, LocatorType.XPATH); 
	
	String lblOthersPath = "//label[@for='EmailAddressRadioCode_EmailAddress']";
	public Label lblOthers = new Label(lblOthersPath, LocatorType.XPATH); 
	
	String chkPrimaryEmailPath = "//input[@id='EmailAddressRadioCode_UserName']";
	public Button chkPrimaryEmail = new Button(chkPrimaryEmailPath, LocatorType.XPATH);
	
	String chkOtherEmailPath = "//input[@id='EmailAddressRadioCode_EmailAddress']";
	public Button chkOtherEmail = new Button(chkOtherEmailPath, LocatorType.XPATH);
	
	String rbtnEmailAddressPath = "//input[@id='EmailAddressRadioCode_EmailAddress']";
	public Button rbtnEmailAddress = new Button(rbtnEmailAddressPath,LocatorType.XPATH);
	
	String txtEmailAddressPath = "//input[@id='EmailAddress']";
	public Input txtEmailAddress = new Input(txtEmailAddressPath,LocatorType.XPATH);
	
	String lblEmailAddressErrorPath = "//label[@for='EmailAddress' and @class='error']";
	public Label lblEmailAddressError = new Label(lblEmailAddressErrorPath,LocatorType.XPATH);
	
	String lblNotePath = "//div[@class='form commsEmailAddress']/p";
	public Label lblNote = new Label(lblNotePath,LocatorType.XPATH);
	
	String lblInstructional5TextPath = "(//div[@id='viewBarDetails']/p)[1]";
	public Label lblInstructional5Text = new Label(lblInstructional5TextPath,LocatorType.XPATH);
	
	String btnNextPath = "//button[@id='btnUpdate']";
	public Button btnNext = new Button(btnNextPath,LocatorType.XPATH);
	
	String selAllHoldingPath = "//select[@id='ViewKey']";
	public ListActions lnkAllHoldingPath = new ListActions(selAllHoldingPath);
	public Select selAllHolding = new Select(selAllHoldingPath, LocatorType.XPATH);
	
	String btnConfirmPath = "//button[@id='btnConfirm']";
	public Button btnConfirm = new Button(btnConfirmPath,LocatorType.XPATH);
	
	String lblCommPrefPath = "//*[@id='mainContent']/div/h1";
	public Label lblCommPref = new Label(lblCommPrefPath,LocatorType.XPATH);
	
	String lblPleaseConfirmPath = "//*[@id=\"ConfirmForm\"]/h2";
	public Label lblPleaseConfirm = new Label(lblPleaseConfirmPath,LocatorType.XPATH);
	
	String lblmethodPath = "(//table[@aria-describedby='Communication prereference confirm']/tbody/tr/th)[1]";
	public Label lblmethod = new Label(lblmethodPath,LocatorType.XPATH);
	
	String lblAllCommElectroncallyPath = "(//table[@aria-describedby='Communication prereference confirm']/tbody/tr/td[contains(text(),'All communications electronically')])[1]";
	public Label lblAllCommElectroncally = new Label(lblAllCommElectroncallyPath,LocatorType.XPATH);
	
	String lblApplyToPath = "(//table[@aria-describedby='Communication prereference confirm']/tbody/tr/th)[2]";
	public Label lblApplyTo = new Label(lblApplyToPath,LocatorType.XPATH);
	
	String lblIssuerPath = "//th[@id=\"UpdatedHoldingsGrid_Issuer\"]/div";
	public Label lblIssuer = new Label(lblIssuerPath,LocatorType.XPATH);
	
	String lblIVCPath = "//th[@id='UpdatedHoldingsGrid_IVC']/div";
	public Label lblIVC = new Label(lblIVCPath,LocatorType.XPATH);
	
	String lblHolderNamePath = "//th[@id='UpdatedHoldingsGrid_Holder name']/div";
	public Label lblHolderName = new Label(lblHolderNamePath,LocatorType.XPATH);
	
	String btnbackButtonPath = "//button[@id=\"btnBack\"]";
	public Button btnbackButton = new Button(btnbackButtonPath,LocatorType.XPATH);
	
	String chkIsShowOtherHoldingsPath = "//label[@for='IsShowOtherHoldings']";
	public Button chkIsShowOtherHoldings = new Button(chkIsShowOtherHoldingsPath,LocatorType.XPATH);
	public Actions chkIsShowOtherHoldingsactions = new Actions(chkIsShowOtherHoldingsPath, LocatorType.XPATH);
	
	String chkIsShowOtherHoldingsAPath = "//input[@id='IsShowOtherHoldings' and @type='checkbox']";
	public Button chkIsShowOtherHoldingsA = new Button(chkIsShowOtherHoldingsAPath,LocatorType.XPATH);
	
	
	String lblIsShowOtherHoldingsPath = "//label[@for='IsShowOtherHoldings']";
	public Label lblIsShowOtherHoldings = new Label(lblIsShowOtherHoldingsPath,LocatorType.XPATH);
	
	String chkApplyToAllHoldings_1Path = "//label[@for='ApplyToAllHoldings_1']";
	public Button chkApplyToAllHoldings_1 = new Button(chkApplyToAllHoldings_1Path,LocatorType.XPATH);
	
	String rdbtnotherHoldingsPadradioListradioListSlimPath1 = "(//div[@class='otherHoldingsPad radioList radioListSlim' and @style='display: none;']/ol/li/label[@for='ApplyToAllHoldings_1'])[1]";
	public Button rdbtnotherHoldingsPadradioListradioListSlim1 = new Button(rdbtnotherHoldingsPadradioListradioListSlimPath1,LocatorType.XPATH);
	
	String rdbtnotherHoldingsPadradioListradioListSlimPath2 = "(//div[@class='otherHoldingsPad radioList radioListSlim' and @style='display: none;']/ol/li/label[@for='ApplyToAllHoldings_2'])[1]";
	public Button rdbtnotherHoldingsPadradioListradioListSlim2 = new Button(rdbtnotherHoldingsPadradioListradioListSlimPath2,LocatorType.XPATH);

	
	String lblApplyToAllHoldings_1Path = "//label[@for='ApplyToAllHoldings_1']";
	public Label lblApplyToAllHoldings_1 = new Label(lblApplyToAllHoldings_1Path,LocatorType.XPATH);
	
	public Label eleApplyToAllHoldings_1 = new Label(lblApplyToAllHoldings_1Path,LocatorType.XPATH);
	
	
	
	String btnApplyToAllHoldings_1Path = "//label[@for='ApplyToAllHoldings_1']";
	public Button btnApplyToAllHoldings_1 = new Button(btnApplyToAllHoldings_1Path,LocatorType.XPATH);
	
	String chkApplyToAllHoldings_2Path = "//label[@for='ApplyToAllHoldings_2']";
	public Button chkApplyToAllHoldings_2 = new Button(chkIsShowOtherHoldingsPath,LocatorType.XPATH);
	public Label lblApplyToAllHoldings_2chk = new Label(chkIsShowOtherHoldingsPath,LocatorType.XPATH);
	
	String lblApplyToAllHoldings_2Path = "//label[@for='ApplyToAllHoldings_2']";
	public Label lblApplyToAllHoldings_2 = new Label(lblApplyToAllHoldings_2Path,LocatorType.XPATH);
	
	public Label eleApplyToAllHoldings_2 = new Label(lblApplyToAllHoldings_2Path,LocatorType.XPATH);
	
	String lblFAQPath = "//li[@id='helpMenu']";
	public Label lblFAQ = new Label(lblFAQPath,LocatorType.XPATH);
	
	public WindowsFactory windowsFactory = new WindowsFactory();
	
	String txtNewLoginPasswordPath = "//input[@autocomplete='off' and @class='required mark-required' and @id='NewPassword']";
	public Input txtNewLoginPassword= new Input(txtNewLoginPasswordPath, LocatorType.XPATH);
	
	//Android UI Elements
	String androidElementListlblPath = "//androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[1]";
	public Label androidElementListlbl = new Label(androidElementListlblPath,LocatorType.XPATH);
	
	String androidElementListIndividualHoldingsPath = "//androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[1]/android.widget.RelativeLayout/android.widget.TextView";
	public Label androidElementListIndividualHoldings = new Label(androidElementListIndividualHoldingsPath,LocatorType.XPATH);
	
	String androidElementListToggleButtonPath = "//android.widget.RelativeLayout[1]/android.widget.Switch";
	public Label androidElementListToggleButton = new Label(androidElementListToggleButtonPath,LocatorType.XPATH);
	
	//IOS Elements 

	String iosElementlblHoldingsPath = "(//XCUIElementTypeStaticText[@name='HOLDING SETTINGS'])[3]";
	public Label iosElementlblHoldings = new Label(iosElementlblHoldingsPath,LocatorType.XPATH); 
	
	String iosElementlblHoldings2Path = "(//XCUIElementTypeStaticText[@name='HOLDING SETTINGS'])[2]";
	public Label iosElementlblHoldings2 = new Label(iosElementlblHoldings2Path,LocatorType.XPATH); 
	
	String iosElementSelViewByDropDownPath = "//XCUIElementTypeTextView";
	public Button iosElementSelViewByDropDown = new Button(iosElementSelViewByDropDownPath,LocatorType.XPATH);
	
	public Button iosElementSelectByTextValue= new Button();
	
	public Label iosElementlblValidateLabel = new Label(); 
	
	String iosElementtxtEmailAddressPath = "(//XCUIElementTypeTextField)[2]";
	public Input iosElementtxtEmailAddress= new Input(iosElementtxtEmailAddressPath, LocatorType.XPATH);
	public Button iosElementbtnEmailAddress= new Button(iosElementtxtEmailAddressPath, LocatorType.XPATH);
	
	public Input iosElementHideKeyboard= new Input();
	
	String iosElementlblConfirm1Path = "(//XCUIElementTypeStaticText[@label='Confirm'])[1]";
	public Label iosElementlblConfirm1 = new Label(iosElementlblConfirm1Path,LocatorType.XPATH); 

	String iosElementlblConfirmPath = "(//XCUIElementTypeStaticText[@label='Confirm'])[2]";
	public Button iosElementlblConfirm = new Button(iosElementlblConfirmPath,LocatorType.XPATH); 

	String iosElementbtnDonePath = "//XCUIElementTypeButton[@name='Done']";
	public Button iosElementbtnDone = new Button(iosElementbtnDonePath,LocatorType.XPATH); 
	
	public Actions action= new Actions();
	
	String iosElementToggleApplytoAllHoldingsPath = "(//XCUIElementTypeSwitch)[1]";
	public Button iosElementToggleApplytoAllHoldings = new Button(iosElementToggleApplytoAllHoldingsPath,LocatorType.XPATH);
	
	String iosElementToggleApplytoIndividualHoldingsPath = "(//XCUIElementTypeSwitch)[2]";
	public Button iosElementToggleApplytoIndividualHoldings = new Button(iosElementToggleApplytoIndividualHoldingsPath,LocatorType.XPATH);
	
	String iosElementlblEdit1Path = "(//XCUIElementTypeStaticText[@label='Edit'])[1]";
	public Label iosElementlblEdit1 = new Label(iosElementlblEdit1Path,LocatorType.XPATH);
	public Button iosElementbtnEdit1 = new Button(iosElementlblEdit1Path,LocatorType.XPATH);

	String iosElementlblEdit2Path = "(//XCUIElementTypeStaticText[@label='Edit'])[2]";
	public Label iosElementlblEdit2 = new Label(iosElementlblEdit2Path,LocatorType.XPATH); 
	public Button iosElementbtnEdit2 = new Button(iosElementlblEdit2Path,LocatorType.XPATH);
	
	String iosElementtxtAddressLine1Path = "(//XCUIElementTypeTextField)[1]";
	public Input iosElementtxtAddressLine1= new Input(iosElementtxtAddressLine1Path, LocatorType.XPATH);

	String iosElementtxtAddressLine2Path = "(//XCUIElementTypeTextField)[2]";
	public Input iosElementtxtAddressLine2= new Input(iosElementtxtAddressLine2Path, LocatorType.XPATH);

	String iosElementtxtAddressLine3Path = "(//XCUIElementTypeTextField)[3]";
	public Input iosElementtxtAddressLine3= new Input(iosElementtxtAddressLine3Path, LocatorType.XPATH);

	String iosElementtxtAddressLine4Path = "(//XCUIElementTypeTextField)[4]";
	public Input iosElementtxtAddressLine4= new Input(iosElementtxtAddressLine4Path, LocatorType.XPATH);

	String iosElementtxtAddressLine5Path = "(//XCUIElementTypeTextField)[5]";
	public Input iosElementtxtAddressLine5= new Input(iosElementtxtAddressLine5Path, LocatorType.XPATH);
	
	String iosElementtxtAddressLine6Path = "(//XCUIElementTypeTextField)[6]";
	public Input iosElementtxtAddressLine6 = new Input(iosElementtxtAddressLine6Path, LocatorType.XPATH);
	
}
