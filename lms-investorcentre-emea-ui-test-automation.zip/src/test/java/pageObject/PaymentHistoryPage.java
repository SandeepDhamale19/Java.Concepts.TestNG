package pageObject;

import ActionsFactory.ListActions;
import ActionsFactory.ValidateLabelUI;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Selenium.LocatorType;

public class PaymentHistoryPage {
	
	String lblPaymentHistoryPath = "//*[@id=\"mainContent\"]/h1";
	public Label lblPaymentHistory= new Label(lblPaymentHistoryPath,LocatorType.XPATH);
	
	String txtDateFromPath = "//input[@id='DateFrom']";
	public Input txtDateFrom = new Input(txtDateFromPath,LocatorType.XPATH);
	
	String txtDateToPath = "//input[@id='DateTo']";
	public Input txtDateTo = new Input(txtDateToPath,LocatorType.XPATH);
	
	
	String lblFilterFromPath = "//*[@id='filterDateFrom']";
	public Label lblFilterFrom = new Label(lblFilterFromPath, LocatorType.XPATH);  
	
	
	String lblFilterToPath = "//*[@id='filterDateTo']";
	public Label lblFilterTo = new Label(lblFilterToPath, LocatorType.XPATH);  
	
	String btnGoPath = "//button[@id='btnGo']";
	public Button btnGo = new Button(btnGoPath,LocatorType.XPATH);
	
	String lblPaymentDatePath = "//table[@id='PaymentHistoryGrid']/tbody/tr/td[2]";
	public ListActions lblPaymentDate = new ListActions(lblPaymentDatePath); 
	
	String paginationlbl = "//div[@class='ui-paging-info']";
	public ListActions listpagination = new ListActions(paginationlbl);
	
	String lblPaymentIssuerPath = "//table[@id='PaymentHistoryGrid']/tbody/tr/td[3]";
	public ListActions lblPaymentIssuer = new ListActions(lblPaymentIssuerPath);
	
	String lblIVCPath = "//table[@id='PaymentHistoryGrid']/tbody/tr/td[6]";
	public ListActions lblIVC = new ListActions(lblIVCPath);
	
	String selivcHoldingPath = "//select[@id='ViewKey']";
	public Select selivcHolding = new Select(selivcHoldingPath, LocatorType.XPATH); 
	
	
	//Android UI Elements
	String androidEelementbtnPaymentcardPath = 	"com.linkgroup.android_investorcentre.sit:id/menu_payments";
	public Button androidEelementbtnPaymentcard= new Button(androidEelementbtnPaymentcardPath, LocatorType.ID);
			
	//Click-----Starts
	String androidElementSelIssuerAllHoldingsPath = "com.linkgroup.android_investorcentre.sit:id/edit_text";
	public Button androidElementSelIssuerAllHoldings= new Button(androidElementSelIssuerAllHoldingsPath, LocatorType.ID);
	
	//Click
	String androidElementInputAllHoldingsPath = "com.linkgroup.android_investorcentre.sit:id/edit_text";
	public Input androidElementInputAllHoldings= new Input(androidElementInputAllHoldingsPath, LocatorType.ID);
	
	//Click----Ends
	String androidElementSelIssuerPath =  "com.linkgroup.android_investorcentre.sit:id/filter_date_range";
	public Button androidElementSelIssuer= new Button(androidElementSelIssuerPath, LocatorType.ID);
	
	//Label Verify
	String androidElementlblPaymentHistoryPath = "com.linkgroup.android_investorcentre.sit:id/title";
	public Label androidElementlblPaymentHistory= new Label(androidElementlblPaymentHistoryPath, LocatorType.ID);
	
	String androidElementlblviewByPath = "com.linkgroup.android_investorcentre.sit:id/view_by";
	public Label androidElementlblviewBy= new Label(androidElementlblviewByPath, LocatorType.ID);
	
	String androidElementlblAllHoldingsPath = "com.linkgroup.android_investorcentre.sit:id/edit_text";
	public Label androidElementlblAllHoldings= new Label(androidElementlblAllHoldingsPath, LocatorType.ID);

	String androidElementlblFilterDateRangePath = "com.linkgroup.android_investorcentre.sit:id/filter_date_range";
	public Label androidElementlblFilterDateRange= new Label(androidElementlblFilterDateRangePath, LocatorType.ID);
	
	String androidElementlblPaymentEmptysubtitlePath = "com.linkgroup.android_investorcentre.sit:id/payment_empty_title";
	public Label androidElementlblPaymentEmptysubtitle= new Label(androidElementlblPaymentEmptysubtitlePath, LocatorType.ID);
	
	String androidElementlblVerifytodaysdatePath = "com.linkgroup.android_investorcentre.sit:id/txt_from_date";
	public Label androidElementlblVerifytodaysdate= new Label(androidElementlblVerifytodaysdatePath, LocatorType.ID);
	
	String androidElementlblVerifyLast2YearsPath = "com.linkgroup.android_investorcentre.sit:id/txt_to_date";
	public Label androidElementlblVerifyLast2Years= new Label(androidElementlblVerifyLast2YearsPath, LocatorType.ID);

	String androidElementlblNoRecentPaymentsPath = "com.linkgroup.android_investorcentre.sit:id/payment_empty_title";
	public Label androidElementlblNoRecentPayments= new Label(androidElementlblNoRecentPaymentsPath, LocatorType.ID);

	String androidElementlblPaymentsmakeLast2YearsPath = "com.linkgroup.android_investorcentre.sit:id/payment_empty_subtitle";
	public Label androidElementlblPaymentsmakeLast2Years= new Label(androidElementlblPaymentsmakeLast2YearsPath, LocatorType.ID);
	
	//Label Payment Description
	String androidElementlblPaymentDescriptionPath = "com.linkgroup.android_investorcentre.sit:id/payment_description_text";
	public Label androidElementlblPaymentDescription= new Label(androidElementlblPaymentDescriptionPath, LocatorType.ID);

	String androidElementlblIVCPath = "com.linkgroup.android_investorcentre.sit:id/hin_srn";
	public Label androidElementlblIVC= new Label(androidElementlblIVCPath, LocatorType.ID);

	String androidElementlblSecurityCodePath = "com.linkgroup.android_investorcentre.sit:id/security_code";
	public Label androidElementlblSecurityCode= new Label(androidElementlblSecurityCodePath, LocatorType.ID);

	String androidElementlblStatusPath = "com.linkgroup.android_investorcentre.sit:id/payment_status";
	public Label androidElementlblStatus= new Label(androidElementlblStatusPath, LocatorType.ID);

	String androidElementlblTypePath = "com.linkgroup.android_investorcentre.sit:id/payment_type";
	public Label androidElementlblType= new Label(androidElementlblTypePath, LocatorType.ID);
	
	String androidElementlblPaymentAmountPath = "com.linkgroup.android_investorcentre.sit:id/payment_amount";
	public Label androidElementlblPaymentAmount= new Label(androidElementlblPaymentAmountPath, LocatorType.ID);

	String androidElementlblPaymentStatementPath = "com.linkgroup.android_investorcentre.sit:id/payment_statement";
	public Label androidElementlblPaymentStatement= new Label(androidElementlblPaymentStatementPath, LocatorType.ID);
	
	String androidElementlblDownloadPath = "com.linkgroup.android_investorcentre.sit:id/payment_statement_download";
	public Label androidElementlblDownload= new Label(androidElementlblDownloadPath, LocatorType.ID);
	
	//IOS Elements
	public Button iosElementPayment= new Button();
	public Label iosElementValidatelabelPayment= new Label();
	
	String iosElementlblEditPath = "(//XCUIElementTypeStaticText[@name='Edit'])[1]";
	public Label iosElementlblEdit= new Label(iosElementlblEditPath, LocatorType.XPATH);
	public Button iosElementbtnEdit= new Button(iosElementlblEditPath, LocatorType.XPATH);
	
	String iosElementlblIVC1Path = "(//XCUIElementTypeStaticText[@name='IVC'])[1]";
	public Label iosElementlblIVC1= new Label(iosElementlblIVC1Path, LocatorType.XPATH);
	
	String iosElementlblIVC2Path = "(//XCUIElementTypeStaticText[@name='IVC'])[2]";
	public Label iosElementlblIVC2= new Label(iosElementlblIVC2Path, LocatorType.XPATH);
	
	String iosElementLast2YearDatePath = "(//XCUIElementTypeTextField)[1]";
	public Label iosElementLast2YearDate= new Label(iosElementLast2YearDatePath, LocatorType.XPATH);
	
	String iosElementTodaysDatePath = "(//XCUIElementTypeTextField)[2]";
	public Label iosElementTodaydate= new Label(iosElementTodaysDatePath, LocatorType.XPATH);
	
	
	String iosElementbtnClosePdfPath = "(//XCUIElementTypeButton)[1]";
	public Button iosElementbtnClosePdf= new Button(iosElementbtnClosePdfPath, LocatorType.XPATH);
	
	String iosElementbtnSharePdfPath = "(//XCUIElementTypeButton)[2]";
	public Button iosElementbtnSharePdf= new Button(iosElementbtnSharePdfPath, LocatorType.XPATH);

}
