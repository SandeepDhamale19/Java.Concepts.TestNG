package pageObject;

import ActionsFactory.JavascriptExecutorfunction;
import ActionsFactory.ListActions;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import Selenium.LocatorType;import io.cucumber.java.en.Then;

public class AccountSettingsPage {
	
	String iosElementlblAddHoldingPath = "//XCUIElementTypeStaticText[@name='Add holding']";
	public Label iosElementlblAddHolding= new Label(iosElementlblAddHoldingPath, LocatorType.XPATH);
	
	String iosElementbtnClosePath = "//XCUIElementTypeButton[@name='close']";
	public Button iosElementbtnClose= new Button(iosElementbtnClosePath, LocatorType.XPATH);
	
	String iosElementbtnLogoutPath = "//XCUIElementTypeStaticText[@name='Log Out']";
	public Button iosElementbtnLogout= new Button(iosElementbtnLogoutPath, LocatorType.XPATH);
	
	public Actions actions= new Actions();
	
	String iosElementlblLogoutPath = "//XCUIElementTypeStaticText[@name='Log out?']";
	public Label iosElementlblLogout= new Label(iosElementlblLogoutPath, LocatorType.XPATH);
	
	String iosElementlblAreYouSureYouwanttoLogoutPath = "//XCUIElementTypeStaticText[@name='Are you sure you want to log out of the app?']";
	public Label iosElementlblAreYouSureYouwanttoLogout= new Label(iosElementlblAreYouSureYouwanttoLogoutPath, LocatorType.XPATH);
	
	String iosElementlblCancelPath = "//XCUIElementTypeButton[@name='Cancel']";
	public Label iosElementlblCancel= new Label(iosElementlblCancelPath, LocatorType.XPATH);

	String iosElementbtnLogOutPath = "//XCUIElementTypeButton[@name='Logout']";
	public Button iosElementbtnLogOut= new Button(iosElementbtnLogOutPath, LocatorType.XPATH);
	
	String iosElementbtnAccountSettingsPath = "(//XCUIElementTypeStaticText[contains(@name,'App Settings')])[last()]";
	public Button iosElementbtnAccountSettings= new Button(iosElementbtnAccountSettingsPath, LocatorType.XPATH);
	
	String iosElementbtnReVisitOnBoardingPath = "(//XCUIElementTypeStaticText[contains(@name,'Re-visit Onboarding')])[last()]";
	public Button iosElementbtnReVisitOnBoarding= new Button(iosElementbtnReVisitOnBoardingPath, LocatorType.XPATH);
	
	
	String iosElementbtnTermsConditionsPath = "(//XCUIElementTypeStaticText[contains(@name,'Terms & Conditions')])[last()]";
	public Button iosElementbtnTermsConditions= new Button(iosElementbtnTermsConditionsPath, LocatorType.XPATH);
			
	String iosElementlblTermsConditionsTitlePath = "(//XCUIElementTypeStaticText[contains(@label,'TERMS & CONDITIONS')])[last()]";
	public Label iosElementlblTermsConditionsTitle= new Label(iosElementlblTermsConditionsTitlePath, LocatorType.XPATH);
	
	String iosElementbtnManagePinPath = "(//XCUIElementTypeStaticText[contains(@name,'Manage PIN')])[last()]";
	public Button iosElementbtnManagePin= new Button(iosElementbtnManagePinPath, LocatorType.XPATH);
	
	String iosElemementbtnEnablePinPath = "//XCUIElementTypeSwitch";
	public Button iosElemementbtnEnablePin= new Button(iosElemementbtnEnablePinPath, LocatorType.XPATH);
	
	String iosElementbtnChangePinPath = "(//XCUIElementTypeStaticText[@name='Change PIN'])[2]";
	public Button iosElementbtnChangePin= new Button(iosElementbtnChangePinPath, LocatorType.XPATH);
	
	String iosElementbtnNavigationBackBtnPath = "//XCUIElementTypeNavigationBar[@name='App Settings']/XCUIElementTypeButton";
	public Button iosElementbtnNavigationBackBtn= new Button(iosElementbtnNavigationBackBtnPath, LocatorType.XPATH);
	
	String iosElementbtnNavigationBackBtnPath2 = "//XCUIElementTypeNavigationBar[@name='APP SETTINGS']/XCUIElementTypeButton";
	public Button iosElementbtnNavigationBackBtn2= new Button(iosElementbtnNavigationBackBtnPath2, LocatorType.XPATH);
	
	String iosElementbtnUserSettingsPath = "(//XCUIElementTypeStaticText[contains(@name,'User Settings')])[last()]";
	public Button iosElementbtnUserSettings= new Button(iosElementbtnUserSettingsPath, LocatorType.XPATH);
	
	String iosElementbtnDeleteAccountPath = "(//XCUIElementTypeStaticText[contains(@name,'Delete Account')])[last()]";
	public Button iosElementbtnDeleteAccount= new Button(iosElementbtnDeleteAccountPath, LocatorType.XPATH);
	
	String iosElementbtnCancelAccountPath = "//XCUIElementTypeStaticText[@name='Cancel']";
	public Button iosElementbtnCancelAccount= new Button(iosElementbtnCancelAccountPath, LocatorType.XPATH);

	String iosElementbtnRemoveAccountFromDevicePath = "//XCUIElementTypeStaticText[@name='Remove Account From Device']";
	public Button iosElementbtnRemoveAccountFromDevice= new Button(iosElementbtnRemoveAccountFromDevicePath, LocatorType.XPATH);
	
	String iosElementbtnCancelAccountFromDevicePath = "//XCUIElementTypeButton[@name='Cancel']";
	public Button iosElementbtnCancelAccountFromDevice= new Button(iosElementbtnCancelAccountFromDevicePath, LocatorType.XPATH);
	
	//User Settings
	String iosElementlblPortfolioPasswordDevicePath = "(//XCUIElementTypeStaticText[contains(@label,'Change Portfolio Password')])[last()]";
	public Label iosElementlblPortfolioPasswordDevice= new Label(iosElementlblPortfolioPasswordDevicePath, LocatorType.XPATH);
	
	String iosElementbtnPortfolioPasswordDevicePath = "(//XCUIElementTypeStaticText[contains(@label,'Change Portfolio Password')])[last()]";
	public Button iosElementbtnPortfolioPasswordDevice= new Button(iosElementbtnPortfolioPasswordDevicePath, LocatorType.XPATH);
	
	String iosElementlblChangeLoginEmailDevicePath = "(//XCUIElementTypeStaticText[contains(@label,'Change Login Email')])[last()]";
	public Label iosElementlblChangeLoginEmailDevice= new Label(iosElementlblChangeLoginEmailDevicePath, LocatorType.XPATH);

	String iosElementlblResetMultiFactorAuthDevicePath = "(//XCUIElementTypeStaticText[contains(@label,'Reset Multi-Factor Authentication')])[last()]";
	public Label iosElementlblResetMultiFactorAuthDevice= new Label(iosElementlblResetMultiFactorAuthDevicePath, LocatorType.XPATH);

	String iosElementlblDeleteAccountDevicePath = "(//XCUIElementTypeStaticText[contains(@label,'Delete Account')])[last()]";
	public Label iosElementlblDeleteAccountDevice= new Label(iosElementlblDeleteAccountDevicePath, LocatorType.XPATH);
	
	//Change Password
	
	String iosElementbtnCurrentPasswordDevicePath = "(///XCUIElementTypeSecureTextField)[1]";
	public Button iosElementbtnCurrentPasswordDevice= new Button(iosElementbtnCurrentPasswordDevicePath, LocatorType.XPATH);
	
	String iosElementtxtCurrentPasswordDevicePath = "(///XCUIElementTypeSecureTextField)[1]";
	public Input iosElementtxtCurrentPasswordDevice= new Input(iosElementtxtCurrentPasswordDevicePath, LocatorType.XPATH);
	
	String iosElementbtnNewPasswordDevicePath = "(///XCUIElementTypeSecureTextField)[2]";
	public Button iosElementbtnNewPasswordDevice= new Button(iosElementbtnNewPasswordDevicePath, LocatorType.XPATH);
	
	String iosElementtxtNewPasswordDevicePath = "(///XCUIElementTypeSecureTextField)[2]";
	public Input iosElementtxtNewPasswordDevice= new Input(iosElementtxtNewPasswordDevicePath, LocatorType.XPATH);
	
	String iosElementbtnConfirmPasswordDevicePath = "(///XCUIElementTypeSecureTextField)[3]";
	public Button iosElementbtnConfirmPasswordDevice= new Button(iosElementbtnConfirmPasswordDevicePath, LocatorType.XPATH);
	
	String iosElementtxtConfirmPasswordDevicePath = "(///XCUIElementTypeSecureTextField)[3]";
	public Input iosElementtxtConfirmPasswordDevice= new Input(iosElementtxtConfirmPasswordDevicePath, LocatorType.XPATH);
	
	
	String iosElementbtnDoneDevicePath = "//XCUIElementTypeButton[@name='Done']";
	public Button iosElementbtnDoneDevice= new Button(iosElementbtnDoneDevicePath, LocatorType.XPATH);

	String iosElementbtnConfirmDevicePath = "//XCUIElementTypeButton[@name='Confirm']";
	public Button iosElementbtnConfirmDevice = new Button(iosElementbtnConfirmDevicePath, LocatorType.XPATH);
	
	//
	String iosElementlblSuccessDevicePath = "//XCUIElementTypeStaticText[@name='Success!']";
	public Label iosElementlblSuccessDevice= new Label(iosElementlblSuccessDevicePath, LocatorType.XPATH);
	
	String iosElementlblYourPasswordhasBeenSuccessDevicePath = "//XCUIElementTypeStaticText[@name='Your password has been successfully changed.']";
	public Label iosElementlblYourPasswordhasBeenSuccessDevice= new Label(iosElementlblYourPasswordhasBeenSuccessDevicePath, LocatorType.XPATH);
	
	String iosElementbtnOkGotItDevicePath = "//XCUIElementTypeButton[@name='Ok, got it']";
	public Button iosElementbtnOkGotItDevice = new Button(iosElementbtnOkGotItDevicePath, LocatorType.XPATH);
	
	String iosElementlblUserSettingsPath = "//XCUIElementTypeStaticText[@label='User Settings']";
	public Label iosElementlblUserSettings= new Label(iosElementlblUserSettingsPath, LocatorType.XPATH);
	
	String iosElementlblHoldingSettingsPath = "//XCUIElementTypeStaticText[@label='Holding Settings']";
	public Label iosElementlblHoldingSettings= new Label(iosElementlblHoldingSettingsPath, LocatorType.XPATH);
	public Button iosElementbtnHoldingSettings= new Button(iosElementlblHoldingSettingsPath, LocatorType.XPATH);
	
	String iosElementlblAppSettingsPath = "//XCUIElementTypeStaticText[@label='App Settings']";
	public Label iosElementlblAppSettings= new Label(iosElementlblAppSettingsPath, LocatorType.XPATH);
	public Button iosElementbtnAppSettings= new Button(iosElementlblAppSettingsPath, LocatorType.XPATH);
	
	String iosElementlblReVisitOnBoardingPath = "//XCUIElementTypeStaticText[@label='Re-visit Onboarding']";
	public Label iosElementlblReVisitOnBoarding= new Label(iosElementlblReVisitOnBoardingPath, LocatorType.XPATH);

	String iosElementlblTermsandConditionsPath = "//XCUIElementTypeStaticText[@label='Terms & Conditions']";
	public Label iosElementlblTermsandConditions= new Label(iosElementlblTermsandConditionsPath, LocatorType.XPATH);

	String iosElementlblContactUsPath = "//XCUIElementTypeStaticText[@label='Contact Us']";
	public Label iosElementlblContactUs= new Label(iosElementlblContactUsPath, LocatorType.XPATH);
	
	String iosElementlblRemoveAccountPath = "//XCUIElementTypeStaticText[@name='Remove Account From Device']";
	public Label iosElementlblRemoveAccount= new Label(iosElementlblRemoveAccountPath, LocatorType.XPATH);
	
	String iosElementlblAccountLogoutPath = "//XCUIElementTypeStaticText[@name='Log Out']";
	public Label iosElementlblAccountLogout= new Label(iosElementlblAccountLogoutPath, LocatorType.XPATH);
	
	String iosElementlblChangePortfolioPasswordPath = "//XCUIElementTypeStaticText[@label='Change Portfolio Password']";
	public Label iosElementlblChangePortfolioPassword= new Label(iosElementlblChangePortfolioPasswordPath, LocatorType.XPATH);

	String iosElementlblChangeLoginEmailPath = "//XCUIElementTypeStaticText[@label='Change Login Email']";
	public Label iosElementlblChangeLoginEmail= new Label(iosElementlblChangeLoginEmailPath, LocatorType.XPATH);

	String iosElementlblResetMultifactorAuthPath = "//XCUIElementTypeStaticText[@label='Reset Multi-Factor Authentication']";
	public Label iosElementlblResetMultifactorAuth= new Label(iosElementlblResetMultifactorAuthPath, LocatorType.XPATH);
	
	String iosElementlblDeleteAccountPath = "//XCUIElementTypeStaticText[@label='Delete Account']";
	public Label iosElementlblDeleteAccount= new Label(iosElementlblDeleteAccountPath, LocatorType.XPATH);
	
	String iosElementbtnBackButtonPath = "//XCUIElementTypeButton";
	public Button iosElementbtnBackButton= new Button(iosElementbtnBackButtonPath, LocatorType.XPATH);
	
	String iosElementlblAddressDetailsPath = "//XCUIElementTypeStaticText[@label='Address Details']";
	public Label iosElementlblAddressDetailsAccounts= new Label(iosElementlblAddressDetailsPath, LocatorType.XPATH);

	String iosElementlblCommunicationPrefPath = "//XCUIElementTypeStaticText[@label='Communication Preferences']";
	public Label iosElementlblCommunicationPref= new Label(iosElementlblCommunicationPrefPath, LocatorType.XPATH);
	public Button iosElementbtnCommunicationPref= new Button(iosElementlblCommunicationPrefPath, LocatorType.XPATH);
	
	String iosElementlblpaymentInstPath = "//XCUIElementTypeStaticText[@label='Payment Instructions']";
	public Label iosElementlblpaymentInst= new Label(iosElementlblpaymentInstPath, LocatorType.XPATH);

	String iosElementlblDividendReinvestmentPath = "//XCUIElementTypeStaticText[@label='Dividend Reinvestment']";
	public Label iosElementlblDividendReinvestment= new Label(iosElementlblDividendReinvestmentPath, LocatorType.XPATH);
	
	String iosElementlblManagePINPath = "//XCUIElementTypeStaticText[@label='Manage PIN']";
	public Label iosElementlblManagePIN= new Label(iosElementlblManagePINPath, LocatorType.XPATH);
	
	String iosElementlblManageFaceIDPath = "//XCUIElementTypeStaticText[@label='Manage Face ID']";
	public Label iosElementlblManageFaceID= new Label(iosElementlblManageFaceIDPath, LocatorType.XPATH);
	
	String iosElementlblEmailAddressUpdatedPath = "(//XCUIElementTypeTextField)[2]";
	public Label iosElementlblEmailAddressUpdated= new Label(iosElementlblEmailAddressUpdatedPath, LocatorType.XPATH);
		
	
}
