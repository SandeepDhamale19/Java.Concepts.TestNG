package pageObject;

import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import Selenium.LocatorType;

public class HoldingDetailsPage {
	
	String lnkCommunicationPrefPath = "//button[@id='btnCommunicationOptionsUpdate']";
	public Button lnkCommunicationPreference = new Button(lnkCommunicationPrefPath, LocatorType.XPATH);
	
	String lnkAddressPath = "//button[@id='btnAddressUpdate']";
	public Button lnkAddressUpdate = new Button(lnkAddressPath, LocatorType.XPATH);	
			
	String lnkPaymentHistoryPath = "//button[@id='btnPaymentHistory']";
	public Button lnkPaymentHistory = new Button(lnkPaymentHistoryPath, LocatorType.XPATH);		
	
	String lnkTaxDetailsUpdatePath = "//button[@id='btnTaxDetailsUpdate']";
	public Button lnkTaxDetailsUpdate= new Button(lnkTaxDetailsUpdatePath, LocatorType.XPATH);
	
	String lnkTaxHistoryPath = "//button[@id='btnTaxHistory']";
	public Button lnkTaxHistory= new Button(lnkTaxHistoryPath, LocatorType.XPATH);

	String lnkPaymentInstructionsUpdatePath = "//button[@id='btnPaymentInstructionsUpdate']";
	public Button lnkPaymentInstructionsUpdate= new Button(lnkPaymentInstructionsUpdatePath, LocatorType.XPATH);
	
	String menuHoldingDetailsPath = "//*[text()='Holdings']";
	public Actions menuHoldingDetails= new Actions(menuHoldingDetailsPath, LocatorType.XPATH);
	
	String menuPortfolioPath = "//*[text()='Portfolio']";
	public Actions menuPortfolio= new Actions(menuPortfolioPath, LocatorType.XPATH);
	
	
		
	
}
