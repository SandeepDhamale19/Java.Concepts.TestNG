package pageObject;

import ActionsFactory.ValidateLabelUI;
import ElementsFactory.Label;
import Selenium.LocatorType;

public class TaxDetailsPage {
	
	String lblTaxDetailsPath = "//*[@id=\"mainContent\"]/h1";
	public Label lblTaxDetails= new Label(lblTaxDetailsPath,LocatorType.XPATH);
	
}
