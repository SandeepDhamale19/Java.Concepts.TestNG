package pageObject;

import ActionsFactory.JavascriptExecutorfunction;
import ActionsFactory.ListActions;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import Selenium.LocatorType;

public class AddHoldingPage {
	
	String lblApplicationTiltePath="//*[@id='ICHeaderTitle']";
	public Label lblApplicationTitle= new Label(lblApplicationTiltePath, LocatorType.XPATH);
	
	String IconApplicationLogoPath="//img[@alt=\"Investor Centre\"]";
	public Button IconApplicationLogo= new Button(IconApplicationLogoPath, LocatorType.XPATH);
	
	String lnkSkipPath = "//*[@id='btnSkip']";
	public ListActions lnkSkip = new ListActions(lnkSkipPath);
	public Button btnSkip = new Button(lnkSkipPath, LocatorType.XPATH);
	
	String btnConfirmPath = "//*[@id='btnConfirm']";
	public Button btnConfirm = new Button(btnConfirmPath, LocatorType.XPATH);
	
	String txtIssuerPath="SingleHolding_IssuerCode";
	public Input txtIssuer = new Input(txtIssuerPath, LocatorType.ID);
	
	String txtivcPath="SingleHolding_Ivc";
	public Input txtivc = new Input(txtivcPath, LocatorType.ID);
	
	String txtPostCodePath="SingleHolding_Postcode_Uk";
	public Input txtPostCode = new Input(txtPostCodePath, LocatorType.ID);
	
	String txtFirstNamePath="SingleHolding_FirstName_Uk";
	public Input txtFirstName = new Input(txtFirstNamePath, LocatorType.ID);
	
	String btnOutsideUKPath = "//button[@class='linkButton']/span[text()='Outside UK']";
	public Button btnOutsideUK = new Button(btnOutsideUKPath, LocatorType.XPATH);
	
	String txtlastnamePath="SingleHolding_LastName_Uk";
	public Input txtLastName = new Input(txtlastnamePath, LocatorType.ID);
	
	String txtlastnameOutsidePath="SingleHolding_LastName_OutsideUk";
	public Input txtlastnameOutside = new Input(txtlastnameOutsidePath, LocatorType.ID);
	
	String chkIElectPath="IsEmailCommunicationPreferred";
	public Button chkIElect= new Button(chkIElectPath, LocatorType.ID);
	
	String btnAddHoldingContinuePath = "btnContinue";
	public Button btnAddHoldingContinue= new Button(btnAddHoldingContinuePath, LocatorType.ID);
	
	String btnAddHoldingPath = "//*[@id='btnNewHolding']";
	public ListActions btnlstAddHolding= new ListActions(btnAddHoldingPath);
	public Button btnAddHoldings = new Button(btnAddHoldingPath, LocatorType.XPATH);
	
	String btnManageHoldingPath = "//button[@id='btnEditPortfolio']";
	public ListActions btnlstManageHolding= new ListActions(btnManageHoldingPath);
	public Button btnManageHoldings = new Button(btnManageHoldingPath, LocatorType.XPATH);
	
	String btnViewHoldingPath = "//button[@id='btnDone' and text()='View Holdings']";
	public Button btnViewHoldings= new Button(btnViewHoldingPath, LocatorType.XPATH);
	
	public JavascriptExecutorfunction btnViewHoldingAction= new JavascriptExecutorfunction(btnViewHoldingPath, LocatorType.XPATH);
	
	String lblSuccessMsgPath = "//*[@id='UpdateCommunicationPreferences']/h2";
	public Label lblSuccessMessage = new Label(lblSuccessMsgPath, LocatorType.XPATH);  
	
	String lblInstructionalMessagePath = "(//div[@class='section']/p)[2]";
	public Label lblInstructionalMessage = new Label(lblInstructionalMessagePath, LocatorType.XPATH);
	
	String btnCancelPath="//button[@id='btnCancel']";
	public Button btnCancel= new Button(btnCancelPath, LocatorType.XPATH);

	String lblPortfolioPath = "//*[@id=\"mainContent\"]/h1";
	public Label lblPortfolio= new Label(lblPortfolioPath,LocatorType.XPATH);
	
	String lbladdHoldingPath = "//*[@id='mainBody']/div[1]/div/h1";
	public Label lbladdHolding = new Label(lbladdHoldingPath, LocatorType.XPATH);
	
	String lbladdHoldingFooterPath = "//p[@class='clear noteParagraph']";
	public Label lbladdHoldingFooter = new Label(lbladdHoldingFooterPath, LocatorType.XPATH);
	
	String lbladdHoldingInstPath = "//*[@id='mainBody']/div[1]/div/p";
	public Label lbladdHoldingInst = new Label(lbladdHoldingInstPath, LocatorType.XPATH);
	
	public String lblErrorMessagePortfolioPath = "//table[@class='noRecords']/tbody/tr/td";
	public Label lblErrorMessagePortfolio = new Label(lblErrorMessagePortfolioPath, LocatorType.XPATH);
	public ListActions lblErrorMessagePortfoliolistPath= new ListActions(lblErrorMessagePortfolioPath);
	
	String lblIssuerNamePath = "//*[@for='SingleHolding_IssuerCode']";
	public Label lblIssuerName = new Label(lblIssuerNamePath, LocatorType.XPATH);
	
	String lblIVCPath = "//*[@id='divHrn']/label";
	public Label lblIVC = new Label(lblIVCPath, LocatorType.XPATH);
	
	String lblPostCodePath = "(//*[@id='divInsideUk']/div/label)[1]";
	public Label lblPostCode = new Label(lblPostCodePath, LocatorType.XPATH);
	
	String lblLastNamePath = "(//*[@id='divInsideUk']/div/label)[2]";
	public Label lblLastName = new Label(lblLastNamePath, LocatorType.XPATH);
	
	String lblOutsideUKPath = "(//button[@class='linkButton']/span)[1]";
	public Label lblOutsideUK = new Label(lblOutsideUKPath, LocatorType.XPATH);
	
	public Button drpdwnIssuer;
	String drpIssuerPath;
	
	public Button dynamicIssuerDropDownSel(String drpdwnIssuervalue) {
		drpIssuerPath = "//li[div[text()='"+drpdwnIssuervalue+"']]";
		drpdwnIssuer = new Button(drpIssuerPath, LocatorType.XPATH);
		return drpdwnIssuer;
	}
	
	
	public Label lblAddHoldingInstructionslText;
	String lblAddHoldingInstructionslTextPath;
	
	public String getLablelInstructionsText() {
		lblAddHoldingInstructionslTextPath = "//*[@id='mainBody']/div[1]/div/p";
		lblAddHoldingInstructionslText = new Label(lblAddHoldingInstructionslTextPath, LocatorType.XPATH);
		   java.util.Scanner scanner = new java.util.Scanner(lblAddHoldingInstructionslText.getTextlabel());
			  StringBuffer sb = new StringBuffer();
				while (scanner.hasNextLine()) {
				  sb.append(scanner.nextLine());
				}
		return sb.toString();
	}
	
	// Android Element //
		String androidElementlblAddHoldingPath = "com.linkgroup.android_investorcentre.sit:id/toolbar_title";
		public Label androidElementlblAddHolding= new Label(androidElementlblAddHoldingPath, LocatorType.ID);
		
		String androidElementlblPleaseEnterthedetailsPath = "com.linkgroup.android_investorcentre.sit:id/titleMessage";
		public Label androidElementlblPleaseEnterthedetails= new Label(androidElementlblPleaseEnterthedetailsPath, LocatorType.ID);
		
		String androidElementselIssuerNamePath = "com.linkgroup.android_investorcentre.sit:id/edit_text";
		public Button androidElementselIssuerName = new Button(androidElementselIssuerNamePath, LocatorType.ID);
		
		String androidElementselIssuerNameInputPath = "com.linkgroup.android_investorcentre.sit:id/edit_text";
		public Input androidElementselIssuerNameInput= new Input(androidElementselIssuerNameInputPath, LocatorType.ID);
		
		String androidElementselIssuerPath = "com.linkgroup.android_investorcentre.sit:id/hin_srn_title";
		public Button androidElementselIssuer = new Button(androidElementselIssuerPath, LocatorType.ID);
		
		String androidElementInputIVCPath = "com.linkgroup.android_investorcentre.sit:id/hin_srn_value";
		public Input androidElementInputIVC = new Input(androidElementInputIVCPath, LocatorType.ID);

		String androidElementRbtnWithInUKPath = "com.linkgroup.android_investorcentre.sit:id/location_within_australia";
		public Button androidElementRbtnWithInUK = new Button(androidElementRbtnWithInUKPath, LocatorType.ID);

		String androidElementRbtnOutSideUKPath = "com.linkgroup.android_investorcentre.sit:id/location_outside_australia";
		public Button androidElementRbtnOutSideUK = new Button(androidElementRbtnOutSideUKPath, LocatorType.ID);

		String androidElementInputPostCodePath = "com.linkgroup.android_investorcentre.sit:id/etPostalCode";
		public Input androidElementInputPostCode = new Input(androidElementInputPostCodePath, LocatorType.ID);

		String androidElementInputLastNamePath = "com.linkgroup.android_investorcentre.sit:id/etLastName";
		public Input androidElementInputLastName = new Input(androidElementInputLastNamePath, LocatorType.ID);

		String androidElementbtnSubmitUKPath = "com.linkgroup.android_investorcentre.sit:id/button";
		public Button androidElementbtnSubmitUK = new Button(androidElementbtnSubmitUKPath, LocatorType.ID);	
		
		public Actions scrollUp = new Actions();
		
		String androidElementlblAddHoldingSuccessfullyPath = "//android.widget.TextView[@text='Holdings added successfully']";
		public Label androidElementlblAddHoldingSuccessfully= new Label(androidElementlblAddHoldingSuccessfullyPath, LocatorType.XPATH);

		String androidElementbtnAddHoldingSuccessfullyPath = "com.linkgroup.android_investorcentre.sit:id/button";
		public Button androidElementbtndoneHoldingSuccessfully= new Button(androidElementbtnAddHoldingSuccessfullyPath, LocatorType.ID);
		
		String androidElementInputFirstNamePath = "com.linkgroup.android_investorcentre.sit:id/etFirstName";
		public Input androidElementInputFirstName = new Input(androidElementInputFirstNamePath, LocatorType.ID);
		
		//IOS Element Input
		String iosElementlblAddHoldingPath = "//XCUIElementTypeStaticText[@name='Add holding']";
		public Label iosElementlblAddHolding= new Label(iosElementlblAddHoldingPath, LocatorType.XPATH);
		
		String iosElementbtnClosePath = "//XCUIElementTypeButton[@name='close']";
		public Button iosElementbtnClose= new Button(iosElementbtnClosePath, LocatorType.XPATH);
		
		
		String iosElementtxtIssuerNamePath = "//XCUIElementTypeTextView";
		public Button iosElementbtnIssuerName= new Button(iosElementtxtIssuerNamePath, LocatorType.XPATH);
		
		public Input iosElementtxtIssuerName= new Input(iosElementtxtIssuerNamePath, LocatorType.XPATH);
		
//		String iosElementSelIssuerNamePath = "//XCUIElementTypeStaticText[@name='ASE - Asite Limited']";
		String iosElementSelIssuerNamePath = "//XCUIElementTypeStaticText[@name='ECK - Eckoh Plc']";
		public Button iosElementSelIssuerName= new Button(iosElementSelIssuerNamePath, LocatorType.XPATH);
		
		String iosElementtxtIVCPath = "//XCUIElementTypeTextField[@value='IVC']";
		public Input iosElementtxtIVC= new Input(iosElementtxtIVCPath, LocatorType.XPATH);
		
		String iosElementbtnWithINUKPath = "//XCUIElementTypeStaticText[@name='Within UK']";
		public Button iosElementbtnWithINUK= new Button(iosElementbtnWithINUKPath, LocatorType.XPATH);

		String iosElementbtnOutsideUKPath = "//XCUIElementTypeStaticText[@name='Outside UK']";
		public Button iosElementbtnOutsideUK= new Button(iosElementbtnOutsideUKPath, LocatorType.XPATH);
		
		String iosElementTxtPostCodePath = "//XCUIElementTypeTextField[@value='Postcode']";
		public Input iosElementTxtPostCode= new Input(iosElementTxtPostCodePath, LocatorType.XPATH);
		
		String iosElementTxtLastNamePath = "//XCUIElementTypeTextField[@value='Last Name']";
		public Input iosElementTxtLastName= new Input(iosElementTxtLastNamePath, LocatorType.XPATH);
		
		String iosElementTxtFirstNamePath = "//XCUIElementTypeTextField[@value='First name']";
		public Input iosElementTxtFirstName= new Input(iosElementTxtFirstNamePath, LocatorType.XPATH);
		
		String iosElementBtnSubmitUKPath = "//XCUIElementTypeStaticText[@name='Submit']";
		public Button iosElementBtnSubmitUK= new Button(iosElementBtnSubmitUKPath, LocatorType.XPATH);
		
		String iosElementlblAddHoldingSuccessfullyPath = "//XCUIElementTypeStaticText[@name='Holdings Added Successfully']";
		public Label iosElementlblAddHoldingSuccessfully= new Label(iosElementlblAddHoldingSuccessfullyPath, LocatorType.XPATH);

		String iosElementBtnDoneUKPath = "//XCUIElementTypeButton[@name='Done']";
		public Button iosElementBtnDoneUK= new Button(iosElementBtnDoneUKPath, LocatorType.XPATH);
		
}
