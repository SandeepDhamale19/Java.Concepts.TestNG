package pageObject;


import ActionsFactory.JavascriptExecutorfunction;
import ActionsFactory.ListActions;
import ActionsFactory.WindowsFactory;
import ElementsFactory.Actions;
import ElementsFactory.Button;
import ElementsFactory.Input;
import ElementsFactory.Label;
import ElementsFactory.Select;
import Selenium.LocatorType;

public class VotingPage {
	
	public WindowsFactory windowsFactory = new WindowsFactory();

	String btnvotingmenuPath = "//div//a[text()='Voting']";
	public ListActions btnlstvotingmenu= new ListActions(btnvotingmenuPath);
	public Button btnvotingmenu = new Button(btnvotingmenuPath, LocatorType.XPATH);
	
	String btnDiscretionaryradiobtnpath = "//input[@value='Open']";
	public ListActions btnDiscretionaryradiobtn= new ListActions(btnDiscretionaryradiobtnpath);
	
	String lblInstructionalTextPath = "//form[@id='ProxyVotingListForm']//..//preceding-sibling::p";
	public Label lblInstructionalText= new Label(lblInstructionalTextPath,LocatorType.XPATH);
	
	String btnPrinterPath = "//a[@id='printLink']";
	public Button btnPrinter= new Button(btnPrinterPath,LocatorType.XPATH);
	
	String lblIssuerPath = "//table//tr[1]//th[2]";
	public Label lblIssuer= new Label(lblIssuerPath,LocatorType.XPATH);
	
	String btninfodisplayPath = "//table";
	public Button btninfodisplay= new Button(btninfodisplayPath,LocatorType.XPATH);
	
	String btninfodisplay1Path = "(//table)[1]";
	public Button gridinfodisplay= new Button(btninfodisplay1Path,LocatorType.XPATH);
	
	String btninfodisplay2Path = "(//table)[2]";
	public Button gridinfodisplay1= new Button(btninfodisplay2Path,LocatorType.XPATH);
	
	String btnagainstPath = "//table//tr//th[2]";
	public Button btnagainst= new Button(btnagainstPath,LocatorType.XPATH);
	
	String btnWithheldPath = "//table//tr//th[3]";
	public Button btnWithheld= new Button(btnWithheldPath,LocatorType.XPATH);
	
	String btnbackPath = "//button[@id='btnCancel']";
	public Button btnback= new Button(btnbackPath,LocatorType.XPATH);
	public JavascriptExecutorfunction btnbackAction= new JavascriptExecutorfunction(btnbackPath, LocatorType.XPATH);
	
	String btnbackPath1 = "//button[@id='btnBack']";
	public Button btnback1= new Button(btnbackPath1,LocatorType.XPATH);
	
	String btndonePath = "//button[@id='btnOK']";
	public Button btndone= new Button(btndonePath,LocatorType.XPATH);
	
	String btnsubmitPath = "//button[@id='btnSubmit']";
	public Button btnsubmit= new Button(btnsubmitPath,LocatorType.XPATH);
	
	String btnnextmeetingPath = "//button[@id='btnNextMeeting']";
	public Button btnnextmeeting= new Button(btnnextmeetingPath,LocatorType.XPATH);
	
	String btnyesPath = "//input[@label='Yes']";
	public Button radiobtnyes= new Button(btnyesPath,LocatorType.XPATH);
	
	String btncharirmanPath = "//input[@id='ProxyType_1']";
	public Button btncharirman= new Button(btncharirmanPath,LocatorType.XPATH);
	
	String btnrtnmeetinglistPath = "//button[@id='btnReturnMeetingList']";
	public Button btnrtnmeetinglist= new Button(btnrtnmeetinglistPath,LocatorType.XPATH);
	
	String btnsubmitanotherquestionPath = "//button[@id='btnSubmitAnotherQuestions']";
	public Button btnsubmitanotherquestion= new Button(btnsubmitanotherquestionPath,LocatorType.XPATH);
	
	String btnanotherpersonPath = "//input[@id='ProxyType_2']";
	public Button btnanotherperson= new Button(btnanotherpersonPath,LocatorType.XPATH);
	
	String firstnametextboxPath = "//input[@id='FirstName']";
	public Input firstnametextbox= new Input(firstnametextboxPath,LocatorType.XPATH);
	
	String LastnametextboxPath = "//input[@id='LastName']";
	public Input Lastnametextbox= new Input(LastnametextboxPath,LocatorType.XPATH);
	
	String ReferenceidtextboxPath = "//input[@id='ProxyEmailAddress']";
	public Input Referenceidtextbox= new Input(ReferenceidtextboxPath,LocatorType.XPATH);
	
	String questiontextboxPath = "//textarea[@id='QuestionText']";
	public Input questiontextbox= new Input(questiontextboxPath,LocatorType.XPATH);
	
	String btnNoPath = "//input[@label='No']";
	public Button radiobtnno= new Button(btnNoPath,LocatorType.XPATH);
	
	String btnnextPath1 = "//button[@id='btnUpdate']";
	public Button btnnext1= new Button(btnnextPath1,LocatorType.XPATH);
	
	String btnnextPath = "//button[@id='btnOk']";
	public Button btnnext= new Button(btnnextPath,LocatorType.XPATH);
	
	String btntickPath = "//span[@class='tick']";
	public Button btntick= new Button(btntickPath,LocatorType.XPATH);
	
	String btnnextPath2 = "//button[@id='btnNext']";
	public Button btnnext2= new Button(btnnextPath2,LocatorType.XPATH);
	
	String lbloptionPath = "//select[@id='ViewKey']/option";
	public Label lblOption= new Label(lbloptionPath,LocatorType.XPATH);
	
	String selquestionforPath = "//select[@id='QuestionForName']";
	public Select selquestionfor = new Select(selquestionforPath, LocatorType.XPATH);
	
	String lblForPath = "//table//tr//th[contains(text(),'For')]";
	public Label lblFor= new Label(lblForPath,LocatorType.XPATH);
	
	String lblAgainstPath = "//table//tr//th[contains(text(),'Against')]";
	public Label lblAgainst= new Label(lblAgainstPath,LocatorType.XPATH);
	
	String lblDiscretionaryPath = "//table//tr//th[contains(text(),'Discretionary')]";
	public Label lblDiscretionary= new Label(lblDiscretionaryPath,LocatorType.XPATH);
	
	String lblheaderPath = "//h1";
	public Label lblheader= new Label(lblheaderPath,LocatorType.XPATH);
	public JavascriptExecutorfunction btnheader= new JavascriptExecutorfunction(lblheaderPath, LocatorType.XPATH);
	
	String lblsubheaderPath = "(//h2)[3]";
	public Label lblsubheader= new Label(lblsubheaderPath,LocatorType.XPATH);
	
	String lblinstructionaltextPath1 = "//form//p";
	public Button lblinstructionaltext1= new Button(lblinstructionaltextPath1,LocatorType.XPATH);
	
	String lblinstructionaltextPath4 = "(//form//p)[2]";
	public Button lblinstructionaltext4= new Button(lblinstructionaltextPath4,LocatorType.XPATH);
	
	String lblinstructionaltextPath2 = "//form//div//p";
	public Button lblinstructionaltext2= new Button(lblinstructionaltextPath2,LocatorType.XPATH);
	public JavascriptExecutorfunction lblinstructional= new JavascriptExecutorfunction(lblinstructionaltextPath2, LocatorType.XPATH);
	
	String lblinstructionaltextPath3 = "(//p//strong)[2]";
	public Button lblinstructionaltext3= new Button(lblinstructionaltextPath3,LocatorType.XPATH);
	
	public JavascriptExecutorfunction btnsubheaderAction= new JavascriptExecutorfunction(lblsubheaderPath, LocatorType.XPATH);
	
	String lblsubheader1Path = "(//h2)[2]";
	public Label lblsubheader1= new Label(lblsubheader1Path,LocatorType.XPATH);
	public JavascriptExecutorfunction btnsubheader1= new JavascriptExecutorfunction(lblsubheader1Path, LocatorType.XPATH);
	
	String lblsubheader3Path = "(//h2)[3]";
	public Label lblsubheader3= new Label(lblsubheader3Path,LocatorType.XPATH);
	
	String lblsubheader2Path = "//div[@class='borderDiv']//p";
	public Label lblsubheader2= new Label(lblsubheader2Path,LocatorType.XPATH);
	
	String lblnotetextPath = "//div[@class='buttonsPanel']//..//preceding-sibling::p//label";
	public Label lblnotetext= new Label(lblnotetextPath,LocatorType.XPATH);
	
	String lblinstructionaltextPath = "//div[@id='chairmanText']/p";
	public Label lblinstructionaltext= new Label(lblinstructionaltextPath,LocatorType.XPATH);
	
	String lblinstrTextPath = "//b";
	public Label lblinstrText= new Label(lblinstrTextPath,LocatorType.XPATH);
	
	String btndropdownpath = "//select[@id='ViewKey']";
	public Button btndropdown= new Button(btndropdownpath,LocatorType.XPATH);
	
	String selAllHoldingPath = "//select[@id='ViewKey']";
	public Select selAllHolding = new Select(selAllHoldingPath, LocatorType.XPATH);
	
	String btnvotePath = "//table//tr[2]//td[13]//a[@class='VotingActionLink']";
	public Button btnvote = new Button(btnvotePath, LocatorType.XPATH);
	
	String btnaskquestionPath = "//table//tr[2]//td//a[@class='AskQuestion']";
	public Button btnaskquestion = new Button(btnaskquestionPath, LocatorType.XPATH);
	
	String lblmeetingnamePath = "//table//tbody//tr[1]//th[1]";
	public Label lblmeetingname= new Label(lblmeetingnamePath,LocatorType.XPATH);
	public JavascriptExecutorfunction btnmeetingname= new JavascriptExecutorfunction(lblmeetingnamePath, LocatorType.XPATH);
	
	public Actions scrolltoElement = new Actions();
}
