package pageObject;

import ElementsFactory.*;
import ActionsFactory.ListActions;
import ActionsFactory.ValidateLabelUI;
import Selenium.LocatorType;

public class PortfolioPage {

	String  lblIVC  = "//table[@id='MyHoldingsGrid']/tbody/tr/td[@aria-describedby='MyHoldingsGrid_IVC']";
	public Label lblIVCno= new Label(lblIVC,LocatorType.XPATH);
	
	String lblRegisteredDetails1 = "(//table[@id='MyHoldingsGrid']/tbody/tr/td/span[@class='tooltip'])[1]";
	public ValidateLabelUI lblRegisteredDetailsName= new ValidateLabelUI(lblRegisteredDetails1,LocatorType.XPATH);
	
	String lnkViewDetail = "//table[@id='MyHoldingsGrid']/tbody/tr/td[@aria-describedby=\"MyHoldingsGrid_Action\"]/a[@class='holdingDetailLink']";
	public Button lnkViewDetails= new Button(lnkViewDetail, LocatorType.XPATH);
	
	String tabCommunicationsPath  = "//*[@class='topMenu' and text()='Communications']";
	public Actions tabCommunications = new Actions(tabCommunicationsPath, LocatorType.XPATH);
	
	String tabPreferencesPath = "//*[text()='Preferences']";
	public Button tabPreferences = new Button(tabPreferencesPath, LocatorType.XPATH);
	
	String tabAddressDetailsPath = "//*[text()='Address Details']";
	public Button tabAddressDetails = new Button(tabAddressDetailsPath, LocatorType.XPATH);
	
	String tabHoldingsPath = "//*[text()='Holdings']";
	public Actions tabHoldings = new Actions(tabHoldingsPath, LocatorType.XPATH);
	
	String tabTransactionHistoryPath = "//*[text()='Transaction History']";
	public Button tabTransactionHistory = new Button(tabTransactionHistoryPath, LocatorType.XPATH);
	
	String tabBalanceHistoryPath = "//*[text()='Balance History']";
	public Button tabBalanceHistory = new Button(tabBalanceHistoryPath, LocatorType.XPATH);
	
	String tabPortfolioPath = "//*[text()='Portfolio']";
	public Button tabPortfolio = new Button(tabPortfolioPath, LocatorType.XPATH);
	
	String tabPaymentPath = "//*[text()='Payments']";
	public Actions tabPayment = new Actions(tabPaymentPath, LocatorType.XPATH);
	
	String tabPaymentInstructionsPath = "//*[text()='Payment Instructions']";
	public Actions tabPaymentInstructions = new Actions(tabPaymentInstructionsPath, LocatorType.XPATH);
	
	String tabPaymentHistoryPath = "//*[text()='Payment History']";
	public Button tabPaymentHistory = new Button(tabPaymentHistoryPath, LocatorType.XPATH);
	
	String btnNewHoldingPath = "//button[@id='btnNewHolding']";
	public Button btnNewHolding = new Button(btnNewHoldingPath, LocatorType.XPATH);
	
	String btnManagePortfolioPath = "//button[@id='btnEditPortfolio']";
	public Button btnManagePortfolio = new Button(btnManagePortfolioPath, LocatorType.XPATH);
	
	String btnBackToPortfolioPath = "//*[@id='btnBackToPortfolio']";
	public Button btnBackToPortfolio = new Button(btnBackToPortfolioPath, LocatorType.XPATH);
	
	String btnLogoutPath = "//a[text()='Logout']";
	public Button btnLogout = new Button(btnLogoutPath, LocatorType.XPATH);
	
	String lblWelcomeToLinkICPath = "//h1[@class='login-welcome-title']";
	public Label lblWelcomeToLink = new Label(lblWelcomeToLinkICPath,LocatorType.XPATH);
	
	String lblAllHoldingPath = "//span[@id='viewName']";
	public Label lblAllHolding = new Label(lblAllHoldingPath,LocatorType.XPATH);
	
	String lblAllHoldingsIVCPath = "//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[3]";
	public ListActions lblAllHoldingsIVC = new ListActions(lblAllHoldingsIVCPath); 
	
	String lblRegisteredDetailsPath = "//table[@aria-labelledby='gbox_MyHoldingsGrid']/tbody/tr/td[4]";
	public ListActions lblRegisteredDetails = new ListActions(lblRegisteredDetailsPath); 
	
	
	String lblColHeaderPath = "//div[@id='jqgh_IVC']";
	public Label lblColHeader = new Label(lblColHeaderPath,LocatorType.XPATH);
	
	String lblColRegDetailsPath = "//div[@id='jqgh_Registered Details']";
	public Label lblColRegDetails = new Label(lblColRegDetailsPath,LocatorType.XPATH);

	String lblColSecurityCodePath = "(//div[contains(@id,'jqgh_Security')])[1]";
	public Label lblColSecurityCode = new Label(lblColSecurityCodePath,LocatorType.XPATH);
	
	String lblLastCodeGBP = "(//div[@id='jqgh_GBP'])[1]";
	public Label lblLastCode = new Label(lblLastCodeGBP,LocatorType.XPATH);
	
	String lblBalancePath = "//div[@id='jqgh_Balance']";
	public Label lblBalance = new Label(lblBalancePath,LocatorType.XPATH);
	
	String lblLastCodeGBP2Path = "(//div[@id='jqgh_GBP'])[2]";
	public Label lblLastCodeGBP2 = new Label(lblLastCodeGBP2Path,LocatorType.XPATH); 	
	
	String lblActionPath = "//div[@id='jqgh_Action']";
	public Label lblAction = new Label(lblActionPath,LocatorType.XPATH);
	
	String lblTotalIsDisplayedPath = "//span[@id=\"gridTotal\"]";
	public Label lblTotalIsDisplayed = new Label(lblTotalIsDisplayedPath,LocatorType.XPATH);
	
	String lblNoHoldingsPath = "//span[@class='fieldvalue']";
	public Label lblNoHoldings = new Label(lblNoHoldingsPath,LocatorType.XPATH);
	
	String lblNoRecordsfoundPath = "//table[@class='noRecords']/tbody/tr/td";
	public Label lblNoRecordsfound = new Label(lblNoRecordsfoundPath,LocatorType.XPATH);
	
	
	//Android Elements UI //
	String androidElementlblIssuerPath ="com.linkgroup.android_investorcentre.sit:id/code";
	public Label androidElementlblIssuer = new Label(androidElementlblIssuerPath,LocatorType.ID);
	
	String androidElementlblIssuerValuePath ="com.linkgroup.android_investorcentre.sit:id/value";
	public Label androidElementlblIssuerValue = new Label(androidElementlblIssuerValuePath,LocatorType.ID);
	
	String androidElementlblIssuerNamePath ="com.linkgroup.android_investorcentre.sit:id/name";
	public Label androidElementlblIssuerName = new Label(androidElementlblIssuerNamePath,LocatorType.ID);
	
	String androidElementlblTotlaPortfolioValuePath ="com.linkgroup.android_investorcentre.sit:id/total_value_label";
	public Label androidElementlblTotlaPortfolioValue = new Label(androidElementlblTotlaPortfolioValuePath,LocatorType.ID);
	
	String androidElementlblTotlaPortfolioInvestorValuePath ="com.linkgroup.android_investorcentre.sit:id/total_value_investor";
	public Label androidElementlblTotlaPortfolioInvestorValue = new Label(androidElementlblTotlaPortfolioInvestorValuePath,LocatorType.ID);
	
	
	//
	String androidElementbtnchecvronIndividualuserPath = "com.linkgroup.android_investorcentre.sit:id/chevron";
	public Button androidElementbtnchecvronIndividualuser= new Button(androidElementbtnchecvronIndividualuserPath , LocatorType.ID);
 
	String androidElementbtnchecvronIndividualHoldingPath = "com.linkgroup.android_investorcentre.sit:id/chevron";
	public Button androidElementbtnchecvronIndividualHolding = new Button(androidElementbtnchecvronIndividualHoldingPath , LocatorType.ID);
 
	String androidElementbtnHoldingCardPath = "com.linkgroup.android_investorcentre.sit:id/holdings_option_label";
	public Button androidElementbtnHoldingCard = new Button(androidElementbtnHoldingCardPath , LocatorType.ID);
	
	String androidElementbtnCommunicationcardPath = "com.linkgroup.android_investorcentre.sit:id/communication_option_label";
	public Button androidElementbtnCommunicationcard = new Button(androidElementbtnCommunicationcardPath , LocatorType.ID);
	
	String androidElementlblTransactionPath = "//android.widget.TextView[@text='Transactions']";
	public Label androidElementlblTransaction= new Label(androidElementlblTransactionPath, LocatorType.XPATH);
 
	String androidElementlblBalancePath = "com.linkgroup.android_investorcentre.sit:id/balance_label";
	public Label androidElementlblBalance= new Label(androidElementlblBalancePath, LocatorType.ID);
 
	String androidElementlblBalancelblPath = "com.linkgroup.android_investorcentre.sit:id/tradable_balance_label";
	public Label androidElementlblBalancelbl= new Label(androidElementlblBalancelblPath, LocatorType.ID);
 
	String androidElementlblBalancevaluePath = "com.linkgroup.android_investorcentre.sit:id/tradable_balance_value";
	public Label androidElementlblBalancevalue= new Label(androidElementlblBalancevaluePath, LocatorType.ID);
	
	public Actions scroll = new Actions();
	
	
			//Label
			String androidElementlblCommunicationOptionLabelPath  = "com.linkgroup.android_investorcentre.sit:id/communication_options_label";
			public Label androidElementlblCommunicationOptionLabel = new Label(androidElementlblCommunicationOptionLabelPath, LocatorType.ID);
			//Button
			String androidElementbtnCommOptionEditPath = "com.linkgroup.android_investorcentre.sit:id/communication_options_edit";
			public Button androidElementbtnCommOptionEdit = new Button(androidElementbtnCommOptionEditPath, LocatorType.ID);
			//email
			String androidElementlblCommEmailPath = "com.linkgroup.android_investorcentre.sit:id/email";
			public Label androidElementlblCommEmail= new Label(androidElementlblCommEmailPath, LocatorType.ID);
			//Option	
			String androidElementlblCommOptionElectronicPath = "com.linkgroup.android_investorcentre.sit:id/option";
			public Label androidElementlblCommOptionElectronic= new Label(androidElementlblCommOptionElectronicPath, LocatorType.ID);
	
			//Label
			String androidElementlblAddressDetailsPath  = "com.linkgroup.android_investorcentre.sit:id/address_label";
			public Label androidElementlblAddressDetails = new Label(androidElementlblAddressDetailsPath, LocatorType.ID);
			
			//Label
			String androidElementlblAddressPath= "com.linkgroup.android_investorcentre.sit:id/address";
			public Label androidElementlblAddress = new Label(androidElementlblAddressPath, LocatorType.ID);
			
			//Button	
			String androidElementbtnAddressDetailsEditPath = "com.linkgroup.android_investorcentre.sit:id/address_edit";
			public Button androidElementbtnAddressDetailsEdit = new Button(androidElementbtnAddressDetailsEditPath, LocatorType.ID);
			
			//---------------------------------------------------------------------------------------------------
			
			String androidElementlblAddressDetailsTitlePath= "com.linkgroup.android_investorcentre.sit:id/address_details_title";
			public Label androidElementlblAddressDetailsTitle = new Label(androidElementlblAddressDetailsTitlePath, LocatorType.ID);
			
			String androidElementlblViewByPath= "com.linkgroup.android_investorcentre.sit:id/view_by_label";
			public Label androidElementlblViewBy = new Label(androidElementlblViewByPath, LocatorType.ID);
	 
			String androidElementlblEnteryourDetailsPath= "//android.widget.TextView[@text='Enter your address details:']";
			public Label androidElementlblEnteryourDetails = new Label(androidElementlblEnteryourDetailsPath, LocatorType.XPATH);
	 
			String androidElementlbllocationTitlePath= "com.linkgroup.android_investorcentre.sit:id/location_title";
			public Label androidElementlbllocationTitle = new Label(androidElementlbllocationTitlePath, LocatorType.ID);		
			
			String androidElementlblWininUKPath= "com.linkgroup.android_investorcentre.sit:id/location_within_uk_ireland";
			public Label androidElementlblWininUK = new Label(androidElementlblWininUKPath, LocatorType.ID);		
			
			String androidElementbtnWininUKPath= "com.linkgroup.android_investorcentre.sit:id/location_within_uk_ireland";
			public Button androidElementbtnWininUK = new Button(androidElementbtnWininUKPath, LocatorType.ID);		
			
			String androidElementlblOutSideUKPath = "com.linkgroup.android_investorcentre.sit:id/location_outside_uk_ireland";
			public Label androidElementlblOutSideUK = new Label(androidElementlblOutSideUKPath, LocatorType.ID);
			
			String androidElementbtnOutSideUKPath = "com.linkgroup.android_investorcentre.sit:id/location_outside_uk_ireland";
			public Button androidElementbtnOutSideUK = new Button(androidElementbtnOutSideUKPath, LocatorType.ID);
			
			String androidElementlblStreetAddressPath = "//android.widget.TextView[@text='Street Address']";
			public Label androidElementlblStreetAddress = new Label(androidElementlblStreetAddressPath, LocatorType.XPATH);
			
			String androidElementlblStreetAddressLin1Path = "com.linkgroup.android_investorcentre.sit:id/street_address";
			public Input androidElementlblStreetAddressLin1 = new Input(androidElementlblStreetAddressLin1Path, LocatorType.ID);
			
			String androidElementlblStreetAddressLin2Path = "com.linkgroup.android_investorcentre.sit:id/street_address_2";
			public Input androidElementlblStreetAddressLin2 = new Input(androidElementlblStreetAddressLin2Path, LocatorType.ID);
			
			String androidElementlblStreetAddressLin3Path = "com.linkgroup.android_investorcentre.sit:id/street_address_3";
			public Input androidElementlblStreetAddressLin3 = new Input(androidElementlblStreetAddressLin3Path, LocatorType.ID);
			
			String androidElementlblStreetAddressLin4Path = "com.linkgroup.android_investorcentre.sit:id/street_address_4";
			public Input androidElementlblStreetAddressLin4 = new Input(androidElementlblStreetAddressLin4Path, LocatorType.ID);
			
			String androidElementlblStreetAddressLin5Path = "com.linkgroup.android_investorcentre.sit:id/street_address_5";
			public Input androidElementlblStreetAddressLin5 = new Input(androidElementlblStreetAddressLin5Path, LocatorType.ID);
			
			String androidElementlblPOstalCodePath  = "com.linkgroup.android_investorcentre.sit:id/postcode_label";
			public Label androidElementlblPOstalCode = new Label(androidElementlblPOstalCodePath, LocatorType.ID);		
			
			String androidElementInputPostalCodePath = "com.linkgroup.android_investorcentre.sit:id/postcode";
			public Input androidElementInputPostalCode = new Input(androidElementInputPostalCodePath, LocatorType.ID);
			
			String androidElementlblupdateSettingspath = "//android.widget.TextView[@text='Update settings']";
			public Label androidElementlblupdateSettings = new Label(androidElementlblupdateSettingspath, LocatorType.XPATH);	
			
			String androidElementlblapplytoallHoldingspath = "com.linkgroup.android_investorcentre.sit:id/apply_to_all";
			public Label androidElementlblapplytoallHoldings = new Label(androidElementlblapplytoallHoldingspath, LocatorType.ID);	
			
			String androidElementbtnapplytoallHoldingspath = "com.linkgroup.android_investorcentre.sit:id/apply_to_all";
			public Button androidElementbtnapplytoallHoldings = new Button(androidElementbtnapplytoallHoldingspath, LocatorType.ID);	
			
			String androidElementlblapplytoIndividualHoldingspath = "com.linkgroup.android_investorcentre.sit:id/apply_to_individual_holding_toggle";
			public Label androidElementlblapplytoIndividualHolding = new Label(androidElementlblapplytoIndividualHoldingspath, LocatorType.ID);	
			
			String androidElementbtnapplytoIndividualHoldingspath = "com.linkgroup.android_investorcentre.sit:id/apply_to_individual_holding_toggle";
			public Button androidElementbtnapplytoIndividualHoldings = new Button(androidElementbtnapplytoIndividualHoldingspath, LocatorType.ID);	
			
			//Update Button
			String androidElementbtnUdpateButtonPortfolioPath = "com.linkgroup.android_investorcentre.sit:id/button";
			public Button androidElementbtnUdpateButtonPortfolio = new Button(androidElementbtnUdpateButtonPortfolioPath, LocatorType.ID);
			
			//Confirmation Screen
			String androidElementlblConfirmationScreenpath = "//android.widget.TextView[@text='Confirm']";
			public Label androidElementlblConfirmationScreen = new Label(androidElementlblConfirmationScreenpath, LocatorType.XPATH);	
			
			String androidElementlblPleaseConfirmthatyouwanttoProceedpath = "//android.widget.TextView[@text='Please confirm that you want to proceed with the following updates.']";
			public Label androidElementlblPleaseConfirmthatyouwanttoProceed = new Label(androidElementlblPleaseConfirmthatyouwanttoProceedpath, LocatorType.XPATH);	
			
			String androidElementlblComfirmAddressDetailsPath = "//android.widget.TextView[@text='Address']";
			public Label androidElementlblComfirmAddressDetails = new Label(androidElementlblComfirmAddressDetailsPath, LocatorType.XPATH);	

			String androidElementlblAddressdataDetailsPath = "com.linkgroup.android_investorcentre.sit:id/address";
			public Label androidElementlblAddressdataDetails = new Label(androidElementlblAddressdataDetailsPath, LocatorType.ID);	
					
			String androidElementlblAddressdataApplyToPath = "com.linkgroup.android_investorcentre.sit:id/apply_to_label";
			public Label androidElementlblAddressdataApplyTo = new Label(androidElementlblAddressdataApplyToPath, LocatorType.ID);	

			String androidElementlblIVCPath = "com.linkgroup.android_investorcentre.sit:id/hin_srn_label";
			public Label androidElementlblIVC = new Label(androidElementlblIVCPath, LocatorType.ID);	
			
			String androidElementlblRegisteredHolderPath = "com.linkgroup.android_investorcentre.sit:id/registration_details_label";
			public Label androidElementlblRegisteredHolder = new Label(androidElementlblRegisteredHolderPath, LocatorType.ID);	

			String androidElementconfirmlblIssuerPath = "com.linkgroup.android_investorcentre.sit:id/issuer_label";
			public Label androidElementconfirmlblIssuer = new Label(androidElementconfirmlblIssuerPath, LocatorType.ID);	
			
			//Confirm Button
			String androidElementbtnConfirmPortfolioPath = "com.linkgroup.android_investorcentre.sit:id/button";
			public Button androidElementbtnConfirmPortfolio = new Button(androidElementbtnConfirmPortfolioPath, LocatorType.ID);
			
			//Success Screen
			String androidElementlblSuccessPath = "com.linkgroup.android_investorcentre.sit:id/success_title";
			public Label androidElementlblSuccess = new Label(androidElementlblSuccessPath, LocatorType.ID);	

			String androidElementlblAddressdetailsPath = "com.linkgroup.android_investorcentre.sit:id/message";
			public Label androidElementlblAddressdetails = new Label(androidElementlblAddressdetailsPath, LocatorType.ID);	

			String androidElementlblAletterwillbesentPath = "com.linkgroup.android_investorcentre.sit:id/sub_message";
			public Label androidElementlblAletterwillbesent = new Label(androidElementlblAletterwillbesentPath, LocatorType.ID);	

			//Click on Done Button
			String androidElementbtnDonePortfolioPath = "com.linkgroup.android_investorcentre.sit:id/back_btn";
			public Button androidElementbtnDonePortfolio = new Button(androidElementbtnDonePortfolioPath, LocatorType.ID);
			
			
			//Label
			String androidElementlblIndividuallySelectHoldingPath= "com.linkgroup.android_investorcentre.sit:id/apply_to_individual_holding";
			public Label androidElementlblIndividuallySelectHolding = new Label(androidElementlblIndividuallySelectHoldingPath, LocatorType.ID);
			
			//Button
			String androidElementbtnIndividuallySelectHoldingPath= "com.linkgroup.android_investorcentre.sit:id/apply_to_individual_holding";
			public Button androidElementbtnIndividuallySelectHolding = new Button(androidElementbtnIndividuallySelectHoldingPath, LocatorType.ID);
			
			
			
			
			//Change address details //Address details
			String androidElementlblAddresspopupUIdetailsPath= "com.linkgroup.android_investorcentre.sit:id/title";
			public Label androidElementlblAddresspopupUIdetails = new Label(androidElementlblAddresspopupUIdetailsPath, LocatorType.ID);
			
			//Individual holdings
			String androidElementlblIndividualHoldingPath= "com.linkgroup.android_investorcentre.sit:id/individual_holdings_label";
			public Label androidElementlblIndividualHolding = new Label(androidElementlblIndividualHoldingPath, LocatorType.ID);
			
			//Toggle Button is displayed
			String androidElementlblsrnswitchPath= "com.linkgroup.android_investorcentre.sit:id/hin_srn_switch";
			public Button androidElementlblsrnswitch = new Button(androidElementlblsrnswitchPath, LocatorType.ID);
			
			//Label	// Registered holder
			String androidElementlblregisteredHolderPath= "com.linkgroup.android_investorcentre.sit:id/registration_details_label";
			public Label androidElementlblregisteredHolde = new Label(androidElementlblregisteredHolderPath, LocatorType.ID);

			//Label //  com.linkgroup.android_investorcentre.sit:id/issuer_label //Issuer
			String androidElementlblAddressIssuerPath= "com.linkgroup.android_investorcentre.sit:id/issuer_label";
			public Label androidElementlblAddressIssuer = new Label(androidElementlblAddressIssuerPath, LocatorType.ID);

			//Label //com.linkgroup.android_investorcentre.sit:id/current_option_label //Address
			String androidElementlblChangeAddressPath= "com.linkgroup.android_investorcentre.sit:id/current_option_label";
			public Label androidElementlblChangeAddress = new Label(androidElementlblChangeAddressPath, LocatorType.ID);
			
			//Button Back
			String androidElementApplybtnPath= "com.linkgroup.android_investorcentre.sit:id/button";
			public Button androidElementApplybtn = new Button(androidElementApplybtnPath, LocatorType.ID);
			
			//Button Back
			String androidElementbtnBackPath= "com.linkgroup.android_investorcentre.sit:id/back_btn";
			public Button androidElementbtnBack = new Button(androidElementbtnBackPath, LocatorType.ID);

			//Communications Option Edit Button
			String androidElementbtnCommunicationOptionEditPath= "com.linkgroup.android_investorcentre.sit:id/communication_options_edit";
			public Button androidElementbtnCommunicationOptionEdit = new Button(androidElementbtnCommunicationOptionEditPath, LocatorType.ID);

			String iosElementlblPOrtfolioPath = "//XCUIElementTypeStaticText[@name='PORTFOLIO']";
			public Label iosElementlblPOrtfolio = new Label(iosElementlblPOrtfolioPath, LocatorType.XPATH);
			
			String iosElementlblAddHoldingPath = "//XCUIElementTypeStaticText[@name='Add holding']";
			public Label iosElementlblAddHolding = new Label(iosElementlblAddHoldingPath, LocatorType.XPATH);
			
			String iosElementbtnAcctountMenuPath = "//XCUIElementTypeButton[@name='menu']";
			public Button iosElementbtnAcctountMenu = new Button(iosElementbtnAcctountMenuPath, LocatorType.XPATH);
			
			String iosElementlblTotlaPortfolioValuePath = "//XCUIElementTypeStaticText[@name='Total portfolio value (G B P)']";
			public Label iosElementlblTotlaPortfolioValue = new Label(iosElementlblTotlaPortfolioValuePath, LocatorType.XPATH);

			String iosElementlblIssuerNamePath ="(//XCUIElementTypeStaticText)[5]";
			public Label iosElementlblIssuerName = new Label(iosElementlblIssuerNamePath,LocatorType.XPATH);
			
			String iosElementlblIssuerValuePath ="(//XCUIElementTypeStaticText)[7]";
			public Label iosElementlblIssuerValue = new Label(iosElementlblIssuerValuePath,LocatorType.XPATH);

			String iosElementlblTotlaPortfolioInvestorValuePath ="(//XCUIElementTypeStaticText)[3]";
			public Label iosElementlblTotlaPortfolioInvestorValue = new Label(iosElementlblTotlaPortfolioInvestorValuePath,LocatorType.XPATH);
			
			String iosElementlblIssuerNamelist1Path = "(//XCUIElementTypeStaticText)[8]";
			public Label iosElementlblIssuerNamelist1 = new Label(iosElementlblIssuerNamelist1Path, LocatorType.XPATH);

			
}		

