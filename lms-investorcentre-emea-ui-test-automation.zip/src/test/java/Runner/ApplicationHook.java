/**
 * 
 */
package Runner;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import DriverFactory.KillDriver;
import DriverFactory.LaunchDriver;
import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalDriver;
import ScreenshotFactory.TakeScreenshot;
import ScreenshotFactory.TakeScreenshotAndroid;
import Utilities.TestNGParameterConfig;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.Scenario;

/**
 * @author Varun Paranganath
 *26/05/2023
 *TestAutomationFramework
 */
public class ApplicationHook {

	@Before
	public void BeforeScenario(Scenario scenario) throws Exception{
		if (TestNGParameterConfig.getExecuteOnBrowserStack().equals("Yes")) {
			switch (TestNGParameterConfig.getBrowserType()) {
			case "Chrome":
				 ExtentCucumberAdapter.addTestStepLog("<span class=\"badge log pass-bg mr-2\"> Start Thread Id "+Thread.currentThread().getId()+"</span>");
					System.out.println("Before Hooks"+TestNGParameterConfig.getBrowserType());
					String url = TestNGParameterConfig.getsitURL();
					System.out.println(url);
					LaunchDriver.LaunchBrowserStack(url);
				break;
			case "androiddevice":
				 ExtentCucumberAdapter.addTestStepLog("<span class=\"badge log pass-bg mr-2\"> Start Thread Id "+Thread.currentThread().getId()+"</span>");
					System.out.println("Before Hooks"+TestNGParameterConfig.getBrowserType());
					LaunchDriver.LaunchAndroidApplication();
				break;	
			default:
				break;
			}
		}else {
			ExtentCucumberAdapter.addTestStepLog("<span class=\"badge log pass-bg mr-2\"> Start Thread Id "+Thread.currentThread().getId()+"</span>");
			System.out.println("Before Hooks"+TestNGParameterConfig.getBrowserType());
			String url = TestNGParameterConfig.getsitURL();
			String driver = TestNGParameterConfig.getBrowserType();
			System.out.println(url);
			LaunchDriver.LaunchApplication(url,driver);
		}
	}

	@After
	public void AfterScenario() throws Exception{
		
		if (TestNGParameterConfig.getExecuteOnBrowserStack().equals("Yes")) {
			switch (TestNGParameterConfig.getBrowserType()) {
			case "Chrome":
				ExtentCucumberAdapter.addTestStepLog("<span class=\"badge log pass-bg mr-2\"> End Thread Id "+Thread.currentThread().getId()+"</span>");
				new KillDriver();
				break;
			case "androiddevice":
				ThreadLocalAndroidDriver.getDriver().quit();	
				break;	
			default:
				break;
			}
			
		}else {
			switch (TestNGParameterConfig.getBrowserType()) {
			case "Chrome":
				ExtentCucumberAdapter.addTestStepLog("<span class=\"badge log pass-bg mr-2\"> End Thread Id "+Thread.currentThread().getId()+"</span>");
				new KillDriver();
				break;
			case "androiddevice":
				ThreadLocalAndroidDriver.getDriver().quit();	
				break;
			case "iosdevice":
				ThreadLocalIOSDriver.getDriver().quit();	
				break;	
			default:
				break;
			}
		}
		
	}

	@AfterStep
	public void addScreenShot(Scenario scenario) throws Exception{
		if (TestNGParameterConfig.getExecuteOnBrowserStack().equals("Yes")) {
			switch (TestNGParameterConfig.getBrowserType()) {
			case "Chrome":
					new TakeScreenshot();
				break;
			case "androiddevice":
					new TakeScreenshotAndroid();
				break;	
			default:
				break;
			}
			
		}else {
			switch (TestNGParameterConfig.getBrowserType()) {
			case "Chrome":
					new TakeScreenshot();
				break;
			case "androiddevice":
					new TakeScreenshotAndroid();
				break;	
			case "iosdevice":
				new TakeScreenshotIOS();
			break;	
			default:
				break;
			}
		}
		
		
	}	
}
