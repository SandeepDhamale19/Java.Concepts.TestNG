package Runner;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import Utilities.TestNGParameterConfig;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

/**
 * @author Varun Paranganath
 *05/05/2023
 *TestAutomationFramework
 */
@CucumberOptions(
   dryRun = false
)
public class RunnerFile extends AbstractTestNGCucumberTests {
	
	@BeforeTest
	@Parameters({"browser","siturl","ExecuteOnBrowserStack","Env"})
	public void LaunchBrowserIC(String browser,String siturl,String ExecuteONBrowserStack,String Env) throws Exception{
		Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c","taskkill /f /im chromedriver.exe /T"});
		
		System.out.println("LIC Launch Configuration on "+browser);
		TestNGParameterConfig.setBrowserType(browser);
		TestNGParameterConfig.setsitURL(siturl);
		TestNGParameterConfig.setExecuteOnBrowserStack(ExecuteONBrowserStack);
		TestNGParameterConfig.setEnv(Env);
		
		System.out.println("Browserstack Execution set on :"+TestNGParameterConfig.getExecuteOnBrowserStack());
		System.out.println("Environment :"+TestNGParameterConfig.getEnv());
		System.out.println("Url :"+TestNGParameterConfig.getsitURL());
	
	}
	
	@DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
	
	
}
