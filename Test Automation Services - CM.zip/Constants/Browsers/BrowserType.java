package Browsers;


public enum BrowserType {
	Chrome,
	IE,
	Firefox,
	HeadlessChrome,
	IncognitoChrome,
	Edge,
	EdgeChromium,
	Android,
	IOS
}
