package Selenium;

import org.openqa.selenium.By;

public class ByType
{
    public static By GetBy(String locator, String locatorType)
    {
        By by = null;

        switch (locatorType)
        {
            case "XPATH":
                by = By.xpath(locator);
                break;
            case "ID":
                by = By.id(locator);
                break;
            case "NAME":
                by = By.name(locator);
                break;
            case "CSS":
                by = By.cssSelector(locator);
                break;
            case "LINKTEXT":
                by = By.linkText(locator);
                break;
            case "CLASSNAME":
                by = By.className(locator);
                break;
            case "TAGNAME":
                by = By.tagName(locator);
                break;
        }

        return by;
    }
}
