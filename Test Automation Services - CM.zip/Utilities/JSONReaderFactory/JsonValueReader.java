/**
 * 
 */
package JSONReaderFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.JSONException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

/**
 * @author Varun Paranganath
 *17/05/2023
 *testautomation-framework
 */
public class JsonValueReader {
	
	
	public static String readJSONValue(String filePath, String jsonKey) {
		JSONParser jsonParser = new JSONParser();
		FileReader reader;
		String jsonValue = "";
		JSONObject jsonObject;
		try {
			reader = new FileReader(filePath);
			Object obj = jsonParser.parse(reader);
			jsonObject = (JSONObject) obj;
			jsonValue = (String) jsonObject.get(jsonKey);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonValue;
	}
	
	public static void writeJSONValue(String filePath,String jsonKey, String jsonValue) throws Exception{
		 ObjectMapper mapper = new ObjectMapper();
	        String key = jsonKey;
	        //Read from file
	        org.json.simple.JSONObject root = mapper.readValue(new File(filePath), JSONObject.class);
//	        org.json.JSONObject jo = new org.json.JSONObject(root);

	        String val_newer = jsonValue;
	        String val_older = root.get(key).toString();

	        //Compare values
	        if(!val_newer.equals(val_older))
	        {
	           //Update value in object
	           root.put(key,val_newer);
	           //Write into the file
	            try (FileWriter file = new FileWriter(filePath)) 
	            {
	            	Gson gson = new GsonBuilder().setPrettyPrinting().create();
		 	        JsonElement je = JsonParser.parseString(root.toString());
		 	        String prettyJsonString = gson.toJson(je);
	                file.write(prettyJsonString);
	                System.out.println("Successfully updated json object to file...!!");
	            }
	        }
	}
	
	
	public static void JsonValueReplace(String fileName,String key,String Value) throws Exception{
		try {
		 File file = new File(fileName);
	        BufferedReader reader = new BufferedReader(new FileReader(file));
	        String words = "", list = "";
	        String replacedtext=null;
	        String _Line = "\""+key+"\""+":"+"\""+Value+"\"";
	        while ((words = reader.readLine()) != null) {
	        	if (words.contains(_Line)) {
//		            list += words + "\r\n";
		            replacedtext = list.replaceAll(words,_Line);
				}else{
					list += words + "\r\n";
				}
	        }
	        reader.close();
//	        replacedtext = list.replace(words,_Line);
	        FileWriter writer = new FileWriter(fileName);
	        writer.write(replacedtext);
	        writer.close();
	        
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws Exception {
		JsonValueReplace("C:\\Users\\VParanganath\\OneDrive - Link Group\\LIC\\LIC_Automation\\LIC_TestAutomation\\config\\JSON_DataSet.json", "ASE_dataOne_IssuerName", "ASE  Asite LimitedXXX");
	}
	
}
