/**
 * 
 */
package ActionsFactory;

import org.openqa.selenium.Alert;
import org.openqa.selenium.interactions.Actions;

import DriverFactory.ThreadLocalDriver;

/**
 * @author Varun Paranganath
 *07/06/2023
 *testautomation-framework
 */
public class AlertsAction {
	
	static Alert alert=null;
	
	public AlertsAction() {
		alert = ThreadLocalDriver.getDriver().switchTo().alert();
	}
	
	
	public String getAlertText() {
		String alertMessage= ThreadLocalDriver.getDriver().switchTo().alert().getText();
		return alertMessage;
	}
	
	public void alertDismiss() {
		ThreadLocalDriver.getDriver().switchTo().alert().dismiss();
	}
	
	public void alertAccept() {
		ThreadLocalDriver.getDriver().switchTo().alert().accept();
	}
	
	public void alertSendkeys(String value) {
		ThreadLocalDriver.getDriver().switchTo().alert().sendKeys(value);
	}
	
}
