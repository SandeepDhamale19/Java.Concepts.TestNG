/**
 * 
 */
package ActionsFactory;

import org.openqa.selenium.JavascriptExecutor;

import DriverFactory.ThreadLocalDriver;

/**
 * @author Varun Paranganath
 *08/06/2023
 *testautomation-framework
 */
public class FrameActions {

	private static String _locator = "";
	private static String _locatorType = "";

	public FrameActions(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public FrameActions() {
	}
	
	
	public void switchtoFrameWithWebElement(){
		ThreadLocalDriver.getDriver().switchTo().frame(FindElements.FindElement(_locator, _locatorType));
	}
	
	public void switchtoFrameWithIndex(int index){
		ThreadLocalDriver.getDriver().switchTo().frame(index);
	}
	
	public void switchtoFrameWithid(String id_Name) {
		ThreadLocalDriver.getDriver().switchTo().frame(id_Name);
	}
	
	public String getFramename() {
		JavascriptExecutor jsExecutor = (JavascriptExecutor)ThreadLocalDriver.getDriver();
		String text = (String) jsExecutor.executeScript("return self.name");
		return text;
	}
	
	public void switchedToParentFrame() {
		ThreadLocalDriver.getDriver().switchTo().parentFrame();
	}
	
	public void switchedToDefaultContent() {
		ThreadLocalDriver.getDriver().switchTo().defaultContent();
	}
	
}
