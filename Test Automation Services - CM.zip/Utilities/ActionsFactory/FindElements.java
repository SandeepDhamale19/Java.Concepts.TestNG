package ActionsFactory;

import java.util.*;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import DriverFactory.DriverInstance;
import DriverFactory.ThreadLocalDriver;
import Selenium.ElementProperties;
import Selenium.LocatorType;

public class FindElements {

			public static WebDriverWait wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	        /// <summary>
	        /// Find element Router based on locator type
	        /// </summary>
	        /// <param name="locator"></param>
	        /// <param name="locatorType"></param>
	        /// <returns></returns>
	        public static WebElement FindElement(String locator, String locatorType)
	        {
	            WebElement webElement = null;

	            if (locatorType.equals(LocatorType.ID))
	                webElement = FindElementById(locator);
	            else if (locatorType.equals(LocatorType.NAME))
	                webElement = FindElementByName(locator);
	            else if (locatorType.equals(LocatorType.XPATH))
	                webElement = FindElementByXPath(locator);
	            else if (locatorType.equals(LocatorType.LINKTEXT))
	                webElement = FindElementByLinkText(locator);
	            else if (locatorType.equals(LocatorType.CSS))
	                webElement = FindElementByCSS(locator);
	            else if (locatorType.equals(LocatorType.TAGNAME))
	                webElement = FindElementByTagname(locator);
	            else if (locatorType.equals(LocatorType.CLASSNAME))
	                webElement = FindElementByClassName(locator);
	            else
	                throw new IllegalArgumentException("Locator type not available. Please use LocatorType class to chose locatort type");

	            ElementProperties.setDisplayed(webElement.isDisplayed());	            
	            ElementProperties.setEnabled(webElement.isEnabled());
	            ElementProperties.setXLocationOnPage(webElement.getLocation().x);
	            ElementProperties.setYLocationOnPage(webElement.getLocation().y);
	            ElementProperties.setWidth(webElement.getSize().width);
	            ElementProperties.setHeight(webElement.getSize().height);	           
	            ElementProperties.setTagName(webElement.getTagName()); 
	            ElementProperties.setText(webElement.getText()); 

	            return webElement;
	        }
	        /// <summary>
	        /// Find Element by XPath
	        /// </summary>
	        /// <param name="xpath"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static WebElement FindElementByXPath(String xpath)
	        {
	            try
	            {
	            	WebDriverWait wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
	                //extentReports.SetStepStatusPass("WebelementName is displayed on the page."); // $"[{elementName}] is displayed on the page."
	                WebElement webElement = ThreadLocalDriver.getDriver().findElement(By.xpath(xpath));
	                return webElement;
	            }
	            catch(Exception ex)
	            {
	                throw new ElementNotInteractableException("WebelementName is not displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Element by Id
	        /// </summary>
	        /// <param name="id"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static WebElement FindElementById(String id) throws ElementClickInterceptedException
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfElementLocated(By.id(id)));

	                return ThreadLocalDriver.getDriver().findElement(By.id(id));
	            }
	            catch (Exception ex)
	            {
	                throw new ElementNotInteractableException("WebelementName is not displayed on the page.");
	            }
	            
	        }

	        /// <summary>
	        /// Find Element by Name
	        /// </summary>
	        /// <param name="name"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static WebElement FindElementByName(String name)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfElementLocated(By.name(name)));

	                return ThreadLocalDriver.getDriver().findElement(By.name(name));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is not displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Element by Text
	        /// </summary>
	        /// <param name="link"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static WebElement FindElementByLinkText(String link)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfElementLocated(By.linkText(link)));

	                return ThreadLocalDriver.getDriver().findElement(By.linkText(link));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is not displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Element by CSS
	        /// </summary>
	        /// <param name="css"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static WebElement FindElementByCSS(String css)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfElementLocated(By.cssSelector(css)));

	                return ThreadLocalDriver.getDriver().findElement(By.cssSelector(css));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is not displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Element by Tagname
	        /// </summary>
	        /// <param name="css"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static WebElement FindElementByTagname(String tagName)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfElementLocated(By.tagName(tagName)));

	                return ThreadLocalDriver.getDriver().findElement(By.tagName(tagName));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is not displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Element by Classname
	        /// </summary>
	        /// <param name="css"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static WebElement FindElementByClassName(String className)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfElementLocated(By.className(className)));

	                return ThreadLocalDriver.getDriver().findElement(By.className(className));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is not displayed on the page.");
	            }
	        }

	        
	        public static List<WebElement> FindElements(String locator, String locatorType)
	        {
	        	List<WebElement> webElements = null;

	            if (locatorType.equals(LocatorType.ID))
	                webElements = FindElementsById(locator);
	            else if (locatorType.equals(LocatorType.NAME))
	                webElements = FindElementsByName(locator);
	            else if (locatorType.equals(LocatorType.XPATH))
	                webElements = FindElementsByXPath(locator);
	            else if (locatorType.equals(LocatorType.LINKTEXT))
	                webElements = FindElementsByLinkText(locator);
	            else if (locatorType.equals(LocatorType.CSS))
	                webElements = FindElementsByCSS(locator);
	            else if (locatorType.equals(LocatorType.TAGNAME))
	                webElements = FindElementsByTagName(locator);
	            else if (locatorType.equals(LocatorType.CLASSNAME))
	                webElements = FindElementsByClassName(locator);
	            else
	                throw new IllegalArgumentException("Locator type not available. Please use LocatorType class to chose locatort type");

	            return webElements;
	        }

	        /// <summary>
	        /// Find Element by XPath
	        /// </summary>
	        /// <param name="xpath"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static List<WebElement> FindElementsByXPath(String xpath)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpath)));

	                //extentReports.SetStepStatusPass("WebelementName is displayed on the page."); // $"[{elementName}] is displayed on the page."
	                return ThreadLocalDriver.getDriver().findElements(By.xpath(xpath));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Element by Id
	        /// </summary>
	        /// <param name="id"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static List<WebElement> FindElementsById(String id)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfAllElementsLocatedBy(By.id(id)));

	                return ThreadLocalDriver.getDriver().findElements(By.id(id));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Element by Name
	        /// </summary>
	        /// <param name="name"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static List<WebElement> FindElementsByName(String name)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfAllElementsLocatedBy(By.name(name)));

	                return ThreadLocalDriver.getDriver().findElements(By.name(name));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Elements by Text
	        /// </summary>
	        /// <param name="link"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static List<WebElement> FindElementsByLinkText(String link)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfAllElementsLocatedBy(By.linkText(link)));

	                return ThreadLocalDriver.getDriver().findElements(By.linkText(link));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Elements by CSS
	        /// </summary>
	        /// <param name="css"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static List<WebElement> FindElementsByCSS(String css)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(css)));

	                return ThreadLocalDriver.getDriver().findElements(By.cssSelector(css));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Elements by CSS
	        /// </summary>
	        /// <param name="css"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static List<WebElement> FindElementsByTagName(String tagName)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName(tagName)));

	                return ThreadLocalDriver.getDriver().findElements(By.tagName(tagName));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is displayed on the page.");
	            }
	        }

	        /// <summary>
	        /// Find Elements by CSS
	        /// </summary>
	        /// <param name="css"></param>
	        /// <param name="timeout"></param>
	        /// <returns></returns>
	        private static List<WebElement> FindElementsByClassName(String className)
	        {
	            try
	            {
	            	wait = new WebDriverWait(ThreadLocalDriver.getDriver(),Duration.ofSeconds(30));
	                wait.until(
	                      ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(className)));

	                return ThreadLocalDriver.getDriver().findElements(By.className(className));
	            }
	            catch (Exception ex)
	            {
	                //extentReports.SetTestStatusFail("WebelementName is displayed on the page.");
	                throw new ElementNotInteractableException("WebelementName is displayed on the page.");
	            }
	        }
	        
	    }