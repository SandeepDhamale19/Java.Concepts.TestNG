/**
 * 
 */
package ActionsFactory;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import DriverFactory.ThreadLocalDriver;
import Hardwait.Hardwait;
import Selenium.ElementProperties;

/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class JavascriptExecutorfunction {
	
	private String _locator = "";
	private String _locatorType = "";
	
	public JavascriptExecutorfunction(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public  void scrollToElement()
    {
		((JavascriptExecutor)ThreadLocalDriver.getDriver()).executeScript("arguments[0].scrollIntoView(true);",FindElements.FindElement(_locator, _locatorType)); 
    }
	
	
	public static void scrollToElement(String locator,String  locatorType)
    {
		((JavascriptExecutor)ThreadLocalDriver.getDriver()).executeScript("arguments[0].scrollIntoView(true);",FindElements.FindElement(locator, locatorType)); 
    }
	
	public  void javaScriptClick()
	{
	((JavascriptExecutor)ThreadLocalDriver.getDriver()).executeScript("arguments[0].click();", FindElements.FindElement(_locator, _locatorType));
	}
	
	public String javaScriptExecutorGetCurrentFrameName()
	{
		JavascriptExecutor jsExecutor = (JavascriptExecutor)ThreadLocalDriver.getDriver();
		String currentFrame = (String) jsExecutor.executeScript("return self.name");
		if(currentFrame.length()>0)
		{
			System.out.println("Current frame is : " + currentFrame);
		}
		return currentFrame;
	}
	
	public void changePageZoom(String zoomLevel)
	{
		System.out.println("Changing page zoom level to : " + zoomLevel +"x");
		JavascriptExecutor executor = (JavascriptExecutor)ThreadLocalDriver.getDriver();
		executor.executeScript("document.body.style.zoom = '"+ zoomLevel +"'");
		Hardwait.staticWait(2000);
	}
	
	public  void scrollToRight()
    {
		((JavascriptExecutor)ThreadLocalDriver.getDriver()).executeScript("arguments[0].scrollLeft=arguments[0].offsetWidth",FindElements.FindElement(_locator, _locatorType));	
    }
	
	public static void scrollDown()
    {
		Hardwait.staticWait(1000);
		((JavascriptExecutor)ThreadLocalDriver.getDriver()).executeScript("window.scrollBy(0,document.body.scrollHeight)");	
    }
	
	public static String getCurrentFrameName()
	{
		JavascriptExecutor jsExecutor = (JavascriptExecutor)ThreadLocalDriver.getDriver();
		String currentFrame = (String) jsExecutor.executeScript("return self.name");
		if(currentFrame.length()>0)
		{
			System.out.println("Current frame is : " + currentFrame);
		}
		return currentFrame;
	}
	
}
