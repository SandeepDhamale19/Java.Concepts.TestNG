/**
 * 
 */
package ActionsFactory;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import Explicitwait.Explicitwait;

/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class SelectDropdownAction {
	
	private String _locator = "";
	private String _locatorType = "";
	
	/**
	 * 
	 */
	public SelectDropdownAction(String locator,String locatorType) {
//		ElementProperties.setlocator(locator);
//		ElementProperties.setlocatorType(locatorType);
		_locator = locator;
		_locatorType = locatorType;
	}
	
	
	public void selectByVisibleText(String visibleTxt)
    {
		WebElement ele = FindElements.FindElement(_locator, _locatorType);
		
		Explicitwait.waitVisibility(ele);
		Select select = new Select(ele);
        select.selectByVisibleText(visibleTxt);
    }
    
    public  void selectByValue(String value)
    {
    	WebElement ele = FindElements.FindElement(_locator, _locatorType);
    	Explicitwait.waitVisibility(ele);
        Select select = new Select(ele);
        select.selectByValue(value);
    }
    
    public void selectByIndex(int index)
    {
    	WebElement ele = FindElements.FindElement(_locator, _locatorType);
    	Explicitwait.waitVisibility(ele);
          Select select = new Select(ele);
          select.selectByIndex(index);
    }
    
    public String selectgetFirstSelectedOption()
    {
    	WebElement ele = FindElements.FindElement(_locator, _locatorType);
    	Explicitwait.waitVisibility(ele);
          Select select = new Select(ele);
          String returnFirstOption = select.getFirstSelectedOption().getText();
          return returnFirstOption;
    }
    
    
    public List <WebElement> DropDownOptions()
    {
    	WebElement ele = FindElements.FindElement(_locator, _locatorType);
    	Explicitwait.waitVisibility(ele);
    	Select select = new Select(ele);
    	List <WebElement> op = select.getOptions();
    	int size = op.size();
    	for(int i =0; i<size ; i++){
            String options = op.get(i).getText();
            System.out.println(options);
         }
    	return op;
    }
	
}
