package ActionsFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import DriverFactory.ThreadLocalAndroidDriver;
import DriverFactory.ThreadLocalDriver;
import DriverFactory.ThreadLocalIOSDriver;
import Hardwait.Hardwait;
import Selenium.ElementProperties;
import io.appium.java_client.AppiumBy;

public class InputAction {
	
	private String _locator ;
	private String _locatorType ;
	
	public InputAction() {
	}
	
	public InputAction(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public  void InputValues(String Value) {
		try {
			InputValues(FindElements.FindElement(_locator, _locatorType),Value);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public  Boolean IsDisplayed() {
		Boolean flag=null;
		try {
			flag = FindElements.FindElement(_locator,_locatorType).isDisplayed();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	public  Boolean IsEnabled() {
		Boolean flag=null;
		try {
			flag = FindElements.FindElement(_locator,_locatorType).isEnabled();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return flag;
	}
	
	
	public static void InputValues(WebElement webElement,String Value) {
		try {
			webElement.sendKeys(Value);
		}
		catch(Exception ex) {
			
		}
	}
//-----------------------------ClearText----------------------------------------------------------	
	
	public void ClearText() {
		try {
			ClearText(FindElements.FindElement(_locator, _locatorType));
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void ClearText(WebElement webElement) {
		try {
			webElement.clear();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void clearInputText(By element)
	{
		String boxValuetemp = ThreadLocalDriver.getDriver().findElement(element).getAttribute("value");
		Hardwait.staticWait(1000);
		for (int tempi=0;tempi<=boxValuetemp.length();tempi++)
		{
			ThreadLocalDriver.getDriver().findElement(element).sendKeys(Keys.BACK_SPACE);
		}
	}
	
	public String getInputText(By element)
	{
		String boxValuetemp = ThreadLocalDriver.getDriver().findElement(element).getAttribute("value");
		return boxValuetemp;
	}
	
	public void enterKey(By element)
	{
		ThreadLocalDriver.getDriver().findElement(element).sendKeys(Keys.ENTER);
	}
	
	public void deleteFullText(By element)
	{
		ThreadLocalDriver.getDriver().findElement(element).sendKeys(Keys.CONTROL,"a");
		ThreadLocalDriver.getDriver().findElement(element).sendKeys(Keys.DELETE);
	}
	
	
	public void SelectText(By element)
	{
		ThreadLocalDriver.getDriver().findElement(element).sendKeys(Keys.CONTROL,"a");
		ThreadLocalDriver.getDriver().findElement(element).sendKeys(Keys.CONTROL,"c");
	}

// Android Device UI Actions //
	
	public void AndroidElementInputValues(String Value) {
		try {
			InputValues(FindAndroidElements.FindElement(_locator, _locatorType),Value);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void AndroidElementInputValues(WebElement webElement,String Value) {
		try {
			webElement.sendKeys(Value);
		}
		catch(Exception ex) {
			
		}
	}
	
	public void androidElementClearText() {
		try {
			FindAndroidElements.FindElement(_locator, _locatorType).clear();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	// IOS Device UI Actions //
	
		public void IOSElementInputValues(String Value) {
			try {
				InputValues(FindIOSElements.FindElement(_locator, _locatorType),Value);
			}catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		
		public static void IOSElementInputValues(WebElement webElement,String Value) {
			try {
				webElement.sendKeys(Value);
			}
			catch(Exception ex) {
				
			}
		}
		
		public void IOSElementClearText() {
			try {
				FindIOSElements.FindElement(_locator, _locatorType).clear();
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
		}
	
	
	
}
