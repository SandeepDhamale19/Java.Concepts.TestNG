/**
 * 
 */
package Hardwait;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

/**
 * @author Varun Paranganath
 *16/05/2023
 *testautomation-framework
 */
public class Hardwait {
		public static void staticWait(long ms)
		{
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
   }
}
