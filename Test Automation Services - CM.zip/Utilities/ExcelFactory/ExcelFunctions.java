package ExcelFactory;

import lombok.extern.slf4j.Slf4j;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class ExcelFunctions {

	/**
	 * The WorkBook path created in LoadFile
     */
    private static transient String sWorkBookPath;

    /**
     * Region Excel WorkBook instance created in LoadFile
     */
    private static transient Workbook workbook;

    /**
     * Region Excel WorkSheet instance created in LoadFile
     */
    private static transient Sheet sheet;
    
    private static final Logger log = LogManager.getLogger(ExcelFunctions.class); 
    
    public ExcelFunctions() {
    	ExcelFunctions.KillExcel();
    }
    /**
     * Sets the region instances for Excel WorkBook and WorkSheet. These
     * instances for the Excel source are created only once and used by other
     * methods. NOTE: For any method to execute, LoadFile must be executed first
     * to set the WorkBook and WorkSheet.
     *
     * @param sWorkBook  Path to the Excel WorkBook
     * @param iWorkSheet Number of the WorkSheet
     * @return ExcelUtil excel util
     */
    public ExcelFunctions LoadFile(String sWorkBook, int iWorkSheet) {
    	//BasicConfigurator.configure();  
    	  
        try {
        	String userDir = System.getProperty("user.dir");
        	sWorkBookPath = userDir + "\\ExcelFactory\\Files\\" + sWorkBook + ".xlsx";
            //sWorkBookPath = sWorkBook;
            InputStream fis = new FileInputStream(sWorkBookPath);
            workbook = WorkbookFactory.create(fis);

            // setHssfsheet(getHssfworkbook().getSheetAt(iWorkSheet));
            sheet = GetWorkbook().getSheetAt(iWorkSheet);
        } catch (IOException e) {
            log.error(e.toString());
        }
        return this;
    }
    public ExcelFunctions LoadFile(String sWorkBook, String iWorkSheet) {
    	//BasicConfigurator.configure();  
    	  
        try {
        	String userDir = System.getProperty("user.dir");
        	sWorkBookPath = userDir + "\\ExcelFactory\\\\Files\\" + sWorkBook + ".xlsx";
            //sWorkBookPath = sWorkBook;
            InputStream fis = new FileInputStream(sWorkBookPath);
            workbook = WorkbookFactory.create(fis);

            // setHssfsheet(getHssfworkbook().getSheetAt(iWorkSheet));
            sheet = GetWorkbook().getSheet(iWorkSheet);
        } catch (IOException e) {
            log.error(e.toString());
        }
        return this;
    }

    /**
     * Finds the number of used rows in the Excel WorkSheet
     *
     * @return The number of used rows
     */
    public static int GetUsedRowsCount() {
        return (GetSheet().getLastRowNum() + 1);
    }
    /**
     * Finds the number of used columns in the Excel WorkSheet
     *
     * @return The number of used columns
     */
    public static int GetUsedColumnsCount() {
        int MaxColumnsCount = 0;
        for (int i = 0; i < GetUsedRowsCount(); i++) {
            Row row = sheet.getRow(i);
            if (row != null && row.getLastCellNum() > MaxColumnsCount) {
                MaxColumnsCount = row.getLastCellNum();
            }

        }
        return MaxColumnsCount;

    }

    /**
     * Reads the value of a cell in an Excel WorkSheet
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     * @return Object cell value
     */
    public static List<Object> GetRangeValue(String range) {
    	List<Integer> GetRangeCoOrdinates = ExcelFunctions.GetRangeCoOrdinates(range);
    	return GetRangeValue(GetRangeCoOrdinates.get(0), GetRangeCoOrdinates.get(1), GetRangeCoOrdinates.get(2), 
    																			GetRangeCoOrdinates.get(3));
    }
    public static List<Object> GetRangeValue(int iStartRow, int iStartColumn, int iEndRow, int iEndColumn) {
    	
    	List<Object> values = new ArrayList();
    	for (int iCurrentRow = iStartRow; iCurrentRow <= iEndRow; iCurrentRow++) {
    		  
    		for (int iCurrentCol = iStartColumn; iCurrentCol <= iEndColumn; iCurrentCol++) {
    			values.add(GetCellValue(iCurrentRow, iCurrentCol));
    		}
    		
    	}
    	
    	return values;
    }
    
    public static String GetCellValue(int iRow, int iColumn) {
    	String cellValue = GetCellValueZeroIndexed(iRow -1, iColumn-1);
        return cellValue;
    }
    public static String GetCellValueZeroIndexed(int iRow, int iColumn) {
        String cellValue = null;
        Row row = sheet.getRow(iRow);
        if (row != null) {
            Cell cell = row.getCell(iColumn);
            if (cell != null) {
                cellValue = GetCellValue(cell);
            }
        }
        if (cellValue == null) {
            return "";
        }
        return cellValue;

    }
    public static String GetCellValue(String range) {
    	
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
        String cellValue = null;
        cellValue = GetCellValue(iRow, iColumn);
        return cellValue;
    }
    /**
     * Get cell value for excel
     *
     * @param cell Cell object of POI
     * @return String value
     */
    public static String GetCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    Date date = DateUtil.getJavaDate(cell.getNumericCellValue());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HHmmss");
                    return sdf.format(date);
                }
                String retVal = String.valueOf(cell.getNumericCellValue());
                if (retVal.endsWith(".0")) {
                    // In order to fix integer number issue, e.g. 9 -> 9.0
                    int length = retVal.length() - 2;
                    retVal = retVal.substring(0, length);
                }
                if (retVal.contains("E")) {
                    // In order to fix big number
                    retVal = String.valueOf(cell.getNumericCellValue());
                    retVal = new BigDecimal(retVal).toString();
                }
                return retVal;
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case ERROR:
                return String.valueOf(cell.getErrorCellValue());
            case FORMULA:
                return GetFormulaValue(cell); //cell.getCellFormula(); 
            default:
                return "";
        }
    }

    /**
     * Get formula type value
     *
     * @param cell The type of cell
     * @return String value
     */
    private static String GetFormulaValue(Cell cell) {
        String retVal = "";
        CellValue cellVal = null;

        try {
            HSSFWorkbook workbook = (HSSFWorkbook) cell.getRow().getSheet()
                    .getWorkbook();
            FormulaEvaluator evaluator = new HSSFFormulaEvaluator(workbook);
            cellVal = evaluator.evaluate(cell);
        } catch (Exception e) {
            XSSFWorkbook workbook = (XSSFWorkbook) cell.getRow().getSheet()
                    .getWorkbook();
            FormulaEvaluator evaluator = new XSSFFormulaEvaluator(workbook);
            cellVal = evaluator.evaluate(cell);
        }

        switch (cellVal.getCellType()) {
            case BOOLEAN:
                retVal = String.valueOf(cellVal.getBooleanValue());
                break;
            case NUMERIC:
                retVal = String.valueOf(cell.getNumericCellValue());
                if (retVal.endsWith(".0")) {
                    // In order to fix integer number issue, e.g. 9 -> 9.0
                    int length = retVal.length() - 2;
                    retVal = retVal.substring(0, length);
                }
                if (retVal.contains("E")) {
                    // In order to fix big number
                    retVal = String.valueOf(cell.getNumericCellValue());
                    retVal = new BigDecimal(retVal).toString();
                }
                break;
            case STRING:
                retVal = cellVal.getStringValue();
                break;
            default:
                break;
        }

        return retVal;
    }
    
    /**
     * Returns a 2D array from the WorkSheet
     *
     * @return 2D array
     */
    public static String[][] Get2DArrayFromSheet() {
        String[][] Array2DFromSheet = new String[GetUsedRowsCount()][GetUsedColumnsCount()];
        try {
            for (int i = 0; i < GetUsedRowsCount(); i++) {
                Row row = sheet.getRow(i);
                if (row != null) {
                    for (int j = 0; j < GetUsedColumnsCount(); j++) {
                        Cell cell = row.getCell(j);
                        if (cell != null) {
                            Array2DFromSheet[i][j] = GetCellValue(cell);
                        } else {
                            Array2DFromSheet[i][j] = "";
                        }

                    }
                } else {
                    for (int j = 0; j < GetUsedColumnsCount(); j++) {
                        Array2DFromSheet[i][j] = "";
                    }
                }

            }
        } catch (Exception e) {
            log.error(e.toString());
        }
        return Array2DFromSheet;
    }
    /**
     * Returns a 2D array by specific rows and columns from the WorkSheet
     *
     * @param MaxRows    The specific max rows
     * @param MaxColumns The specific max columns
     * @return String[][] String [ ] [ ]
     */
    public static String[][] Get2DArrayFromSheetBySpecificRowsColumns(int MaxRows,
                                                               int MaxColumns) {
        String[][] Array2DFromSheet = new String[MaxRows][MaxColumns];
        try {
            for (int i = 0; i < MaxRows; i++) {
                Row row = sheet.getRow(i);
                if (row != null) {
                    for (int j = 0; j < MaxColumns; j++) {
                        Cell cell = row.getCell(j);
                        if (cell != null) {
                            Array2DFromSheet[i][j] = GetCellValue(cell);
                        } else {
                            Array2DFromSheet[i][j] = "";
                        }

                    }
                } else {
                    for (int j = 0; j < MaxColumns; j++) {
                        Array2DFromSheet[i][j] = "";
                    }
                }

            }
        } catch (Exception e) {
            log.error(e.toString());
        }
        return Array2DFromSheet;
    }
    /**
     * Returns a 2D data from the WorkSheet
     *
     * @return the 2 d data from sheet
     */
    public static List<List<String>> Get2DDataFromSheet() {
        List<List<String>> data2DFromSheet = new ArrayList<List<String>>();
        List<String> rowData = new ArrayList<String>();
        try {
            for (int i = 0; i < GetUsedRowsCount(); i++) {
                Row row = sheet.getRow(i);
                if (row != null) {
                    for (int j = 0; j < GetUsedColumnsCount(); j++) {
                        Cell cell = row.getCell(j);
                        if (cell != null) {
                            rowData.add(GetCellValue(cell));
                        } else {
                            rowData.add("");
                        }

                    }
                } else {
                    for (int j = 0; j < GetUsedColumnsCount(); j++) {
                        rowData.add("");
                    }
                }
                data2DFromSheet.add(rowData);

            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        return data2DFromSheet;
    }

    /**
     * Get the column data by the specified column.
     *
     * @param iColumn the column
     * @return the column data
     */
    public static List<String> GetColumnData(int iColumn) {
    	
    	List<String> columnData =GetColumnDataZeroIndexed(iColumn-1);
        return columnData;
    }
    public static List<String> GetColumnDataZeroIndexed(int iColumn) {
        List<String> columnData = new ArrayList<String>();
        String[][] data = Get2DArrayFromSheet();
        for (String[] aData : data) {
            for (int j = 0; j < aData.length; j++) {
                if (j == iColumn) {
                    if (!aData[j].isEmpty()) {
                        columnData.add(aData[j]);
                    }
                }
            }
        }
        return columnData;
    }
    public static List<String> GetColumnData(String columnName) {
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(columnName);
    	List<String> columnData =GetColumnData(iColumn);
        return columnData;
    }

    /**
     * Set the foreground fill color for specify cell
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     */
    public static void SetForegroundColor(int iRow, int iColumn) {
    	SetForegroundColorZeroIndexed(iRow -1, iColumn-1);        
    }
    public static void SetForegroundColorZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = workbook.createCellStyle();
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setFillForegroundColor(IndexedColors.CORAL.getIndex());
        if (cell != null) {
            cell.setCellStyle(style);
        } else {
            cell = row.createCell(iColumn);
            cell.setCellStyle(style);
        }
    }
    public static void SetForegroundColor(String range) {
    	
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	SetForegroundColor(iRow, iColumn);
    }
    /**
     * Set the foreground fill color to white(default color) for specify cell
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     */
    public static void SetToDefaultForegroundColor(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = workbook.createCellStyle();
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setFillForegroundColor(IndexedColors.WHITE.getIndex());

        if (cell != null) {
            cell.setCellStyle(style);
        } else {
            cell = row.createCell(iColumn);
            cell.setCellStyle(style);
        }
    }

    /**
     * Get cell foreground color
     *
     * @param iRow    the row
     * @param iColumn the column
     * @return cell foreground color
     */
    public static int GetCellForegroundColor(int iRow, int iColumn) {
    	int cellForeGroundColor = GetCellForegroundColorZeroIndexed(iRow-1, iColumn-1);
    	
        return cellForeGroundColor;
    }
    public static int GetCellForegroundColorZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        return cell.getCellStyle().getFillForegroundColor();
    }
    public static int GetCellForegroundColor(String range) {
    	
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	int cellForeGroundColor = GetCellForegroundColor(iRow, iColumn);
    	
        return cellForeGroundColor;
    }
    
    /**
     * Set the font fill color for specify cell
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     * @param color   the color
     */
    public static void SetFontColor(int iRow, int iColumn, long color) {
    	SetFontColorZeroIndexed(iRow -1, iColumn-1, color);
    }
    public static void SetFontColor(String range, long color) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	SetFontColor(iRow, iColumn, color);
    }
    public static void SetFontColorZeroIndexed(int iRow, int iColumn, long color) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setColor((short) color);
        style.setFont(font);
        if (cell != null) {
            cell.setCellStyle(style);
        } else {
            cell = row.createCell(iColumn);
            cell.setCellStyle(style);
        }
    }
    /**
     * Set the font fill color to red for specify cell
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     */
    public static void SetFontColorToRed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setColor(IndexedColors.RED.getIndex());
        style.setFont(font);
        if (cell != null) {
            cell.setCellStyle(style);
        } else {
            cell = row.createCell(iColumn);
            cell.setCellStyle(style);
        }
    }
    /**
     * Set the font fill color for specify cell
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     */
    public static void SetToDefaultFontColor(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(font);
        if (cell != null) {
            cell.setCellStyle(style);
        } else {
            cell = row.createCell(iColumn);
            cell.setCellStyle(style);
        }
    }

    /**
     * Get cell font color
     *
     * @param iRow    the row
     * @param iColumn the column
     * @return the cell font color
     */
    public static int GetCellFontColor(int iRow, int iColumn) {
    	return GetCellFontColorZeroIndexed(iRow-1, iColumn -1);
    }
    public static int GetCellFontColor(String range) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	return GetCellFontColor(iRow, iColumn);
    }
    public static int GetCellFontColorZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = cell.getCellStyle();
        Font font = workbook.getFontAt(style.getFontIndexAsInt()) ;//workbook.getFontAt(style.getFontIndex());
        return font.getColor();
    }
    
    public static int GetCellFontSize(int iRow, int iColumn) {
    	return GetCellFontSizeZeroIndexed(iRow-1, iColumn -1);
    }
    public static int GetCellFontSizeZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = cell.getCellStyle();
        Font font = workbook.getFontAt(style.getFontIndexAsInt()) ;//workbook.getFontAt(style.getFontIndex());
        return font.getFontHeight();
    }
    public static int GetCellFontSize(String range) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	return GetCellFontSize(iRow, iColumn);
    }
    
    public static String GetCellFontName(int iRow, int iColumn) {
    	return GetCellFontNameZeroIndexed(iRow-1, iColumn -1);
    }
    public static String GetCellFontNameZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = cell.getCellStyle();
        Font font = workbook.getFontAt(style.getFontIndexAsInt()) ;//workbook.getFontAt(style.getFontIndex());
        return font.getFontName();
    }
    public static String GetCellFontName(String range) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	return GetCellFontName(iRow, iColumn);
    }
    
    public static boolean GetCellFontItalic(int iRow, int iColumn) {
    	return GetCellFontItalicZeroIndexed(iRow-1, iColumn -1);
    }
    public static boolean GetCellFontItalicZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = cell.getCellStyle();
        Font font = workbook.getFontAt(style.getFontIndexAsInt()) ;//workbook.getFontAt(style.getFontIndex());
        return font.getItalic();
    }
    public static boolean GetCellFontItalic(String range) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	return GetCellFontItalic(iRow, iColumn);
    }
    
    public static boolean GetCellFontBold(int iRow, int iColumn) {
    	return GetCellFontBoldZeroIndexed(iRow-1, iColumn -1);
    }
    public static boolean GetCellFontBoldZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = cell.getCellStyle();
        Font font = workbook.getFontAt(style.getFontIndexAsInt()) ;//workbook.getFontAt(style.getFontIndex());
        return font.getBold();
    }
    public static boolean GetCellFontBold(String range) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	return GetCellFontBold(iRow, iColumn);
    }
    
    public static String GetCellFormula(int iRow, int iColumn) {
    	return GetCellFormulaZeroIndexed(iRow-1, iColumn -1);
    }
    public static String GetCellFormulaZeroIndexed(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        String cellFormula = "";
        
        try{
        	cellFormula = cell.getCellFormula();        
        }
        catch(Exception ex){
        	
        }
        return cellFormula;
    }
    public static String GetCellFormula(String range) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	return GetCellFormula(iRow, iColumn);
    }
    
    /**
     * Set the cell value for specify cell
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     * @param value   value to be write
     */
    public static void SetRangeValue(String range,  List<Object> values) {
    	List<Integer> GetRangeCoOrdinates = ExcelFunctions.GetRangeCoOrdinates(range);
    	SetRangeValue(GetRangeCoOrdinates.get(0), GetRangeCoOrdinates.get(1), GetRangeCoOrdinates.get(2), 
    																			GetRangeCoOrdinates.get(3),  values);
    }
    public static void SetRangeValue(int iStartRow, int iStartColumn, int iEndRow, int iEndColumn,  List<Object> values) {
    	Integer index =0;
    	for (int iCurrentRow = iStartRow; iCurrentRow <= iEndRow; iCurrentRow++) {
    		  
    		for (int iCurrentCol = iStartColumn; iCurrentCol <= iEndColumn; iCurrentCol++) {
    			SetCellValue(iCurrentRow, iCurrentCol, values.get(index).toString());
    			index++;
    		}
    		
    	}
    }
    
    public static void SetCellValue(int iRow, int iColumn, String value) {
    	SetCellValueZeroIndexed(iRow -1, iColumn -1 , value);
    }
    public static void SetCellValue(String range, String value) {
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	SetCellValue(iRow, iColumn, value);
    }
    public static void SetCellValueZeroIndexed(int iRow, int iColumn, String value) {
        Row row = sheet.getRow(iRow);
        if (row == null) {
            row = sheet.createRow(iRow);
        }
        Cell cell = row.getCell(iColumn);
        if (cell != null) {
            cell.setBlank();
            cell.setCellValue(value);
        } else {
            cell = row.createCell(iColumn);
            cell.setBlank();
            cell.setCellValue(value);
        }
    }

    /**
     * Save the workbook Sometimes writing twice to a .xlsx file throws
     * org.apache.xmlbeans.impl.values.XmlValueDisconnectedException
     * https://issues.apache.org/bugzilla/show_bug.cgi?id=49940
     */
    public static void SaveWorkbook() {
        // Write the output to a file
        try {
            FileOutputStream fileOut = new FileOutputStream(sWorkBookPath);
            workbook.write(fileOut);
            //fileOut.close();
        } catch (IOException e) {
            log.error(e.toString());
        }
    }
    public static void CloseWorkbook() {
        // Write the output to a file
        try {
            FileOutputStream fileOut = new FileOutputStream(sWorkBookPath);
            workbook.write(fileOut);
            fileOut.close();
        } catch (IOException e) {
            log.error(e.toString());
        }
    }
    public static void ClearWorkSheet() {
    	//Sheet sheet = wb.getSheetAt(0);
    	for (Row row : sheet) {
    	   sheet.removeRow(row);
    	}
    }
    /**
     * Set the cell type to numeric for specify cell
     *
     * @param iRow    Row Number
     * @param iColumn Column Number
     */
    public static void SetCellTypeToDate(int iRow, int iColumn) {
        Row row = sheet.getRow(iRow);
        Cell cell = row.getCell(iColumn);
        CellStyle style = workbook.createCellStyle();
        CreationHelper createHelper = workbook.getCreationHelper();
        style.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));
        cell.setCellStyle(style);
    }
    
    /**
    * Gets cell.
     *
     * @param rowIndex    the row index
     * @param columnIndex the column index
     * @return the cell
     */
    public static Cell GetCell(int rowIndex, int columnIndex) {
        
        Cell cell = GetCellZeroIndexed(rowIndex -1 , columnIndex-1);
        return cell;

    }
    public static Cell GetCellZeroIndexed(int rowIndex, int columnIndex) {
        // Create a row and put some cells in it. Rows are 0 based.
        Row row = sheet.getRow((int) rowIndex);
        // Create a cell and put a value in it.
        Cell cell = row.getCell(columnIndex);
        if (cell == null) {
            cell = row.createCell(columnIndex);
            cell.setBlank();
        }
        return cell;

    }
    public static Cell GetCell(String range) {
    	
    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	Cell cell = GetCell(iRow, iColumn);
        return cell;

    }
    
    /**
     * Find a cell by the text in specified column
     *
     * @param iColumn the column
     * @param text    the text
     * @return the cell
     */
    public static Cell FindCellByColumn(int iColumn, String text) {
        for (Row row : sheet) {
            if (row != null) {
                Cell cell = (Cell) row.getCell(iColumn);
                if (cell != null
                        && text.equalsIgnoreCase(GetCellValue((Cell) cell).trim())) {
                    return cell;
                }
            }

        }
        return null;
    }
    /**
     * Find a cell by the text in specified row
     *
     * @param iRow the row
     * @param text the text
     * @return cell cell
     */
    public static Cell FindCellByRow(int iRow, String text) {
        Row row = sheet.getRow(iRow);
        if (row != null) {
            for (Cell cell : row) {
                if (cell != null
                        && text.equalsIgnoreCase(GetCellValue((Cell) cell).trim())) {
                    return cell;
                }
            }
        }
        return null;
    }
    /**
     * Find a cell by the text
     *
     * @param text the text
     * @return cell cell
     */
    public static Cell FindCell(String text) {
        for (Row row : sheet) {
            if (row != null) {
                for (Cell cell : row) {
                    if (cell != null
                            && text.equalsIgnoreCase(GetCellValue((Cell) cell).trim())) {
                        return cell;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Build a test dictionary with header
     *
     * @param iHeadingRow the heading row
     * @param iRow        the row
     * @return hash map
     */
    public static HashMap<String, String> BuildRowHeadingDictionary(int iHeadingRow,
                                                             int iRow) {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        for (int iCol = 0; iCol < GetUsedColumnsCount(); iCol++) {
            if (GetCellValueZeroIndexed(iRow, iCol) != null) {
                hashMap.put(GetCellValueZeroIndexed(iHeadingRow, iCol),
                		GetCellValueZeroIndexed(iRow, iCol));
            } else {
                hashMap.put(GetCellValueZeroIndexed(iHeadingRow, iCol), "");
            }

        }
        return hashMap;
    }
    /**
     * Build a dictionary list with header
     *
     * @param iHeadingRow the heading row
     * @return list list
     */
    public static List<Map<String, String>> RowHeadingDictList(int iHeadingRow) {
        List<Map<String, String>> rowHeadingDictionaryList = new ArrayList<Map<String, String>>();
        for (int i = 0; i < GetUsedRowsCount(); i++) {
            rowHeadingDictionaryList.add(BuildRowHeadingDictionary(iHeadingRow, i));
        }
        return rowHeadingDictionaryList;
    }
    /**
     * Build a test dictionary with header
     *
     * @param iHeadingRow       the heading row
     * @param strUniquecolValue the str uniquecol value
     * @return hash map
     */
    public static HashMap<String, String> BuildRowHeadingDictionary(int iHeadingRow,
                                                             String strUniquecolValue) {
        int iRow = FindCell(strUniquecolValue).getRowIndex();
        return BuildRowHeadingDictionary(iHeadingRow, iRow);
    }
    /**
     * Build a test dictionary with header
     *
     * @param iHeadingRow       the heading row
     * @param iColumn           the column
     * @param strUniquecolValue the str uniquecol value
     * @return hash map
     */
    public static HashMap<String, String> BuildRowHeadingDictionary(int iHeadingRow,
                                                             int iColumn, String strUniquecolValue) {
        try {
            int iRow = FindCellByColumn(iColumn, strUniquecolValue)
                    .getRowIndex();
            return BuildRowHeadingDictionary(iHeadingRow, iRow);
        } catch (Exception e) {
            log.error("The " + strUniquecolValue + " can't be found in "
                    + (iColumn + 1) + " column in the file-" + sWorkBookPath, e);
        }
        return null;
    }

    /**
     * Create the workbook and work sheet For any method to execute, CreateExcel
     * must be executed first to set the WorkBook and WorkSheet.
     *
     * @param outputFile the output file
     * @param sheetName  the sheet name
     */
    public static void CreateExcel(String outputFile, String sheetName) {
        sWorkBookPath = outputFile;
        if (sWorkBookPath.endsWith("xls")) {
            workbook = new HSSFWorkbook();
        } else {
            workbook = new XSSFWorkbook();
        }
        sheet = workbook.createSheet(sheetName);
        // saveWorkbook();
    }
    /**
     * Create the cells for the worksheet
     *
     * @param rowsCount    the rows count
     * @param columnsCount the columns count
     */
    public static void CreateCells(int rowsCount, int columnsCount) {
        for (int i = 0; i < rowsCount; i++) {
            // Create a row and put some cells in it. Rows are 0 based.
            Row row = sheet.createRow((int) i);
            for (int j = 0; j < columnsCount; j++) {
                // Create a cell and put a value in it.
                row.createCell(j);
            }
        }
    }
    /**
     * Create cell cell.
     *
     * @param rowIndex    the row index
     * @param columnIndex the column index
     * @return the cell
     */
    public static Cell CreateCell(int rowIndex, int columnIndex) {
        // Create a row and put some cells in it. Rows are 0 based.
        Row row = sheet.createRow((int) rowIndex);
        // Create a cell and put a value in it.
        return row.createCell(columnIndex);

    }

    /**
     * Create a hyperlink with blue or red font color for a specified cell based
     * on if it's a pass or failed case
     *
     * @param cell    the cell
     * @param address the address
     * @param isPass  the is pass
     */
    public static void CreateHyperlink(Cell cell, String address, boolean isPass) {
        // cell style for hyperlinks
        CellStyle hlink_style = workbook.createCellStyle();
        Font hlink_font = workbook.createFont();
        hlink_font.setUnderline(Font.U_SINGLE);

        if (isPass) {
            hlink_font.setColor(IndexedColors.BLUE.getIndex());
        } else {
            hlink_font.setColor(IndexedColors.RED.getIndex());
        }

        hlink_style.setFont(hlink_font);

        WriteHyperlinkToCell(cell, address, hlink_style);
    }
    /**
     * Writes hyper link to cell.
     *
     * @param cell       the <code>Cell<code> object of POI
     * @param linkedExpr the cell linked expression. example: #'sheetName'!A1
     */
    private static void WriteHyperlinkToCell(Cell cell, String linkedExpr,
                                      CellStyle cellStyle) {
        cell.setCellFormula("HYPERLINK(\"" + linkedExpr + "\", \""
                + GetCellValue(cell) + "\")");
        //cell.set(CellType.FORMULA);
        cell.setCellStyle(cellStyle);
    }
    /**
     * Writes hyper link to cell.
     *
     * @param cell          the <code>Cell</code> object of POI
     * @param linkedSheet   the linked sheet name
     * @param linkedPostion the linked position example: A1, A2, A3...
     * @param cellStyle     the cell style
     */
    public static void WriteHyperlinkToCell(Cell cell, String linkedSheet,
                                     String linkedPostion, CellStyle cellStyle) {
        String linkExpr = "#'" + linkedSheet + "'!" + linkedPostion;
        WriteHyperlinkToCell(cell, linkExpr, cellStyle);
    }

    /**
     * insert row into the sheet, the style of cell is the same as startRow
     *
     * @param startRow the start row
     * @param rows     the rows
     */
    public static void InsertRow(int startRow, int rows) {
        int startRowIndex = startRow;
        sheet.shiftRows(startRowIndex + 1, sheet.getLastRowNum(), rows, true,
                false);
        // Parameters:
        // startRow - the row to start shifting
        // endRow - the row to end shifting
        // n - the number of rows to shift
        // copyRowHeight - whether to copy the row height during the shift
        // resetOriginalRowHeight - whether to set the original row's height to
        // the default

        for (int i = 0; i < rows; i++) {
            sheet.createRow(++startRowIndex);
        }
    }
    /**
     * Remove a row by its index
     *
     * @param rowIndex the row index
     */
    public static void RemoveRow(int rowIndex) {
        int lastRowNum = sheet.getLastRowNum();
        if (rowIndex >= 0 && rowIndex < lastRowNum) {
            sheet.shiftRows(rowIndex + 1, lastRowNum, -1);
        }
        if (rowIndex == lastRowNum) {
            Row removingRow = sheet.getRow(rowIndex);
            if (removingRow != null) {
                sheet.removeRow(removingRow);
            }
        }

    }

    /**
     * Export the ListMap to excel with header row
     *
     * @param listMap    the list map
     * @param outputFile the output file
     * @param sheetName  the sheet name
     */
    public static void ExportListMapToExcel(List<Map<String, String>> listMap,
                                     String outputFile, String sheetName) {
        ExcelFunctions.CreateExcel(outputFile, sheetName);
        ExcelFunctions.CreateCells(listMap.size() + 1, listMap.get(0).size());
        log.info("Start to export to the result file " + outputFile);
        int iRow = 0;
        int iCol = 0;
        // Fill the header row
        for (Map.Entry<String, String> entry : listMap.get(0).entrySet()) {
            ExcelFunctions.SetCellValue(0, iCol, entry.getKey());
            iCol++;
        }
        // Fill the data row
        for (Map<String, String> map : listMap) {
            iRow++;
            iCol = 0;
            for (Map.Entry<String, String> entry : map.entrySet()) {
                ExcelFunctions.SetCellValue(iRow, iCol, entry.getValue());
                iCol++;
            }
        }
        // Save
        ExcelFunctions.SaveWorkbook();
        log.info("The export process are done!");
    }

    /**
     * Gets workbook.
     *
     * @return the workbook
     */
    public static Workbook GetWorkbook() {
        return workbook;
    }
    /**
     * Sets workbook.
     *
     * @param workbook the workbook
     */
    public void SetWorkbook(Workbook workbook) {
    	ExcelFunctions.workbook = workbook;
    }
    /**
     * Sets work book path.
     *
     * @param sWorkBookPath the s work book path
     */
    public void SetsWorkBookPath(String sWorkBookPath) {
    	ExcelFunctions.sWorkBookPath = sWorkBookPath;
    }
    /**
     * Gets work book path.
     *
     * @return the work book path
     */
    public static String GetsWorkBookPath() {
        return sWorkBookPath;
    }
    
    /**
     * Gets sheet.
     *
     * @return the sheet
     */
    public static Sheet GetSheet() {
        return sheet;
    }
    /**
     * Sets sheet.
     *
     * @param sheet the sheet
     */
    public void SetSheet(Sheet sheet) {
    	ExcelFunctions.sheet = sheet;
    }

    public static String ColumnIndexToColumnAlphabet(int columnNumber) {    	
    	return CellReference.convertNumToColString(columnNumber - 1);
    }
    public static int ColumnAlphabetToColumnIndex(String columnName) {    	
    	return CellReference.convertColStringToIndex(columnName) + 1;
    }
    
    public static void KillExcel() {
    	try {
        Runtime.getRuntime().exec("taskkill /f /t /IM EXCEL.EXE");
        Thread.sleep(1000);
    	}
    	catch (InterruptedException ex){
    		//throws InterruptedException;
    	}
    	catch (IOException ex){
    		//throws InterruptedException;
    	}
        
    }
    
    public static List<Integer> GetRangeCoOrdinates(String range)
    {
        List<Integer> rangeCoOrdinates = new ArrayList<Integer>();
        String rangeEndEnd = "";
        String rangeStartEnd = "";
        String rangeStartColumn = "";
        String rangeStartRow = "";
        String rangeEndColumn = "";
        String rangeEndRow = "";
        String[] rangeEnds = null;

        if (range.contains("$"))
            range = range.replace("$", "");

        if (range.contains(":"))
        {
            rangeEnds = range.split(":",0);
            rangeStartEnd = rangeEnds[0];
        }
        else
        {
            rangeStartEnd = range;
        }

        rangeStartColumn = GetAlphaValueFromRange(rangeStartEnd);
        rangeStartRow = GetNumericValueFromRange(rangeStartEnd);

        if (!(rangeStartRow == null || rangeStartRow.length() == 0))
        {
            int startRow = Integer.parseInt(rangeStartRow);
            rangeCoOrdinates.add(startRow);
        }
        else
        {
            rangeCoOrdinates.add(1);
        }

        int startColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangeStartColumn);
        rangeCoOrdinates.add(startColumn);

        if (rangeEnds.length == 2)
        {
            rangeEndEnd = rangeEnds[1];
            rangeEndColumn = GetAlphaValueFromRange(rangeEndEnd);
            rangeEndRow = GetNumericValueFromRange(rangeEndEnd);
            if (!(rangeEndRow == null || rangeEndRow.length() == 0))
            {
                int endRow = Integer.parseInt(rangeEndRow);
                rangeCoOrdinates.add(endRow);
            }
            else
            {
                rangeCoOrdinates.add(GetUsedRowsCount());
            }
            int endColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangeEndColumn);
            rangeCoOrdinates.add(endColumn);
        }

        return rangeCoOrdinates;
    }
    
    private static String GetAlphaValueFromRange(String range)
    {
    	String[] part = range.split("(?<=\\D)(?=\\d)");
    	String text = part[0];

    	return text;
    }
    private static String GetNumericValueFromRange(String range)
    {
    	String[] part = range.split("(?<=\\D)(?=\\d)");
    	String number = part[1];

    	return number;
    }
    
    public static HashMap<String, Object> GetCellProperties(int iRow, int iColumn){
    	HashMap<String, Object> cellProperties= new HashMap<String, Object>();

    	cellProperties.put("CellValue", GetCellValue(iRow, iColumn));
    	cellProperties.put("ForegroundColor", GetCellForegroundColor(iRow, iColumn));
    	cellProperties.put("FontColor", GetCellFontColor(iRow, iColumn));
    	cellProperties.put("FontSize", GetCellFontSize(iRow, iColumn));
    	cellProperties.put("FontName", GetCellFontName(iRow, iColumn));
    	cellProperties.put("FontItalic", GetCellFontItalic(iRow, iColumn));
    	cellProperties.put("FontBold", GetCellFontBold(iRow, iColumn));
    	cellProperties.put("Formula", GetCellFormula(iRow, iColumn));

    	return cellProperties;
    }
    public static HashMap<String, Object> GetCellProperties(String range){
    	HashMap<String, Object> cellProperties= new HashMap<String, Object>();

    	String[] rangePart = range.split("(?<=\\D)(?=\\d)");
    	int iRow = Integer.parseInt(rangePart[1]);
    	int iColumn = ExcelFunctions.ColumnAlphabetToColumnIndex(rangePart[0]);
    	cellProperties = GetCellProperties(iRow, iColumn);
    	return cellProperties;
    }
    
    public static List<Object> GetRangeProperties(String range) {
    	List<Integer> GetRangeCoOrdinates = ExcelFunctions.GetRangeCoOrdinates(range);
    	List<Object> rangeProperties = new ArrayList();
    	rangeProperties = GetRangeProperties(GetRangeCoOrdinates.get(0), GetRangeCoOrdinates.get(1), GetRangeCoOrdinates.get(2), 
    																			GetRangeCoOrdinates.get(3));
    	
    	return rangeProperties;
    }
    public static List<Object> GetRangeProperties(int iStartRow, int iStartColumn, int iEndRow, int iEndColumn) {
    	Integer index =0;
    	List<Object> rangeProperties = new ArrayList();
    	for (int iCurrentRow = iStartRow; iCurrentRow <= iEndRow; iCurrentRow++) {
    		  
    		for (int iCurrentCol = iStartColumn; iCurrentCol <= iEndColumn; iCurrentCol++) {
    			rangeProperties.add(GetCellProperties(iCurrentRow, iCurrentCol));
    			index++;
    		}
    		
    	}
    	
    	return rangeProperties;
    }


}

