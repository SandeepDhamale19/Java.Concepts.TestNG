package Framework;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;

import DriverFactory.DriverInstance;
import DriverFactory.ThreadLocalDriver;

public class UIFramework {
	
	public static WebDriver driver;
	
	@BeforeTest
	public void Setup()
	{
		driver = DriverInstance.Driver();
	}
	
	@Test
	public void RunTest() {
		
	}
	
	@AfterSuite
	public void Teardown()
	{
		DriverInstance.ResetDriver();
	}

}
