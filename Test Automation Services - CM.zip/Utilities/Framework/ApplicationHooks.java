/**
 * 
 */
package Framework;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

/**
 * @author Varun Paranganath
 *24/05/2023
 *testautomation-framework
 */
public class ApplicationHooks {

	@Before
	public void BeforeScenario(Scenario scenario) throws Exception{
			ExtentCucumberAdapter.addTestStepLog("<span class=\"badge log pass-bg mr-2\">Executing Scenario on TestCaseId "+scenario.getSourceTagNames()+"</b></span>");
	}
	
}
