package DriverFactory;

import org.openqa.selenium.WebDriver;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class ThreadLocalIOSDriver {
	
	public ThreadLocalIOSDriver() {
	}
	
	private static ThreadLocalIOSDriver instance= new ThreadLocalIOSDriver();
	private static ThreadLocal<IOSDriver> driver = new ThreadLocal<IOSDriver>();
	
	public static ThreadLocalIOSDriver getInstance() {
		return instance;
	}

    /**
     * @return thread local webdriver
     */
    public static IOSDriver getDriver() {
        return driver.get();
    }

    /**
     * @param driver set the driver instance
     */
    public static  void setWebDriver(IOSDriver driverparam) {
        driver.set(driverparam);
    }
    
    /**
     * @param Close Driver Instance and remove current thread
     */
    public  void closeBrowser() {
		try {
			driver.get().close();
			driver.remove();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    /**
     * @param Driver Instance remove current thred
     */
	public void removeThread() {
		try {
			driver.remove();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
