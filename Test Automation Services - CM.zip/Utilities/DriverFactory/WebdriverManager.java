/**
 * 
 */
package DriverFactory;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author Varun Paranganath 28/04/2023 Testautomation-framework
 */
public class WebdriverManager implements WebDriver{
	private WebDriver driver;
	private final int timeout = 30;
	private String browserName;
	
	public WebdriverManager(String browserName) { 
	      this.browserName = browserName; 
	      this.driver = createDriver(browserName); 
	   }  
	
	/**
	 * @param browserName
	 * @return
	 */
	private WebDriver createDriver(String browserName) {
		if (browserName.toUpperCase().equals("FIREFOX")) 
		         return firefoxDriver(); 
		      if (browserName.toUpperCase().equals("CHROME")) 
		         return chromeDriver();  
		      throw new RuntimeException ("invalid browser name");
	}



	/**
	 * @return
	 */
	private WebDriver chromeDriver() {
		ChromeOptions chromeOptions = new ChromeOptions();
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver(chromeOptions);
		return driver;
	}

	/**
	 * @return
	 */
	private WebDriver firefoxDriver() {
		ChromeOptions chromeOptions = new ChromeOptions();
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new ChromeDriver(chromeOptions);
		return driver;
	}

	@Override
	public void get(String url) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public String getCurrentUrl() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<WebElement> findElements(By by) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public WebElement findElement(By by) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getPageSource() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void quit() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Set<String> getWindowHandles() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getWindowHandle() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public TargetLocator switchTo() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Navigation navigate() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Options manage() {
		// TODO Auto-generated method stub
		return null;
	}

}
