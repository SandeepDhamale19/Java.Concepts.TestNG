package DriverFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.util.concurrent.TimeUnit;
import ConfigurationFactory.ConfigDataProvider;
import io.appium.java_client.android.AndroidDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import Browsers.BrowserType;

public class DriverProvider {
	
	public ConfigDataProvider configProperty;
	static WebDriver driver;
	static AndroidDriver androiddriver;
	
	public WebDriver Create() {		
		
		configProperty = new ConfigDataProvider();
		var driverToUse = configProperty.getBrowser();
		
		if(driverToUse.equalsIgnoreCase(BrowserType.Chrome.name())) {
			driver = ConfigureChromeSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.IE.name())) {
			driver = ConfigureIESetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.Firefox.name())) {
			driver = ConfigureFirefoxSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.HeadlessChrome.name())) {
			driver = ConfigureHeadlessChromeSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.IncognitoChrome.name())) {
			driver = ConfigureIncognitoChromeSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.Edge.name())) {
			driver = ConfigureEdgeSetUp();
		}
		
		return driver;
	}
	
	
public WebDriver Create(String browser) {		
		
		var driverToUse = browser;
		
		if(driverToUse.equalsIgnoreCase(BrowserType.Chrome.name())) {
			driver = ConfigureChromeSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.IE.name())) {
			driver = ConfigureIESetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.Firefox.name())) {
			driver = ConfigureFirefoxSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.HeadlessChrome.name())) {
			driver = ConfigureHeadlessChromeSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.IncognitoChrome.name())) {
			driver = ConfigureIncognitoChromeSetUp();
		}
		else if (driverToUse.equalsIgnoreCase(BrowserType.Edge.name())) {
			driver = ConfigureEdgeSetUp();
		}
		return driver;
	}
	
public AndroidDriver createAndroidDriver(String browser) {		
	var driverToUse = browser;
	if(driverToUse.equalsIgnoreCase(BrowserType.Android.name())) {
		androiddriver = ConfigureAndroidDrivereSetUp();
	}
	return androiddriver;
}
	

	private WebDriver ConfigureChromeSetUp() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
//		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VParanganath\\OneDrive - Link Group\\LIC\\ChromeDriver\\chromedriver-win64\\chromedriver.exe");
//		driver = new ChromeDriver();
		return driver;
	}
	
	private AndroidDriver ConfigureAndroidDrivereSetUp() {
		try {
		 String Username ="manasabharadwaj_Mnpz90";
		 String accesskey ="LRq8kom6sCq5cxVeuL6y";
		 String URL = "https://" + Username + ":" + accesskey + "@hub-cloud.browserstack.com/wd/hub";
		 DesiredCapabilities caps = new DesiredCapabilities();
			caps.setCapability("deviceName", "Google Pixel 7 Pro");
			caps.setCapability("os_version", "13.0");
			caps.setCapability("name", "IC Android Application Test");
			caps.setCapability("app", "bs://1d194a3b9d20654a5ecfd3fe86caf6d8616c076a");
			caps.setCapability("unicodeKeyboard", true);
			androiddriver = new AndroidDriver(
	         		new java.net.URL(URL), caps);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return androiddriver;
	}
	
	
	
	private WebDriver ConfigureHeadlessChromeSetUp() {
		driver = new ChromeDriver();
		//WebDriverManager.chromedriver().setup();
		ChromeOptions chromeOptions = DriverOptions.getHeadlessChromeOptions();
		return new ChromeDriver(chromeOptions);
	}
	
	private WebDriver ConfigureIncognitoChromeSetUp() {		
		
		driver = new ChromeDriver();
		//WebDriverManager.chromedriver().setup();
		ChromeOptions chromeOptions = DriverOptions.getIncognitoChromeOptions();		
		return new ChromeDriver(chromeOptions);
	}
	
	private WebDriver ConfigureIESetUp() {
		driver = new InternetExplorerDriver();
		//WebDriverManager.iedriver().setup();
		InternetExplorerOptions ieOptions = DriverOptions.getIEOptions();
		return new InternetExplorerDriver(ieOptions);
	}
	
	private WebDriver ConfigureFirefoxSetUp() {
		driver = new FirefoxDriver();
		//WebDriverManager.firefoxdriver().setup();
		FirefoxOptions firefoxOptions = DriverOptions.getFirefoxOptions();
		return new FirefoxDriver(firefoxOptions);
	}
	
	
	
	private WebDriver ConfigureEdgeSetUp() {
		driver = new EdgeDriver();
		//WebDriverManager.edgedriver().setup();
		return driver;
	}
	
	/*private WebDriver ConfigureEdgeChromiumSetUp() {
		driver = new ChromiumDriverManager();
		//WebDriverManager.chromiumdriver().setup();
		return driver;
	}*/

}
