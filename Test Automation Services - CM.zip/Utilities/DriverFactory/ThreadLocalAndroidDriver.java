package DriverFactory;

import org.openqa.selenium.WebDriver;

import io.appium.java_client.android.AndroidDriver;

public class ThreadLocalAndroidDriver {
	
	public ThreadLocalAndroidDriver() {
	}
	
	private static ThreadLocalAndroidDriver instance= new ThreadLocalAndroidDriver();
	private static ThreadLocal<AndroidDriver> driver = new ThreadLocal<AndroidDriver>();
	
	public static ThreadLocalAndroidDriver getInstance() {
		return instance;
	}

    /**
     * @return thread local webdriver
     */
    public static AndroidDriver getDriver() {
        return driver.get();
    }

    /**
     * @param driver set the driver instance
     */
    public static  void setWebDriver(AndroidDriver driverparam) {
        driver.set(driverparam);
    }
    
    /**
     * @param Close Driver Instance and remove current thread
     */
    public  void closeBrowser() {
		try {
			driver.get().close();
			driver.remove();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    /**
     * @param Driver Instance remove current thred
     */
	public void removeThread() {
		try {
			driver.remove();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
