package DriverFactory;

import org.openqa.selenium.WebDriver;

public class ThreadLocalDriver {
	
	public ThreadLocalDriver() {
	}
	
	private static ThreadLocalDriver instance= new ThreadLocalDriver();
	private static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	
	public static ThreadLocalDriver getInstance() {
		return instance;
	}

    /**
     * @return thread local webdriver
     */
    public static WebDriver getDriver() {
        return driver.get();
    }

    /**
     * @param driver set the driver instance
     */
    public static  void setWebDriver(WebDriver driverparam) {
        driver.set(driverparam);
    }
    
    /**
     * @param Close Driver Instance and remove current thread
     */
    public  void closeBrowser() {
		try {
			driver.get().close();
			driver.remove();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    /**
     * @param Driver Instance remove current thred
     */
	public void removeThread() {
		try {
			driver.remove();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
