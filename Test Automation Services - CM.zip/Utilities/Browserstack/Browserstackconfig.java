package Browserstack;

import java.net.MalformedURLException;
import java.util.HashMap;

import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class Browserstackconfig {

	private static WebDriver driver;
	public static String Username ="manasabharadwaj_Mnpz90";
	public static String accesskey ="LRq8kom6sCq5cxVeuL6y";
	public static final String URL = "https://" + Username + ":" + accesskey + "@hub-cloud.browserstack.com/wd/hub";
	public static AndroidDriver android_driver=null;
	public static WebDriver FireFoxLaunchTest(){
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("os_version", "11");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("browser", "Firefox");
		caps.setCapability("browser_version", "latest-beta");
		caps.setCapability("os", "Windows");
		caps.setCapability("name", "Test Investment Center Lanch on BrowserStack Firefox"); // test name
		System.getProperties().put("https.proxyHost", "172.30.238.52");
        System.getProperties().put("https.proxyPort", "80");
		try {
			driver = new RemoteWebDriver(new java.net.URL(URL), caps);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}
	
	public static WebDriver ChromeLaunchTest(){
		MutableCapabilities capabilities = new MutableCapabilities();
		capabilities.setCapability("browserName", "Chrome");
		capabilities.setCapability("browserVersion", "114.0");
		HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();
		browserstackOptions.put("platformName", "Windows");
		browserstackOptions.put("osVersion", "11");
		capabilities.setCapability("bstack:options", browserstackOptions);
//		System.getProperties().put("https.proxyHost", "172.30.238.52");
//        System.getProperties().put("https.proxyPort", "80");
		try {
			driver = new RemoteWebDriver(new java.net.URL(URL), capabilities);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}

	public static WebDriver LaunchChromeIncognitoTest(){
		ChromeOptions options = new ChromeOptions();
		options.addArguments("incognito");
		options.setAcceptInsecureCerts(true);
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("os_version", "11");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("browser", "Chrome");
		caps.setCapability("browser_version", "latest-beta");
		caps.setCapability("os", "Windows");
		caps.setCapability("name", "Test Investment Center Lanch on BrowserStack Incognito Chrome"); // test name
		caps.setCapability(ChromeOptions.CAPABILITY, options);
		System.getProperties().put("https.proxyHost", "172.30.238.52");
        System.getProperties().put("https.proxyPort", "80");
		try {
			driver = new RemoteWebDriver(new java.net.URL(URL), caps);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}

	public static WebDriver LaunchMicrosoftEdgeTest(){
		ChromeOptions options = new ChromeOptions();
		options.addArguments("incognito");
		options.setAcceptInsecureCerts(true);
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("os_version", "11");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("browser", "Edge");
		caps.setCapability("browser_version", "latest-beta");
		caps.setCapability("os", "Windows");
		caps.setCapability("name", "Test Investment Center Lanch on BrowserStack MicrosoftEdge"); // test name
		caps.setCapability(ChromeOptions.CAPABILITY, options);
		System.getProperties().put("https.proxyHost", "172.30.238.52");
        System.getProperties().put("https.proxyPort", "80");
		try {
			driver = new RemoteWebDriver(new java.net.URL(URL), caps);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return driver;
	}

	public static WebDriver LaunchSafariTest() {
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("os_version", "Ventura");
		caps.setCapability("resolution", "1920x1080");
		caps.setCapability("browser", "Safari");
		caps.setCapability("browser_version", "16.0");
		caps.setCapability("os", "OS X");
		caps.setCapability("name", "Test Investment Center Lanch on BrowserStack"); // test name
		System.getProperties().put("https.proxyHost", "172.30.238.52");
        System.getProperties().put("https.proxyPort", "80");
		try {
			driver = new RemoteWebDriver(new java.net.URL(URL), caps);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}

	public static AndroidDriver launchAndroidTest(){
		try {
			DesiredCapabilities caps = new DesiredCapabilities();
			caps.setCapability("deviceName", "Samsung Galaxy S23 Ultra");
			caps.setCapability("os_version", "13.0");
			caps.setCapability("name", "LIC Android Application");
			caps.setCapability("app", "bs://3cf9a19553076eaaa90a62f758b3729df6aff2d3");
//			caps.setCapability("unicodeKeyboard", true);
//			caps.setCapability("resetKeyboard", true);
	        android_driver = new AndroidDriver(new java.net.URL(URL), caps);
		}catch (Exception e) {
			e.printStackTrace();
		}
        return android_driver;
	}
	
	public static IOSDriver launchIOSTest(){
		IOSDriver ios_driver=null;
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "iPhone 14 Plus");
		caps.setCapability("os_version", "16");
		caps.setCapability("waitForIdleTimeout", "0");
		caps.setCapability("name", "LIC IOS Application Test");
		caps.setCapability("app", "bs://666a16105a4d2de9938414cd11092c26c26dfbb5");
//		caps.setCapability("browserstack.resignApp", true);
//		caps.setCapability("autoAcceptAlerts", true);
//		caps.setCapability("unicodeKeyboard", true);
//		caps.setCapability("resetKeyboard", true);
//		System.getProperties().put("https.proxyHost", "172.30.238.52");
//        System.getProperties().put("https.proxyPort", "80");
        try {
        	System.out.println(URL);
			ios_driver = new IOSDriver(new java.net.URL(URL), caps);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return ios_driver;
	}
	
	public static AndroidDriver launchAndroidWebviewtest(){ 
		AndroidDriver android_driver=null;
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("browserName", "chrome");
		caps.setCapability("os_version", "10.0");
		caps.setCapability("deviceName", "Samsung Galaxy S20");
		caps.setCapability("local", "false");
		System.getProperties().put("https.proxyHost", "172.30.238.52");
	    System.getProperties().put("https.proxyPort", "80");
	    try {
			android_driver = new AndroidDriver(
				new java.net.URL(URL), caps);
			android_driver.get("https://ic-web-au-sit2.np.linkgroup.com/");
		}catch(MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return android_driver;
	}
	
	
	
}
