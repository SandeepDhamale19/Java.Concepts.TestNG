package AutoITFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.openqa.selenium.Keys;

import com.jacob.com.LibraryLoader;

import autoitx4java.AutoItX;
import SessionFactory.SessionVariables;
import Browsers.BrowserType;

public class AutoITFunctions {

	AutoItX autoIT;
	SessionVariables session;
	
	public AutoITFunctions() {
		String userDir = System.getProperty("user.dir");
		String jacobArchitect =
		System.getProperty("sun.arch.data.model").contains("32") ? "jacob-1.18-x86.dll" : "jacob-1.18-x64.dll";
		String jacobArchitectPath = userDir + "\\" + jacobArchitect;
		File filejacob = new File(jacobArchitect);
		System.setProperty(LibraryLoader.JACOB_DLL_PATH,
		filejacob.getAbsolutePath());
		autoIT = new AutoItX();
		//session = new SessionVariables();
	}
	
	 
	
	public void FileUpload(String FilePath)
    {
		
        try
        {
        	Thread.sleep(2000);
            //autoIT.WinActivate("Open");
            switch ("Chrome")
            {
                case "Firefox":
                    autoIT.winActivate("File Upload");
                    break;
                case "chrome":
                	autoIT.winWait("Open");
                    autoIT.winActivate("Open");
                    break;
                case "Chrome":
                	autoIT.winWait("Open");
                    autoIT.winActivate("Open");
                    break;
                case "IE":
                    autoIT.winActivate("Choose File to Upload");
                    break;
                case "ie":
                    autoIT.winActivate("Choose File to Upload");
                    break;
            }
            
            Thread.sleep(3500);
            autoIT.send(FilePath);
            Thread.sleep(4000);
            //autoIT.controlSend("Open", "", mainOutlookClass, "{ENTER}");
            autoIT.send("{ENTER}!n", false);
            Thread.sleep(3500);
        }

        catch (Exception ex)
        {
            //Assert.Fail("Unable to Upload File -" + ex.Message);
        }

    }
	
	public void ClickDownload() throws InterruptedException
	{
		
		Thread.sleep(10000);
		autoIT.send("{TAB}!n", false);
		Thread.sleep(1000);
		autoIT.send("{TAB}!n", false);
		Thread.sleep(1000);
		autoIT.send("{TAB}!n", false);
		/*Thread.sleep(1000);
		autoIT.send("{TAB}!n", false);
		Thread.sleep(1000);
		autoIT.send("{TAB}!n", false);		
		Thread.sleep(500);
		autoIT.send("{DOWN}!n", false);
		Thread.sleep(500);
		autoIT.send("{DOWN}!n", false);*/
		Thread.sleep(2000);
		autoIT.send("{ENTER}!n", false);
		Thread.sleep(5000);
	
	}
	public void FileSaveAs()
    {
		String currentPath = System.getProperty("user.dir");
		
		Path projectVariableFilepath = Paths.get(currentPath, "\\Files");
		
        String folderPath = projectVariableFilepath.toString();//System.IO.Path.GetDirectoryName(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) + ConfigurationManager.AppSettings["Files"];
        String fileName = "";
        try
        {
            Thread.sleep(1000);
            autoIT.winWait("Save As");
            autoIT.winActivate("Save As");
            Thread.sleep(2000);
            autoIT.send("{HOME}!n", false);
            Thread.sleep(1000);
            autoIT.send("{CTRLDOWN}a{CTRLUP}!n", false);
            Thread.sleep(1000);
            //autoIT.Send("^c");
            autoIT.send("{CTRLDOWN}c{CTRLUP}!n", false);
            Thread.sleep(1000);
            fileName = autoIT.clipGet();
            //session.RemoveItemFromLocalStorage("AutoITClipboard");
            //session.SetItemInLocalStorage("AutoITClipboard", fileName);
            //ScenarioContext.Current.Remove("AutoITClipboard");
            //ScenarioContext.Current.Add("AutoITClipboard", fileName);
            Thread.sleep(2000);
            autoIT.send("{HOME}!n", false);
            Thread.sleep(1000);
            autoIT.send(folderPath + "\\");
            Thread.sleep(5000);
            autoIT.winWait("Save As");
            autoIT.send("{ENTER}!n", false);
            Thread.sleep(3500);
        }
        catch (Exception ex)
        {
            //Assert.Fail("Unable to Upload File -" + ex.Message);
        }

    }
	
	public void HandleFileUploadWindow(String filepath) throws Exception
    {
        try
        {
            /*String windowTitle = Browser == "IE" ?
             "Choose File to Upload" : "Open";*/
        	String windowTitle = "Choose File to Upload";

            autoIT.winWait(windowTitle, "File &name:", 10);
            autoIT.ControlSetText(windowTitle, "", "[CLASS:Edit; INSTANCE:1]", filepath);
            autoIT.controlClick(windowTitle, "", "[CLASS:Button; INSTANCE:1]");
            autoIT.winWaitClose(windowTitle, "File &name:", 10);
        }

        catch (Exception ex)
        {
            //throw new Exception(ex.getMessage());
        }
    }

    public void WindowsWarningOrConfirmationAccept(String alertTitle)
    {
        try
        {
            if (autoIT.winExists(alertTitle))
            {
                autoIT.winActive(alertTitle);
                autoIT.controlClick(alertTitle, "", "[CLASS:Button; INSTANCE:0; TEXT:&Yes]");
                autoIT.winWaitClose(alertTitle);
            }

        }

        catch (Exception ex)
        {
            //throw new Exception(ex.getMessage());
        }
    }

    public void WindowsWarningOrConfirmationDismiss(String alertTitle)
    {
        try
        {
            if (!autoIT.winExists(alertTitle))
            {
                autoIT.winWaitActive(alertTitle);
                autoIT.controlClick(alertTitle, "", "[CLASS:Button; INSTANCE:1; TEXT:&No]");
                autoIT.winWaitClose(alertTitle);
            }
        }

        catch (Exception ex)
        {
            //throw new Exception(ex.getMessage());
        }
    }

    
    
    
    
    
}
