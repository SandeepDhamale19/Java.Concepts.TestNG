package DataFactory;

import org.apache.commons.lang3.StringUtils;


public class StringFunction {

	public static String ToTitleCase(String text) {
		
		if (text == null || text.isEmpty()) {
	        return text;
	    }

	    StringBuilder converted = new StringBuilder();

	    boolean convertNext = true;
	    for (char ch : text.toCharArray()) {
	        if (Character.isSpaceChar(ch)) {
	            convertNext = true;
	        } else if (convertNext) {
	            ch = Character.toTitleCase(ch);
	            convertNext = false;
	        } else {
	            ch = Character.toLowerCase(ch);
	        }
	        converted.append(ch);
	    }

	    return converted.toString();
	}
	
	public static String SplitTitleCase(String text) {
		
		return StringUtils.splitByCharacterTypeCamelCase(text)[0];
        //return regex.Replace(input, "([A-Z])", " $1", RegexOptions.Compiled).Trim();
    }
}
