package ElementsFactory;

import DriverFactory.ThreadLocalDriver;

public class Browser {
	
	public void Navigatebackward() {
		ThreadLocalDriver.getDriver().navigate().back();	
	}
	
	
	public void NavigateForward() {
		ThreadLocalDriver.getDriver().navigate().forward();
	}
	
	
	public void Refresh() {
		ThreadLocalDriver.getDriver().navigate().refresh();
	}
	
}
