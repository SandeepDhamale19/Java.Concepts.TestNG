/**
 * 
 */
package ElementsFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import ActionsFactory.ClickActions;
import ActionsFactory.FindElements;
import ActionsFactory.InputAction;
import DriverFactory.ThreadLocalIOSDriver;
import io.appium.java_client.AppiumBy;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Input {
	private String _locator;
	private String _locatorType;
	
	public Input(String locator,String locatorType) {
		this._locator = locator;
		this._locatorType = locatorType;
	}
	
	public Input() {
	}
	public void Inputvalues(String values) {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.InputValues(values);
		ExtentCucumberAdapter.addTestStepLog("Input values in UI:"+values);
	}
	
	public void ClearInputvalues() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.ClearText();
	}
	
	public void ClearInputText() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.clearInputText(By.xpath(_locator));
	}
	
	public Boolean IsDisplayed() {
		InputAction click= new InputAction(_locator, _locatorType);
		Boolean flag = click.IsDisplayed();
		return flag;
	}
	
	public Boolean IsEnabled() {
		InputAction click= new InputAction(_locator, _locatorType);
		Boolean flag = click.IsEnabled();
		return flag;
	}
	
	public String getInputText() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		String valueText = InputAction.getInputText(By.xpath(_locator));
		return valueText;
	}
	
	
	public void ClickSendkeys(String values) {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.InputValues(values);
	}
	
	
	public void SendkeysEnter() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.enterKey(By.xpath(_locator));
	}
	
	public void InputDeleteFullText() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.deleteFullText(By.xpath(_locator));
	}
	
	public void selectText() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.SelectText(By.xpath(_locator));
	}
	
	public void InputtextIsEnabled() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.SelectText(By.xpath(_locator));
	}
	
	// Android Device UI Actions //
	
	public void AndroidDeviceInputvalues(String values) {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.AndroidElementInputValues(values);
		ExtentCucumberAdapter.addTestStepLog("Input values in UI:"+values);
	}
	
	public void AndroidDeviceClearInputvalues() {
		InputAction InputAction= new InputAction(_locator, _locatorType);
		InputAction.androidElementClearText();
	}
	
	
	// Android Device UI Actions //
	
		public void IOSDeviceInputvalues(String values) {
			InputAction InputAction= new InputAction(_locator, _locatorType);
			InputAction.IOSElementInputValues(values);
			ExtentCucumberAdapter.addTestStepLog("Input values in UI:"+values);
		}
		
		public void IOSDeviceClearInputvalues() {
			InputAction InputAction= new InputAction(_locator, _locatorType);
			InputAction.IOSElementClearText();
		}
	
		public void iosHideKeyboard() {
			if(ThreadLocalIOSDriver.getDriver().isKeyboardShown()) {   
				ThreadLocalIOSDriver.getDriver().findElement(AppiumBy.xpath("//XCUIElementTypeButton[@name='Done']")).click();
			}
		}
}