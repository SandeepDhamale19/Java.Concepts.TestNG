package ElementsFactory;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import ActionsFactory.ClickActions;
import ActionsFactory.FindAndroidElements;
import ActionsFactory.FindElements;

public class Button {

	private String _locator = "";
	private String _locatorType = "";
	
	public Button(String locator, String locatorType) {
		this._locator=locator;
		this._locatorType=locatorType;
	}
	public Button() {
	}
	
	public void Click() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		click.Click();
	}
	
	public void Click(String dynamicLocator) {
		ClickActions click= new ClickActions(dynamicLocator, _locatorType);
		click.Click();
	}
	
	public Boolean IsDisplayed() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		Boolean flag = click.IsDisplayed();
		return flag;
	}
	
	public Boolean IsSelected() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		Boolean flag = click.IsSelected();
		return flag;
	}
	
	public void ValidateIsButtonDisplayed() {
		if (FindElements.FindElement(_locator, _locatorType).isDisplayed()) {
			ExtentCucumberAdapter.addTestStepLog("Button is Displayed on Screen!!");
		}else{
			ExtentCucumberAdapter.addTestStepLog("Button is NOT Displayed on Screen!!");
		}
	}
	
	public void ValidateIsSelected() {
		if (FindElements.FindElement(_locator, _locatorType).isSelected()) {
			ExtentCucumberAdapter.addTestStepLog("Button is Displayed on Screen!!");
		}else{
			ExtentCucumberAdapter.addTestStepLog("Button is NOT Displayed on Screen!!");
		}
	}
	
	// Android Device UI Actions //
	public void AndroidElementClick() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		click.androidElementClick();
	}
	
	public Boolean AndroidElementIsDisplayed() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		Boolean flag = click.androidElementIsDisplayed();
		return flag;
	}
	
	public Boolean AndroidElementIsSelected() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		Boolean flag = click.androidElementIsSelected();
		return flag;
	}
	
	public void AndroidElementValidateIsButtonDisplayed() {
		if (FindAndroidElements.FindElement(_locator, _locatorType).isDisplayed()) {
			ExtentCucumberAdapter.addTestStepLog("Button is Displayed on Screen!!");
		}else{
			ExtentCucumberAdapter.addTestStepLog("Button is NOT Displayed on Screen!!");
		}
	}
	
	public void AndroidElementValidateIsSelected() {
		if (FindAndroidElements.FindElement(_locator, _locatorType).isSelected()) {
			ExtentCucumberAdapter.addTestStepLog("Button is Displayed on Screen!!");
		}else{
			ExtentCucumberAdapter.addTestStepLog("Button is NOT Displayed on Screen!!");
		}
	}
	
	//IOS Device UI Actions // 
	public void IOSElementClick() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		click.iosElementClick();
	}
	
	
	public void IOSElementClick(String label) {
		ClickActions click= new ClickActions(label, "XPATH");
		click.iosElementClickbylabel(label);
	}
	
	public void IOSElementIsEnabled() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		Boolean flagCheck = click.iOSElementIsEnabled();
		if (!flagCheck) {
			Assert.fail("Element is Not Enabled!");
		}
	}
	
	public void IOSElementIsDisplayed() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		Boolean flagCheck = click.iOSElementIsDisplayed();
		if (!flagCheck) {
			Assert.fail("Element is Not Displayed!");
		}
	}
	
	public void IOSElementTap() {
		ClickActions click= new ClickActions(_locator, _locatorType);
		click.tapElement();
	}
	
}
