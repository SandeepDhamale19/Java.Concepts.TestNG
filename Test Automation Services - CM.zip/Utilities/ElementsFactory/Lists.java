/**
 * 
 */
package ElementsFactory;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import ActionsFactory.ListActions;
import DriverFactory.ThreadLocalDriver;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Lists {
	
	private String _locator = "";
	
	public Lists(String locator) {
		_locator = locator;
	}
	
	public List<WebElement> GetNoOfWebElements() {
		ListActions ob= new ListActions(_locator);
		List<WebElement> elements = ob.GetNoOfWebElements();
	    return elements;
	}
	
	public ArrayList<String> GetListOfWebElements() {
		ListActions ob= new ListActions(_locator);
		ArrayList<String> array_List = ob.GetListOfWebElements();
	    return array_List;
	}
	
	
	
	
	
	
	
}
