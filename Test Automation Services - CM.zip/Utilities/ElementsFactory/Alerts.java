/**
 * 
 */
package ElementsFactory;

import ActionsFactory.ActionOnElement;
import ActionsFactory.AlertsAction;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Alerts {
	
	public void DismissAlert() {
		AlertsAction alert= new AlertsAction();
		alert.alertDismiss();
	}
	
	
	public void AcceptAlert() {
		AlertsAction alert= new AlertsAction();
		alert.alertAccept();
	}
	
	public String getTextAlert() {
		AlertsAction alert= new AlertsAction();
		return alert.getAlertText();
	}
	
	public void setTextAlert(String value) {
		AlertsAction alert= new AlertsAction();
		alert.alertSendkeys(value);
	}
	
}
