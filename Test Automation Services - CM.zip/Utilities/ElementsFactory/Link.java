/**
 * 
 */
package ElementsFactory;

/**
 * @author Varun Paranganath
 *02/06/2023
 *testautomation-framework
 */
public class Link {
	
	
	
	
}
