package DateFactory;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class DateFunction {
	
	public static String dateFormatChange (String convertDate) throws Exception{
        String oldFormat = "dd/MM/yyyy";
        String newFormat = "dd MMM yyyy";
        String str1 = convertDate;
        String strnew = str1.substring(0,10);
        SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
        Date d = sdf.parse(strnew);
        sdf.applyPattern(newFormat);
        System.out.println("final->"+sdf.format(d));
    return (sdf.format(d).replace(".", ""));
    }
	
	public static boolean ValidateBetweenSpecifiedRange(String startDate , String endDate, String checkDate) throws Exception{
		String oldFormat = "dd/MM/yyyy";
        String newFormat = "dd MMM yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
        Date startDateFormat = sdf.parse(startDate);
        Date endDateFormat = sdf.parse(startDate);
        Date checkDateFormat = sdf.parse(startDate);
        
        Boolean flagcheck1 = checkDateFormat.after(startDateFormat);
        Boolean flagcheck2 = checkDateFormat.before(endDateFormat);
        
        if (flagcheck1 && flagcheck2) {
			return true;
		}
		else if (flagcheck1 == false || flagcheck2 == false ) 
		{
			return true;
		}
		else {
			return false;
		}
    }
	
	public static String getTodaysDate(String Dateformat) {
		LocalDate today = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Dateformat);
		String formattedDate = today.format(formatter);
		return formattedDate;
	}
	
	public static String getDateLastYears(String Dateformat) {
		LocalDate lasttwoyearsDate = LocalDate.now().minusYears(2);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Dateformat);
		String formattedDate = lasttwoyearsDate.format(formatter);
		return formattedDate;
	}
	
}
