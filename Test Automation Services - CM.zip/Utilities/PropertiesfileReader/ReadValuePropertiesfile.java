/**
 * 
 */
package PropertiesfileReader;

import java.io.FileInputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * @author Varun Paranganath
 *17/05/2023
 *testautomation-framework
 */
public class ReadValuePropertiesfile {
	
	static Properties prop;
	
	public static String ConfigDataProvider(String directorypath,String Key) {
		String value=null;
		try {
			String currentPath = System.getProperty("user.dir");
			Path projectVariableFilepath = Paths.get(currentPath, directorypath);
			FileInputStream propFile = new FileInputStream(projectVariableFilepath.toString());
			prop = new Properties();
			prop.load(propFile);
			value = prop.get(Key).toString();
		} catch(Exception e) {
			System.out.println("Unable to read the config file : " + e.getMessage());
		}
		return value;
	}
}
